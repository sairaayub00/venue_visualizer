package com.example.majumodel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
