import 'dart:ui';

final Color appColorPrimary = Color(0xFFFBFEFF);
final Color appColorSecondary = Color(0xFF343434);
final Color appColorAccent = Color(0xFFCD7F32);
final Color appColorGrey = Color(0xFFE1E1E1);