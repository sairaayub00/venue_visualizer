import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
class ModelService{

  static Future<String> uploadingModel(String modelImage)async{
    debugPrint("ImageUrl is : $modelImage");
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer msy_JerCxuFYavNV0TXgzfUPSuAvGke6RuhTKAZE'
    };
    var request = http.Request('POST', Uri.parse('https://api.meshy.ai/v1/image-to-3d'));
    request.body = json.encode({
      "image_url": modelImage
    });
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 202) {
      var res = await response.stream.bytesToString();
      Map data = jsonDecode(res);
      String imageID = data['result'];
      debugPrint("ID is: $imageID and Res is : $res");
      return imageID;
    }
    else {
      debugPrint(response.reasonPhrase.toString());
      return response.reasonPhrase.toString();
    }

  }



  static Future convertingUpdatingModel(String modelID)async{
    try {
      var modelLink = '';
      int progress = 0;
      int maxRetries = 50;
      int retryCount = 0;

      while (progress < 100 && retryCount < maxRetries) {
        retryCount++;
      var headers = {
        'Authorization': 'Bearer msy_JerCxuFYavNV0TXgzfUPSuAvGke6RuhTKAZE'
      };
      var request = http.Request(
          'GET', Uri.parse('https://api.meshy.ai/v1/image-to-3d/$modelID'));

      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        var res = await response.stream.bytesToString();
        Map data = jsonDecode(res);
        progress = data['progress'];

        if (progress == 100) {
          modelLink = data['model_urls']['glb'];
          debugPrint("Model link fetched successfully: $modelLink");
          break;
        } else {
          debugPrint('Image is Processing: $progress');
        }
      }
      await Future.delayed(const Duration(seconds: 2));
    }
      return {"progress": progress, "format": modelLink};

    }catch(ex){
      debugPrint('An Error Occurred: $ex');
      return ex;
    }

  }

}