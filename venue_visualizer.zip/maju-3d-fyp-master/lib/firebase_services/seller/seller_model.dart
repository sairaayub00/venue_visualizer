// import 'dart:io';
//
// class SellerModel{
//
//   final String? sellerID;
//   final String? sellerName;
//   final String? sellerRole;
//   final File? sellerImage;
//   final String? getImage;
//   final String? sellerAge;
//   final String? sellerGender;
//   final String? sellerPhone;
//   final String? sellerEmail;
//   final String sellerPassword;
//   final bool? sellerStatus;
//   final String? createdAt;
//
//   SellerModel(
//       {this.sellerID,
//         this.sellerName,
//         this.sellerRole,
//         this.sellerImage,
//         this.getImage,
//         this.sellerAge,
//         this.sellerGender,
//         this.sellerPhone,
//         this.sellerEmail,
//         required this.sellerPassword,
//         this.sellerStatus,
//         this.createdAt});
// }