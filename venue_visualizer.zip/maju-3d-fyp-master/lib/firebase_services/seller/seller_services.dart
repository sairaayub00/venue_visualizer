// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/material.dart';
// import 'package:majumodel/views/main_navbar/home_screen.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../views/credentials_screen/login_screen.dart';
// import 'seller_model.dart';
//
// class SellerServices{
//
//   final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("sellerData");
//
//   void sellerRegister(SellerModel sellerModel, BuildContext context)async{
//     try{
//       if(sellerModel.sellerImage != null){
//         await FirebaseAuth.instance.createUserWithEmailAndPassword(email: sellerModel.sellerEmail!, password: sellerModel.sellerPassword);
//
//         UploadTask uploadTask = FirebaseStorage.instance.ref().child("sellerImages").child('${sellerModel.sellerID!}').putFile(sellerModel.sellerImage!);
//         TaskSnapshot taskSnapshot = await uploadTask;
//         String sellerImage = await taskSnapshot.ref.getDownloadURL();
//
//         _collectionReference.doc('${sellerModel.sellerID}').set({
//           "sID" : sellerModel.sellerID,
//           "sName" : sellerModel.sellerName,
//           "sRole" : sellerModel.sellerRole,
//           "sImage" : sellerImage,
//           "sAge" : sellerModel.sellerAge,
//           "sGender" : sellerModel.sellerGender,
//           "sPhone" : sellerModel.sellerPhone,
//           "sEmail" : sellerModel.sellerEmail,
//           "sPassword" : sellerModel.sellerPassword,
//           "sStatus" : sellerModel.sellerStatus,
//           "sCreatedAt" : sellerModel.createdAt
//         });
//         if(context.mounted){
//           ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Registration Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//           Navigator.push(context, MaterialPageRoute(builder:  (context) => const LoginScreen(),));
//         }
//       }
//       else{
//         await FirebaseAuth.instance.createUserWithEmailAndPassword(email: sellerModel.sellerEmail!, password: sellerModel.sellerPassword);
//         _collectionReference.doc('${sellerModel.sellerID}').set({
//           "sID" : sellerModel.sellerID,
//           "sName" : sellerModel.sellerName,
//           "sRole" : sellerModel.sellerRole,
//           "sImage" : "",
//           "sAge" : sellerModel.sellerAge,
//           "sGender" : sellerModel.sellerGender,
//           "sPhone" : sellerModel.sellerPhone,
//           "sEmail" : sellerModel.sellerEmail,
//           "sPassword" : sellerModel.sellerPassword,
//           "sStatus" : sellerModel.sellerStatus,
//           "sCreatedAt" : sellerModel.createdAt
//         });
//         if(context.mounted){
//           ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Registration Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//           Navigator.push(context, MaterialPageRoute(builder:  (context) => const LoginScreen(),));
//         }
//         // ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not picked"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//       }
//     } on FirebaseAuthException catch(ex){
//       if(context.mounted){
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//       }
//     }
//   }
//
//   void sellerLogin(SellerModel logModel, BuildContext context)async {
//     try {
//       await FirebaseAuth.instance.signInWithEmailAndPassword(email: logModel.sellerEmail!, password: logModel.sellerPassword);
//       SharedPreferences sellerCred = await SharedPreferences.getInstance();
//       sellerCred.setString("email", logModel.sellerEmail!);
//       if(context.mounted){
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//           content: Text("Login Successful"),
//           backgroundColor: Colors.green,
//           margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
//           behavior: SnackBarBehavior.floating,));
//         Navigator.push(context, MaterialPageRoute(builder:  (context) => const HomeScreen(),));
//       }
//     } on FirebaseAuthException catch (ex) {
//       if (context.mounted) {
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//           content: Text("Something went Wrong"),
//           backgroundColor: Colors.red,
//           margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
//           behavior: SnackBarBehavior.floating,));
//       }
//     }
//   }
//
//   void sellerLogout(BuildContext context)async{
//     await FirebaseAuth.instance.signOut();
//     SharedPreferences sellerCred = await SharedPreferences.getInstance();
//     sellerCred.clear();
//     if(context.mounted){
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Logout Successful"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//       Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
//     }
//   }
//
//   static Future sellerCredGet()async{
//     SharedPreferences sellerCred = await SharedPreferences.getInstance();
//     var uEmail = sellerCred.getString("email");
//     return uEmail;
//   }
//
//   Stream<List<SellerModel>> getSeller(String? uEmail){
//     return _collectionReference.where('sEmail',isEqualTo: uEmail).snapshots().map((snapshot){
//       return snapshot.docs.map((doc){
//         Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
//         return SellerModel(
//           sellerID: data['sID'],
//           sellerName: data['sName'],
//           sellerRole: data['sRole'],
//           getImage: data['sImage'],
//           sellerAge: data['sAge'],
//           sellerGender: data['sGender'],
//           sellerPhone: data['sPhone'],
//           sellerEmail: data['sEmail'],
//           sellerPassword: data['sPassword'],
//           sellerStatus: data['sStatus'],
//           createdAt: data['sCreatedAt'],
//         );
//       }).toList();
//     });
//   }
//
//   Stream<List<SellerModel>> getAllSeller(){
//     return _collectionReference.snapshots().map((snapshot){
//       return snapshot.docs.map((doc){
//         Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
//         return SellerModel(
//           sellerID: data['sID'],
//           sellerName: data['sName'],
//           sellerRole: data['sRole'],
//           getImage: data['sImage'],
//           sellerAge: data['sAge'],
//           sellerGender: data['sGender'],
//           sellerPhone: data['sPhone'],
//           sellerEmail: data['sEmail'],
//           sellerPassword: data['sPassword'],
//           sellerStatus: data['sStatus'],
//           createdAt: data['sCreatedAt'],
//         );
//       }).toList();
//     });
//   }
//
//   Stream<List<SellerModel>> searchSeller(String? searchQuery){
//     return _collectionReference.snapshots().map((snapshot){
//       return snapshot.docs.map((doc){
//         Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
//         return SellerModel(
//           sellerID: data['sID'],
//           sellerName: data['sName'],
//           sellerRole: data['sRole'],
//           getImage: data['sImage'],
//           sellerAge: data['sAge'],
//           sellerGender: data['sGender'],
//           sellerPhone: data['sPhone'],
//           sellerEmail: data['sEmail'],
//           sellerPassword: data['sPassword'],
//           sellerStatus: data['sStatus'],
//           createdAt: data['sCreatedAt'],
//         );
//       }).where((seller) {
//         if (searchQuery == null || searchQuery.isEmpty) {
//           return true;
//         } else {
//           return seller.sellerName!.toLowerCase().contains(searchQuery.toLowerCase());
//         }
//       }).toList();
//     });
//   }
//
//   void sellerUpdate(SellerModel sellerModel, BuildContext context)async{
//     try{
//       if(sellerModel.sellerImage != null){
//
//         FirebaseStorage.instance.refFromURL(sellerModel.getImage!).delete();
//         UploadTask uploadTask = FirebaseStorage.instance.ref().child("sellerImages").child('${sellerModel.sellerID!}').putFile(sellerModel.sellerImage!);
//         TaskSnapshot taskSnapshot = await uploadTask;
//         String sellerImage = await taskSnapshot.ref.getDownloadURL();
//
//         _collectionReference.doc('${sellerModel.sellerID}').update({
//           "sID" : sellerModel.sellerID,
//           "sName" : sellerModel.sellerName,
//           "sRole" : sellerModel.sellerRole,
//           "sImage" : sellerImage,
//           "sAge" : sellerModel.sellerAge,
//           "sGender" : sellerModel.sellerGender,
//           "sPhone" : sellerModel.sellerPhone,
//           "sEmail" : sellerModel.sellerEmail,
//           "sPassword" : sellerModel.sellerPassword,
//           "sStatus" : sellerModel.sellerStatus,
//           "sCreatedAt" : sellerModel.createdAt
//         });
//         if(context.mounted){
//           ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Update Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//           Navigator.push(context, MaterialPageRoute(builder:  (context) => const LoginScreen(),));
//         }
//       }
//       else{
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not picked"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//       }
//     } on FirebaseAuthException catch(ex){
//       if(context.mounted){
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//       }
//     }
//
//   }
//
//   void sellerDelete(String? sellerID, String? sellerImage, BuildContext context)async{
//     try{
//       await FirebaseStorage.instance.refFromURL(sellerImage!).delete();
//       await FirebaseAuth.instance.currentUser!.delete();
//       await _collectionReference.doc(sellerID).delete();
//
//       if(context.mounted){
//         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Account Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//         Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
//       }
//
//     }catch(ex){
//       if(context.mounted){
//         ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
//         Navigator.pop(context);
//       }
//     }
//   }
//
// }