import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:majumodel/firebase_services/order/order_model.dart';

class OrderService{

  final CollectionReference _orderReference = FirebaseFirestore.instance.collection('order');

  Future<void> addOrder(OrderModel order, BuildContext context)async{
    try{
      _orderReference.doc(order.orderID).set({
        "orderID": order.orderID,
        "sellerID": order.sellerID,
        "userEmail": order.userEmailID,
        "orderItem": order.orderItem,
        "orderPrice": order.orderPrice,
        "orderStatus": order.orderStatus,
        "shippingID": order.shippingID,
        "cardID": order.cardID,
        "createdAt": order.createdAt
      });
      clearCart(order.userEmailID);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Order Generated"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      Navigator.pop(context);
    } catch(ex) {
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

  Stream getOrder(String sellerEmail){
    return _orderReference.where('sellerID',isEqualTo: sellerEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String,dynamic> data = doc.data() as Map<String, dynamic>;
        return OrderModel(
            orderID: data['orderID'],
            sellerID: data['sellerID'],
            userEmailID : data['userEmail'],
            orderItem: data['orderItem'],
            orderPrice: data['orderPrice'],
            orderStatus: data['orderStatus'],
            shippingID: data['shippingID'],
            cardID: data['cardID'],
            createdAt: data['createdAt']
        );
      }).toList();
    });
  }

  Stream getUserOrder(String userEmail){
    return _orderReference.where('userEmail',isEqualTo: userEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String,dynamic> data = doc.data() as Map<String, dynamic>;
        return OrderModel(
            orderID: data['orderID'],
            sellerID: data['sellerID'],
            userEmailID : data['userEmail'],
            orderItem: data['orderItem'],
            orderPrice: data['orderPrice'],
            orderStatus: data['orderStatus'],
            shippingID: data['shippingID'],
            cardID: data['cardID'],
            createdAt: data['createdAt']
        );
      }).toList();
    });
  }

  Stream getAllOrder(){
    return _orderReference.snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String,dynamic> data = doc.data() as Map<String, dynamic>;
        return OrderModel(
            orderID: data['orderID'],
            sellerID: data['sellerID'],
            userEmailID : data['userEmail'],
            orderItem: data['orderItem'],
            orderPrice: data['orderPrice'],
            orderStatus: data['orderStatus'],
            shippingID: data['shippingID'],
            cardID: data['cardID'],
            createdAt: data['createdAt']
        );
      }).toList();
    });
  }

  Future<void> updateOrder(OrderModel order, BuildContext context)async{
    try{
      _orderReference.doc(order.orderID).update({
        "orderID": order.orderID,
        "sellerID": order.sellerID,
        "userEmail": order.userEmailID,
        "orderItem": order.orderItem,
        "orderPrice": order.orderPrice,
        "orderStatus": order.orderStatus,
        "shippingID": order.shippingID,
        "cardID": order.cardID,
        "createdAt": order.createdAt
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Order Updated"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      Navigator.pop(context);
    } catch(ex) {
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

  Future<void> deleteOrder(String orderID, BuildContext context)async{
    try{
      _orderReference.doc(orderID).delete();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Order Deleted"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
    }
    catch(ex) {
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  // Deletes all cart data for the specified userEmail.
  void clearCart(String userEmail) async {
    final FirebaseFirestore _firestore = FirebaseFirestore.instance;
    try {
      // Query to find all cart items for the given userEmail
      final QuerySnapshot cartSnapshot = await _firestore
          .collection('cart')
          .where('cEmail', isEqualTo: userEmail)
          .get();

      // Batch write to delete all matched documents
      final WriteBatch batch = _firestore.batch();

      for (var doc in cartSnapshot.docs) {
        batch.delete(doc.reference);
      }

      // Commit the batch
      await batch.commit();

      print('Cart cleared for user: $userEmail');
    } catch (e) {
      print('Error clearing cart for $userEmail: $e');
    }
  }


}