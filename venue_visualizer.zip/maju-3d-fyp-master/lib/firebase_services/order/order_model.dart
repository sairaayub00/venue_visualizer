class OrderModel{
  final String orderID;
  final String sellerID;
  final String userEmailID;
  final String orderPrice;
  final List orderItem;
  final String orderStatus;
  final String shippingID;
  final String cardID;
  final String createdAt;

  OrderModel(
      {
      required this.orderID,
        required this.sellerID,
        required this.userEmailID,
        required this.orderPrice,
        required this.orderItem,
        required this.orderStatus,
        required this.shippingID,
        required this.cardID,
        required this.createdAt
      });


}