import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'card_model.dart';

class CardService{
  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("card");

  Stream<List<CardModel>> getCard(String? userEmail){
    return _collectionReference.where('cEmail', isEqualTo: userEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return CardModel(
            cardID: data['cID'],
            userEmail: data['cEmail'],
            cardHolderName: data['cName'],
            cardNumber: data['cNumber'],
            expiryDate: data['cExpiry'],
            cardCvv: data['cCvv'],
        );
      }).toList();
    });
  }

  void addCard(CardModel cardModel, BuildContext context)async{
    try{
      await _collectionReference.doc(cardModel.cardID).set({
        "cID" : cardModel.cardID,
        "cEmail" : cardModel.userEmail,
        "cName" : cardModel.cardHolderName,
        "cNumber" : cardModel.cardNumber,
        "cExpiry" : cardModel.expiryDate,
        "cCvv" : cardModel.cardCvv,
      });
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Card Added Successfully"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void updateCard(CardModel cardModel, BuildContext context)async{
    try{
      await _collectionReference.doc(cardModel.cardID).update({
        "cEmail" : cardModel.userEmail,
        "cName" : cardModel.cardHolderName,
        "cNumber" : cardModel.cardNumber,
        "cExpiry" : cardModel.expiryDate,
        "cCvv" : cardModel.cardCvv,
      });
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Card Updated Successfully"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void deleteCard(String cardId, BuildContext context)async{
    try{
      await _collectionReference.doc(cardId).delete();

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Card Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

}