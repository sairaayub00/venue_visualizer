class CardModel{
  final String cardID;
  final String userEmail;
  final String cardHolderName;
  final String cardNumber;
  final String expiryDate;
  final String cardCvv;

  CardModel(
      {
        required this.cardID,
        required this.userEmail,
        required this.cardHolderName,
        required this.cardNumber,
        required this.expiryDate,
        required this.cardCvv
      });
}