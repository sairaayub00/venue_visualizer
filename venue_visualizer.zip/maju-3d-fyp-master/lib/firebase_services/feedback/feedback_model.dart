class FeedbackModel{
  final String feedbackID;
  final String userEmail;
  final String userFeedback;

  FeedbackModel(this.feedbackID, this.userEmail, this.userFeedback);
}