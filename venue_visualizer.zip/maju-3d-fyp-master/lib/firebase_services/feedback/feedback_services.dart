import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:majumodel/firebase_services/feedback/feedback_model.dart';

class FeedbackServices{

  final CollectionReference _feedBackRef = FirebaseFirestore.instance.collection("feedback");

  Future<void> addFeedback(FeedbackModel model, BuildContext context)async{
    try{

      await _feedBackRef.doc(model.feedbackID).set({
        "feedbackID" : model.feedbackID,
        "userEmail" : model.userEmail,
        "userFeedback" : model.userFeedback,
      });

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Thanks for your words"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }

    catch(e){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  Stream<List<FeedbackModel>> getFeedback(){
    return _feedBackRef.snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return FeedbackModel(data['feedbackID'], data['userEmail'], data['userFeedback']);
      }).toList();
    });
  }

}