import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:majumodel/views/main_navbar/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../views/credentials_screen/login_screen.dart';
import 'admin_model.dart';

class AdminServices{

  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("adminData");

  void adminRegister(AdminModel adminModel, BuildContext context)async{
    try{
      if(adminModel.adminImage != null){
        await FirebaseAuth.instance.createUserWithEmailAndPassword(email: adminModel.adminEmail!, password: adminModel.adminPassword);

        UploadTask uploadTask = FirebaseStorage.instance.ref().child("adminImages").child('${adminModel.adminID!}').putFile(adminModel.adminImage!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String adminImage = await taskSnapshot.ref.getDownloadURL();

        _collectionReference.doc('${adminModel.adminID}').set({
          "aID" : adminModel.adminID,
          "aName" : adminModel.adminName,
          "aRole" : adminModel.adminRole,
          "aImage" : adminImage,
          "aAge" : adminModel.adminAge,
          "aGender" : adminModel.adminGender,
          "aPhone" : adminModel.adminPhone,
          "aEmail" : adminModel.adminEmail,
          "aPassword" : adminModel.adminPassword,
          "aStatus" : adminModel.adminStatus,
          "aCreatedAt" : adminModel.createdAt
        });
        if(context.mounted){
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Registration Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
          Navigator.push(context, MaterialPageRoute(builder:  (context) => const LoginScreen(),));
        }
      }
      else{
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not picked"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    } on FirebaseAuthException catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void adminLogin(AdminModel logModel, BuildContext context)async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: logModel.adminEmail!, password: logModel.adminPassword);
      SharedPreferences adminCred = await SharedPreferences.getInstance();
      adminCred.setString("email", logModel.adminEmail!);
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Login Successful"),
          backgroundColor: Colors.green,
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          behavior: SnackBarBehavior.floating,));
        Navigator.push(context, MaterialPageRoute(builder:  (context) => const HomeScreen(),));
      }
    } on FirebaseAuthException catch (ex) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Something went Wrong"),
          backgroundColor: Colors.red,
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void adminLogout(BuildContext context)async{
    await FirebaseAuth.instance.signOut();
    SharedPreferences adminCred = await SharedPreferences.getInstance();
    adminCred.clear();
    if(context.mounted){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Logout Successful"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
    }
  }

  static Future adminCredGet()async{
    SharedPreferences adminCred = await SharedPreferences.getInstance();
    var uEmail = adminCred.getString("email");
    return uEmail;
  }

  Stream<List<AdminModel>> getAdmin(String? uEmail){
    return _collectionReference.where('aEmail',isEqualTo: uEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return AdminModel(
          adminID: data['aID'],
          adminName: data['aName'],
          adminRole: data['aRole'],
          getImage: data['aImage'],
          adminAge: data['aAge'],
          adminGender: data['aGender'],
          adminPhone: data['aPhone'],
          adminEmail: data['aEmail'],
          adminPassword: data['aPassword'],
          adminStatus: data['aStatus'],
          createdAt: data['aCreatedAt'],
        );
      }).toList();
    });
  }

  void adminUpdate(AdminModel adminModel, BuildContext context)async{
    try{
      if(adminModel.adminImage != null){

        FirebaseStorage.instance.refFromURL(adminModel.getImage!).delete();
        UploadTask uploadTask = FirebaseStorage.instance.ref().child("adminImages").child('${adminModel.adminID!}').putFile(adminModel.adminImage!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String adminImage = await taskSnapshot.ref.getDownloadURL();

        _collectionReference.doc('${adminModel.adminID}').update({
          "aID" : adminModel.adminID,
          "aName" : adminModel.adminName,
          "aRole" : adminModel.adminRole,
          "aImage" : adminImage,
          "aAge" : adminModel.adminAge,
          "aGender" : adminModel.adminGender,
          "aPhone" : adminModel.adminPhone,
          "aEmail" : adminModel.adminEmail,
          "aPassword" : adminModel.adminPassword,
          "aStatus" : adminModel.adminStatus,
          "aCreatedAt" : adminModel.createdAt
        });
        if(context.mounted){
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Update Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
          Navigator.push(context, MaterialPageRoute(builder:  (context) => const LoginScreen(),));
        }
      }
      else{
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not picked"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    } on FirebaseAuthException catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }

  }

  void adminDelete(String? adminID, String? adminImage, BuildContext context)async{
    try{
      await FirebaseStorage.instance.refFromURL(adminImage!).delete();
      await FirebaseAuth.instance.currentUser!.delete();
      await _collectionReference.doc(adminID).delete();

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Account Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
      }

    }catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

}