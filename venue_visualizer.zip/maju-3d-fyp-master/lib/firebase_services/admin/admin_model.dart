import 'dart:io';

class AdminModel{

  final int? adminID;
  final String? adminName;
  final String? adminRole;
  final File? adminImage;
  final String? getImage;
  final int? adminAge;
  final String? adminGender;
  final BigInt? adminPhone;
  final String? adminEmail;
  final String adminPassword;
  final bool? adminStatus;
  final DateTime? createdAt;

  AdminModel(
      {this.adminID,
        this.adminName,
        this.adminRole,
        this.adminImage,
        this.getImage,
        this.adminAge,
        this.adminGender,
        this.adminPhone,
        this.adminEmail,
        required this.adminPassword,
        this.adminStatus,
        this.createdAt});
}