import 'dart:io';

class UserModel{

  final String? userID;
  final String? userName;
  final String? userRole;
  final File? userImage;
  final String? getImage;
  final String? userAge;
  final String? userGender;
  final String? userPhone;
  final String? userEmail;
  final String userPassword;
  final bool? userStatus;
  final String? createdAt;

  UserModel(
      {this.userID,
      this.userName,
      this.userRole,
      this.userImage,
      this.getImage,
      this.userAge,
      this.userGender,
      this.userPhone,
      this.userEmail,
      required this.userPassword,
      this.userStatus,
      this.createdAt});
}