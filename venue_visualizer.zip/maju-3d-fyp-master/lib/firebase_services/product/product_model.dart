import 'dart:io';

class ProductModel{
  final String productId;
  final String sellerEmail;
  final String? productName;
  final File? productImage;
  final String? getProductImage;
  final String? productDescription;
  final String? productCategory;
  final String? productPrice;
  final String? productWidth;
  final String? productHeight;
  final String? productBreath;
  final String? glbFormat;
  final String? fbxFormat;
  final String? objFormat;
  var productReviews;
  final String? productStatus;
  final String? createdAt;

  ProductModel(
      {
        required this.productId,
        required this.sellerEmail,
      this.productName,
      this.productImage,
      this.getProductImage,
      this.productDescription,
      this.productCategory,
      this.productPrice,
      this.productWidth,
      this.productHeight,
      this.productBreath,
      this.glbFormat,
      this.fbxFormat,
      this.objFormat,
      this.productReviews,
      this.productStatus,
      this.createdAt});
}