import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_event.dart';
import 'package:majumodel/firebase_services/3d_service/3d_service.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ProductService{
  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("productData");


  void productAdd(ProductModel productModel, BuildContext context)async{
    try{
      if(productModel.productImage != null){
        BlocProvider.of<LoaderBloc>(context).add(LoadEvent(true));
        UploadTask uploadTask = FirebaseStorage.instance.ref().child("productImages").child(productModel.productId).putFile(productModel.productImage!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String userImage = await taskSnapshot.ref.getDownloadURL();

        var id = await ModelService.uploadingModel(userImage);
        var modelGlb = await ModelService.convertingUpdatingModel(id);

        await _collectionReference.doc(productModel.productId).set({
          "pID" : productModel.productId,
          "sEmail": productModel.sellerEmail,
          "pName" : productModel.productName,
          "pImage" : userImage,
          "pDesc" : productModel.productDescription,
          "pCate" : productModel.productCategory,
          "pPrice" : productModel.productPrice,
          "pWidth" : productModel.productWidth,
          "pHeight" : productModel.productHeight,
          "pBreath" : productModel.productBreath,
          "glbFormat" : modelGlb['format'],
          "fbxFormat" : "",
          "objFormat" : "",
          "pReviews" : [],
          "pStatus" : productModel.productStatus,
          "pCreatedAt" : productModel.createdAt,
        });
        if(context.mounted){
          BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Product Added Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
          Navigator.pop(context);
        }
      }
      else{
        BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not picked"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    } catch(ex){
      if(context.mounted){
        BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  Stream<List<ProductModel>> getProduct(String? pID){
    return _collectionReference.where('pID',isEqualTo: pID).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ProductModel(
          productId: data['pID'],
          sellerEmail: data['sEmail'],
          productName: data['pName'],
          getProductImage: data['pImage'],
          productDescription: data['pDesc'],
          productCategory: data['pCate'],
          productPrice: data['pPrice'],
          productWidth: data['pWidth'],
          productHeight: data['pHeight'],
          productBreath: data['pBreath'],
          glbFormat: data['glbFormat'],
          fbxFormat: data['fbxFormat'],
          objFormat: data['objFormat'],
          productStatus: data['pStatus'],
          createdAt: data['pCreatedAt'],
          productReviews: data['pReviews']
        );
      }).toList();
    });
  }

  Stream<List<ProductModel>> getAllProduct(){
    return _collectionReference.snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ProductModel(
          productId: data['pID'],
          sellerEmail: data['sEmail'],
          productName: data['pName'],
          getProductImage: data['pImage'],
          productDescription: data['pDesc'],
          productCategory: data['pCate'],
          productPrice: data['pPrice'],
          productWidth: data['pWidth'],
          productHeight: data['pHeight'],
          productBreath: data['pBreath'],
          glbFormat: data['glbFormat'],
          fbxFormat: data['fbxFormat'],
          objFormat: data['objFormat'],
          productStatus: data['pStatus'],
          createdAt: data['pCreatedAt'],
        );
      }).toList();
    });
  }

  Stream<List<ProductModel>> getProductBySeller(String? sellerEmail){
    return _collectionReference.where('sEmail',isEqualTo: sellerEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ProductModel(
          productId: data['pID'],
          sellerEmail: data['sEmail'],
          productName: data['pName'],
          getProductImage: data['pImage'],
          productDescription: data['pDesc'],
          productCategory: data['pCate'],
          productPrice: data['pPrice'],
          productWidth: data['pWidth'],
          productHeight: data['pHeight'],
          productBreath: data['pBreath'],
          glbFormat: data['glbFormat'],
          fbxFormat: data['fbxFormat'],
          objFormat: data['objFormat'],
          productStatus: data['pStatus'],
          createdAt: data['pCreatedAt'],
        );
      }).toList();
    });
  }

  Stream<List<ProductModel>> searchProduct(String? searchQuery, String? category){
    return _collectionReference.where("pCate",isEqualTo: category).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ProductModel(
          productId: data['pID'],
          sellerEmail: data['sEmail'],
          productName: data['pName'],
          getProductImage: data['pImage'],
          productDescription: data['pDesc'],
          productCategory: data['pCate'],
          productPrice: data['pPrice'],
          productWidth: data['pWidth'],
          productHeight: data['pHeight'],
          productBreath: data['pBreath'],
          glbFormat: data['glbFormat'],
          fbxFormat: data['fbxFormat'],
          objFormat: data['objFormat'],
          productStatus: data['pStatus'],
          createdAt: data['pCreatedAt'],
        );
      }).where((product) {
        if (searchQuery == null || searchQuery.isEmpty) {
          return true;
        } else {
          return product.productName!.toLowerCase().contains(searchQuery.toLowerCase());
        }
      }).toList();
    });
  }

  Stream<List<ProductModel>> getProductCategory(String? productCate){
    return _collectionReference.where('pCate',isEqualTo: productCate).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ProductModel(
          productId: data['pID'],
          sellerEmail: data['sEmail'],
          productName: data['pName'],
          getProductImage: data['pImage'],
          productDescription: data['pDesc'],
          productCategory: data['pCate'],
          productPrice: data['pPrice'],
          productWidth: data['pWidth'],
          productHeight: data['pHeight'],
          productBreath: data['pBreath'],
          glbFormat: data['glbFormat'],
          fbxFormat: data['fbxFormat'],
          objFormat: data['objFormat'],
          productStatus: data['pStatus'],
          createdAt: data['pCreatedAt'],
        );
      }).toList();
    });
  }

  void productUpdate(ProductModel productModel, BuildContext context)async{
    try{
      if(productModel.productImage != null){

        UploadTask uploadTask = FirebaseStorage.instance.ref().child("productImages").child(productModel.productId).putFile(productModel.productImage!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String userImage = await taskSnapshot.ref.getDownloadURL();

        _collectionReference.doc(productModel.productId).update({
          "pName" : productModel.productName,
          "pImage" : userImage,
          "pDesc" : productModel.productDescription,
          "pCate" : productModel.productCategory,
          "pPrice" : productModel.productPrice,
          "pWidth" : productModel.productWidth,
          "pHeight" : productModel.productHeight,
          "pBreath" : productModel.productBreath,
          "glbFormat" : productModel.glbFormat,
          "fbxFormat" : productModel.fbxFormat,
          "objFormat" : productModel.objFormat,
          "pReviews" : [],
          "pStatus" : productModel.productStatus,
          "pCreatedAt" : productModel.createdAt,
        });
        if(context.mounted){
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Product Updated Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
          Navigator.pop(context);
        }
      }
      else{
        _collectionReference.doc(productModel.productId).update({
          "pName" : productModel.productName,
          "pDesc" : productModel.productDescription,
          "pCate" : productModel.productCategory,
          "pPrice" : productModel.productPrice,
          "pWidth" : productModel.productWidth,
          "pHeight" : productModel.productHeight,
          "pBreath" : productModel.productBreath,
          "glbFormat" : productModel.glbFormat,
          "fbxFormat" : productModel.fbxFormat,
          "objFormat" : productModel.objFormat,
          "pReviews" : [],
          "pStatus" : productModel.productStatus,
          "pCreatedAt" : productModel.createdAt,
        });
        if(context.mounted){
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Product Updated Successful"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
          Navigator.pop(context);
        }      }
    }  catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }

  }

  void productDelete(String? productID, String? productImage, BuildContext context)async{
    try{
      await FirebaseStorage.instance.refFromURL(productImage!).delete();
      await _collectionReference.doc(productID).delete();

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Product Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }

    }catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

  Future<void> getGlbFormatsWithIDs() async {
    // Fetch all products from the collection
    final snapshot = await _collectionReference.get();

    // Create a list of maps containing productID and glbFormat
    final products = snapshot.docs
        .map((doc) {
      // Check if the document data is null
      if (doc.data() == null) return null;

      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      final productID = doc.id; // Get the product ID (document ID)
      final glbFormat = data['glbFormat'];

      // Filter out unwanted values for glbFormat
      if (glbFormat != null &&
          glbFormat.isNotEmpty &&
          glbFormat != 'Blocked' &&
          glbFormat != 'Pending') {
        return {
          'productID': productID,
          'glbFormat': glbFormat,
        };
      }
      return null;
    })
        .where((product) => product != null)
        .toList();

    print("$products");
  }


  Future<void> addProductReview(
      String productId,
      String userEmail,
      double rating,
      String writtenFeedback,
      BuildContext context,
      ) async {
    try {
      // Reference to the specific document in the 'productData' collection
      DocumentReference productRef =
      FirebaseFirestore.instance.collection('productData').doc(productId);

      // Fetch the current document to check existing reviews
      DocumentSnapshot documentSnapshot = await productRef.get();

      if (documentSnapshot.exists) {
        List<dynamic> reviews = documentSnapshot['pReviews'] ?? [];

        // Check if there's already a review by the same userEmail
        bool reviewExists = reviews.any((review) =>
        review is Map<String, dynamic> && review['userEmail'] == userEmail);

        if (reviewExists) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("You have already reviewed this product."),
                backgroundColor: Colors.orange,
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                behavior: SnackBarBehavior.floating,
              ),
            );
            Navigator.pop(context);
          }
          return; // Exit without adding a new review
        }
      }

      // Prepare the review data
      Map<String, dynamic> reviewData = {
        'userEmail': userEmail,
        'rating': rating,
        'feedback': writtenFeedback,
      };

      // Add the new review to the pReviews array
      await productRef.update({
        'pReviews': FieldValue.arrayUnion([reviewData]),
      });

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Review Added Successfully"),
            backgroundColor: Colors.green,
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            behavior: SnackBarBehavior.floating,
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString()),
            backgroundColor: Colors.red,
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            behavior: SnackBarBehavior.floating,
          ),
        );
        Navigator.pop(context);
      }
    }
  }

}