class CartModel{
  final String cartID;
  final String productID;
  final String userEmail;
  final String sellerEmail;
  final String productName;
  final String productImage;
  final String productQuantity;
  final String productPrice;

  CartModel(
      {
        required this.cartID,
        required this.productID,
        required this.userEmail,
        required this.sellerEmail,
        required this.productName,
        required this.productImage,
        required this.productQuantity,
        required this.productPrice
      });
}