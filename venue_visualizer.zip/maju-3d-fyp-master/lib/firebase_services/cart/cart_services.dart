import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:majumodel/firebase_services/cart/cart_model.dart';

class CartService{
  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("cart");

  Stream<List<CartModel>> getCart(String? userEmail){
    return _collectionReference.where('cEmail', isEqualTo: userEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return CartModel(
          cartID: data['cID'],
          productID: data['pID'],
          userEmail: data['cEmail'],
          sellerEmail: data['sEmail'],
          productName: data['cProduct'],
          productImage:  data['cImage'],
          productPrice: data['cPrice'],
          productQuantity: data['cQuantity'],
        );
      }).toList();
    });
  }

  void addCart(CartModel cartModel, BuildContext context)async{
    try{
      await _collectionReference.doc(cartModel.cartID).set({
        "cID" : cartModel.cartID,
        "cEmail" : cartModel.userEmail,
        "pID" : cartModel.productID,
        "sEmail" : cartModel.sellerEmail,
        "cProduct" : cartModel.productName,
        "cImage" : cartModel.productImage,
        "cPrice" : cartModel.productPrice,
        "cQuantity" : cartModel.productQuantity,
      });
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Item Added Successfully"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void deleteCart(String cartId, BuildContext context)async{
    try{
      await _collectionReference.doc(cartId).delete();

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Item Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  // Calculates the total price of all products in the Cart collection.
  Future<double> calculateTotalPrice(String? userEmail) async {
    if (userEmail == null || userEmail.isEmpty) {
      print('Error: userEmail is null or empty');
      return 0.0;
    }

    try {
      // Reference to the 'Cart' collection filtered by userEmail
      final QuerySnapshot cartSnapshot = await FirebaseFirestore.instance
          .collection("cart")
          .where('cEmail', isEqualTo: userEmail)
          .get();

      // Initialize total price
      double totalPrice = 0.0;

      // Loop through each document in the 'Cart' collection
      for (var doc in cartSnapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;

        // Extract price, defaulting to "0" if missing, then convert to double
        final String priceString = (data['cPrice'] ?? "0").toString();
        final double price = double.tryParse(priceString) ?? 0.0;

        // Add to the overall total
        totalPrice += price;
      }

      return totalPrice;
    } catch (e) {
      print('Error calculating total price: $e');
      return 0.0;
    }
  }

}