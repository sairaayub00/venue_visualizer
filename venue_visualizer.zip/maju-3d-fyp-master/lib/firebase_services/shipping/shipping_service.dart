import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'shipping_model.dart';

class ShippingService{
  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection("shipping");

  Stream<List<ShippingModel>> getShipping(String? userEmail){
    return _collectionReference.where('uEmail', isEqualTo: userEmail).snapshots().map((snapshot){
      return snapshot.docs.map((doc){
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        return ShippingModel(
            shippingID: data['sID'],
            userEmail: data['uEmail'],
            shippingTitle: data['sTitle'],
            shippingAddress: data['sAddress']);
      }).toList();
    });
  }

  void addShipping(ShippingModel shipModel, BuildContext context)async{
    try{
    await _collectionReference.doc('${shipModel.shippingID}').set({
      "sID" : shipModel.shippingID,
      "uEmail" : shipModel.userEmail,
      "sTitle" : shipModel.shippingTitle,
      "sAddress" : shipModel.shippingAddress,
    });
    if(context.mounted){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Shipping Address Added"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      Navigator.pop(context);
    }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void updateShipping(ShippingModel shipModel, BuildContext context)async{
    try{
      await _collectionReference.doc('${shipModel.shippingID}').update({
        "uEmail" : shipModel.userEmail,
        "sTitle" : shipModel.shippingTitle,
        "sAddress" : shipModel.shippingAddress,
      });
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Shipping Address Updated"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something went Wrong"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
      }
    }
  }

  void deleteShipping(String shipId, BuildContext context)async{
    try{
      await _collectionReference.doc(shipId).delete();

      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Address Deleted Successfully"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
    catch(ex){
      if(context.mounted){
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Something went wrong $ex"),backgroundColor: Colors.red, margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
        Navigator.pop(context);
      }
    }
  }

}