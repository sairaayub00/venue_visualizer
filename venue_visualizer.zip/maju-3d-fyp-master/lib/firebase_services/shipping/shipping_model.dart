class ShippingModel{
  final String shippingID;
  final String userEmail;
  final String shippingTitle;
  final String shippingAddress;

  ShippingModel(
      {
        required this.shippingID,
        required this.userEmail,
        required this.shippingTitle,
        required this.shippingAddress
      });
}