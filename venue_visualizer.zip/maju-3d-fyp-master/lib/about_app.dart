import 'package:flutter/material.dart';

class AboutApplicationScreen extends StatelessWidget {
  const AboutApplicationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About the Application'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Application Overview
            const Text(
              'Furniture AR E-Commerce Application',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8.0),
            const Text(
              'Transform your online furniture shopping experience with high-quality product listings and augmented reality (AR) features. Visualize furniture in your space, enjoy secure transactions, and receive personalized recommendations through a user-friendly interface.',
            ),
            const SizedBox(height: 16.0),

            // Key Features
            const Text(
              'Key Features:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8.0),
            ..._buildFeatureItems([
              'AR Previews: Virtually place furniture in your room.',
              'Secure Transactions: Firebase-backed data security and third-party payment gateways.',
              'Personalized Experience: Data-driven recommendations.',
              'Transparent Policies: Clear payment, refund, and return terms.',
              'Real-Time Support: Dedicated customer support channels.',
            ]),
            const SizedBox(height: 16.0),

            // Responsibilities Section
            const Text(
              'Responsibilities of Key Sections:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8.0),
            ..._buildResponsibilityItems({
              'Introduction': 'Explains the app’s purpose, features, and terms of use.',
              'Data Privacy': 'Details data collection, secure storage in Firebase, and user privacy protection.',
              'User Responsibilities': 'Covers account confidentiality, accurate information, proper use, and AR compatibility.',
            }),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildFeatureItems(List<String> features) {
    return features.map((feature) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4.0),
        child: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.green),
            const SizedBox(width: 8.0),
            Flexible(
              child: Text(feature),
            ),
          ],
        ),
      );
    }).toList();
  }

  List<Widget> _buildResponsibilityItems(Map<String, String> responsibilities) {
    return responsibilities.entries.map((entry) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              entry.key,
              style: const TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4.0),
            Text(entry.value),
          ],
        ),
      );
    }).toList();
  }
}
