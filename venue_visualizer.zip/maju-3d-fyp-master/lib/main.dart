import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/main_navbar_bloc/navbar_bloc.dart';
import 'package:majumodel/bloc/password/password_check_bloc.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_bloc.dart';
import 'package:majumodel/bloc/product_tab/product_tab_bloc.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_options.dart';
import 'package:majumodel/views/credentials_screen/splash_screen.dart';


void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return MultiBlocProvider(providers: [
      BlocProvider<NavbarBloc>(create: (context) => NavbarBloc(),),
      BlocProvider<ProductQuantityBloc>(create: (context) => ProductQuantityBloc(),),
      BlocProvider<ProductTabBloc>(create: (context) => ProductTabBloc(),),
      BlocProvider<PasswordCheckBloc>(create: (context) => PasswordCheckBloc(),),
      BlocProvider<LoaderBloc>(create: (context) => LoaderBloc(),),
    ], child: MaterialApp(
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme()
      ),
      title: 'Venue Visualizer',
    ));
  }
}
