
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../views/ar/ar_screen.dart';

class FileService {
  /// Downloads a file from the given URL and saves it with the provided custom file name.
  Future<void> downloadFile(String url, String customFileName, BuildContext context) async {
    try {
      // Encode the URL to handle any special characters
      final encodedUrl = Uri.encodeFull(url);

      // Get the directory to save the file
      final Directory directory = await getApplicationDocumentsDirectory();
      final String filePath = '${directory.path}/$customFileName.glb';

      // Check if the file already exists
      final File file = File(filePath);
      if (await file.exists()) {
        print('File already exists at: $filePath');
        if (context.mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ARView(filePath: filePath),
            ),
          );
        }
        return; // Exit the function as the file already exists
      }

      // Download the file using http
      final http.Response response = await http.get(Uri.parse(encodedUrl));

      if (response.statusCode == 200) {
        // Save the file to the specified path
        await file.writeAsBytes(response.bodyBytes);

        print('File downloaded to: $filePath');
        if (context.mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ARView(filePath: filePath),
            ),
          );
        }
      } else {
        print('Failed to download file. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error downloading file: $e');
    }
  }
}

