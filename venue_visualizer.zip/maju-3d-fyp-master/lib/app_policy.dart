import 'package:flutter/material.dart';

class AppPolicyPage extends StatelessWidget {
  const AppPolicyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Policy'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle('1. Introduction'),
            _buildSectionContent(
              'Welcome to our Furniture AR E-Commerce Application (the "App"). This App is designed to provide users with an enhanced shopping experience by offering high-quality furniture and home decor products, along with a virtual reality (VR) preview feature. This policy outlines the terms of use, privacy practices, and user responsibilities when using the App. By using the App, you agree to the terms stated below.',
            ),
            _buildSectionTitle('2. Data Collection and Privacy'),
            _buildSectionContent(
              'We are committed to protecting your privacy. The App uses Firebase as its backend to manage user data securely. The following data may be collected and stored:\n\n- Personal Information: Name, email address, contact number, and delivery address (provided during account registration and checkout).\n- Usage Data: Information about how you interact with the App, such as viewed products and search preferences.\n- Payment Information: Securely processed via third-party payment gateways; we do not store credit/debit card details.\n- Device Information: Data such as device type, operating system, and unique identifiers for app functionality and analytics.\n\nAll data is stored securely and used only for improving user experience, processing transactions, and fulfilling orders. We do not share your personal information with third parties except as required to provide services or comply with the law.',
            ),
            _buildSectionTitle('3. User Responsibilities'),
            _buildSectionContent(
              '- Account Security: Maintain the confidentiality of your login credentials. Report any unauthorized account activity immediately.\n- Accurate Information: Provide accurate and up-to-date information during registration and checkout.\n- Prohibited Actions: Do not misuse the App for illegal activities, fraudulent transactions, or unauthorized access to other user accounts.\n- Device Compatibility: Ensure your device meets the technical requirements to use the VR feature effectively.',
            ),
            _buildSectionTitle('4. Product Information and Virtual Reality (VR) Preview'),
            _buildSectionContent(
              '- Product Descriptions: While we strive for accuracy, product descriptions, colors, and dimensions may vary slightly from the actual items.\n- VR Feature: The VR preview provides an estimated visual representation of the product in your space. For the best experience, use a device compatible with augmented reality features.\n- Disclaimer: The VR preview is for illustrative purposes only and may not reflect the exact product scale or appearance.',
            ),
            _buildSectionTitle('5. Payment and Refund Policy'),
            _buildSectionContent(
              '- Payment Methods: We accept online payments through secure payment gateways. Ensure that your payment information is accurate.\n- Refunds: Refunds are processed for eligible returns as per our return policy. Refunds may take up to 7 business days to reflect in your account.\n- Order Cancellation: You can cancel orders within 24 hours of placement unless the order has already been processed.',
            ),
            _buildSectionTitle('6. Return and Exchange Policy'),
            _buildSectionContent(
              '- Eligibility: Products can be returned or exchanged within 7 days of delivery if they are defective, damaged, or incorrect.\n- Condition: Items must be returned in their original packaging and unused condition.\n- Process: Contact customer support via the App to initiate a return or exchange.',
            ),
            _buildSectionTitle('7. Liability Disclaimer'),
            _buildSectionContent(
              'We strive to ensure the App operates smoothly and securely. However, we are not liable for:\n\n- Any temporary unavailability of the App due to maintenance or technical issues.\n- Loss or damage resulting from the improper use of the App or VR feature.\n- Unauthorized access to your account caused by your negligence.',
            ),
            _buildSectionTitle('8. Changes to Policy'),
            _buildSectionContent(
              'We may update this policy periodically. Users will be notified of significant changes through the App or via email. Continued use of the App after such updates constitutes acceptance of the revised policy.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 16.0, bottom: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18.0,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSectionContent(String content) {
    return Text(
      content,
      style: const TextStyle(
        fontSize: 16.0,
        height: 1.5,
      ),
    );
  }
}

