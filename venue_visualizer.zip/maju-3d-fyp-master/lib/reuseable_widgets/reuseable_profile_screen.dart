import 'dart:ui';

import 'package:flutter/material.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomProfileCard extends StatelessWidget {
  const CustomProfileCard({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userProfile,
    required this.screenDirector,
  });

  final String userName;
  final String userEmail;
  final String userProfile;
  final VoidCallback screenDirector;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.16,
      padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
      decoration: BoxDecoration(
          border: Border.all(color: appColorPrimary,width: 2),
         borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: [
            Colors.brown.withOpacity(0.6),
            Colors.brown.withOpacity(0.4),
          ]),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.shade300,
                spreadRadius: 1,
                blurRadius: 10
            )
          ]
      ),
      child: SizedBox(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 0.16,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(userName,style: TextStyle(
                      fontSize: SizeConfig.textMultiplier * 2.5,
                      color: appColorPrimary,
                      fontWeight: FontWeight.w600
                  ),),
                  Text(userEmail,style: TextStyle(
                      fontSize: SizeConfig.textMultiplier * 1.8,
                      color: appColorPrimary,
                      fontWeight: FontWeight.w400
                  ),),
                ],
              ),

              Column(
                children: [
                  CircleAvatar(
                    radius: 35,
                    backgroundImage: AssetImage(userProfile),
                    backgroundColor: appColorAccent,
                  ),

                  SizedBox(height: SizeConfig.heightMultiplier * 1,),

                  GestureDetector(
                    onTap: screenDirector,
                    child: SizedBox(
                      child: Text('View Profile',style: TextStyle(
                          fontSize: SizeConfig.textMultiplier * 1.5,
                          color: appColorAccent,
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
