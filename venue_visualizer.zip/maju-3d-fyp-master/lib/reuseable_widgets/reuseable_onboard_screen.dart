import 'package:flutter/material.dart';
import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomOnBoardScreen extends StatelessWidget {
  const CustomOnBoardScreen({
    super.key,
    required this.title,
    required this.subTitle,
    required this.image,
    this.action
  });

  final String title;
  final String subTitle;
  final String image;
  final VoidCallback? action;
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [


        // Main Container
        Container(
          width: SizeConfig.screenWidth * 1,
          height: SizeConfig.screenHeight * 1,
          decoration: BoxDecoration(
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(image))
          ),
        ),

        Positioned(
          bottom: 40,
          child: GestureDetector(
            onTap: action,
            child: Container(
              width: SizeConfig.screenWidth * 0.95,
              height: SizeConfig.screenHeight * 0.2,
              margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14,vertical: 20),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.transparent
              ),
              child: SizedBox(
                width: SizeConfig.screenWidth * 1,
                height: SizeConfig.screenHeight * 0.2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: SizeConfig.heightMultiplier * 2,
                    ),
                    Text(title,style: TextStyle(
                        color: appColorPrimary,
                        fontSize: SizeConfig.textMultiplier * 3,
                        fontWeight: FontWeight.w600
                    ),),
                    SizedBox(
                      height: SizeConfig.heightMultiplier * 1,
                    ),
                    Text(subTitle,style: TextStyle(
                        color: appColorPrimary,
                        fontSize: SizeConfig.textMultiplier * 1.5,
                        fontWeight: FontWeight.w400
                    ),),
                  ],
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
}
