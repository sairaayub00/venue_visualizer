import 'package:flutter/material.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    super.key,
    required this.hintText,
    required this.fieldIcon,
    required this.errorText,
    required this.fieldController,
  });

  final String hintText;
  final String errorText;
  final IconData fieldIcon;
  final TextEditingController fieldController;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 1,
      padding: const EdgeInsets.all(6.0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.transparent
      ),
      child: TextFormField(
        controller: fieldController,
        validator: (val){
          if(val == null || val == " " || val.isEmpty){
            return errorText;
          } else{
            return null;
          }
        },
        style: TextStyle(
          color: appColorPrimary
        ),
        decoration: InputDecoration(
            prefixIcon: Icon(fieldIcon, color: appColorPrimary,),
            hintText: hintText,
            hintStyle: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: SizeConfig.textMultiplier * 1.8,
                color: appColorPrimary
            ),
            border: UnderlineInputBorder(
              borderSide: BorderSide(color: appColorPrimary)
            ),
            focusedBorder: InputBorder.none
        ),
      ),
    );
  }
}
