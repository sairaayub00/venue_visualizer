import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomProductContainer extends StatelessWidget {
  const CustomProductContainer({
    super.key,
    required this.productImage,
    required this.productName,
    required this.productSize,
    required this.productPrice,
  });

  final String productImage;
  final String productName;
  final String productSize;
  final String productPrice;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 0.5,
      height: SizeConfig.screenHeight * 0.35,
      margin: const EdgeInsets.only(right: 10,top: 6, bottom: 6),
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
          color: appColorPrimary,
          borderRadius: BorderRadius.circular(20),
          boxShadow:[
            BoxShadow(
                color: appColorSecondary.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 6
            )
          ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // Image Container
          Container(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.23,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(productImage))
            ),
          ),

          SizedBox(height: SizeConfig.heightMultiplier * 1,),

          Text(productName,style: TextStyle(
              color: appColorSecondary,
              fontSize: SizeConfig.textMultiplier * 2,
              fontWeight: FontWeight.w600
          ),maxLines: 1, overflow: TextOverflow.ellipsis,),

          SizedBox(height: SizeConfig.heightMultiplier * 0.2,),

          Text(productSize,style: TextStyle(
              color: appColorSecondary.withOpacity(0.4),
              fontSize: SizeConfig.textMultiplier * 1.6,
              fontWeight: FontWeight.w600
          ),),

          SizedBox(height: SizeConfig.heightMultiplier * 0.2,),

          Text('$productPrice PKR',style: TextStyle(
              color: appColorSecondary,
              fontSize: SizeConfig.textMultiplier * 1.6,
              fontWeight: FontWeight.w600
          ),),

        ],
      ),
    );
  }
}
