import 'package:flutter/material.dart';
import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomCategoryCard extends StatelessWidget {
  const CustomCategoryCard({
    super.key,
    required this.produuctImage,
    required this.productCategoryName,
    required this.productUnit,
    required this.action
  });

  final String produuctImage;
  final String productCategoryName;
  final String productUnit;
  final VoidCallback action;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.26,
      padding: const EdgeInsets.all(6.0),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: appColorPrimary,
          boxShadow: [
            BoxShadow(
                color: appColorSecondary.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 6
            )
          ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.16,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(produuctImage))
            ),
          ),

          SizedBox(height: SizeConfig.heightMultiplier * 1.4,),

          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(productCategoryName,style: TextStyle(
                        color: appColorSecondary,
                        fontSize: SizeConfig.textMultiplier * 2,
                        fontWeight: FontWeight.w600
                    ),),

                    Text(productUnit,style: TextStyle(
                        color:appColorAccent,
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w600
                    ),),
                  ],
                ),

                TextButton(onPressed: action, child: Text('View All',style: TextStyle(
                    color:appColorAccent,
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    fontWeight: FontWeight.w600
                ),),)
              ],
            ),
          )
        ],
      ),
    );
  }
}
