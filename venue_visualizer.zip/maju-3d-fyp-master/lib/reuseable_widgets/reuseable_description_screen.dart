import 'package:flutter/material.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomDescriptionWidget extends StatelessWidget {
  const CustomDescriptionWidget({
    super.key,
    required this.productDescription,
    required this.productWidth,
    required this.productHeight,
    required this.productBreath,
    required this.productPrice,
  });
  final String productDescription;
  final String productWidth;
  final String productHeight;
  final String productBreath;
  final String productPrice;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(left: 14, top: 10),
          child: Text('Description:',style: TextStyle(
              fontSize: SizeConfig.textMultiplier * 2.5,
              color: appColorSecondary,
              fontWeight: FontWeight.w600
          ),),
        ),

        SizedBox(height: SizeConfig.heightMultiplier * 1,),

        // Description

        Container(
          margin: const EdgeInsets.symmetric(horizontal: 14),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: SizeConfig.screenHeight * 0.06,
              minWidth: SizeConfig.screenWidth * 1,
              maxHeight: SizeConfig.screenHeight * 0.2,
              maxWidth: SizeConfig.screenWidth * 1,
            ),
            child: SingleChildScrollView(
              physics: const ScrollPhysics(),
              child: Text(productDescription,style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 1.5,
                  color: appColorSecondary,
                  fontWeight: FontWeight.w400
              ),),
            ),
          ),
        ),

        // Measurement Heading

        Container(
          margin: const EdgeInsets.only(left: 14, top: 2),
          child: Text('Measurements:',style: TextStyle(
              fontSize: SizeConfig.textMultiplier * 2.5,
              color: appColorSecondary,
              fontWeight: FontWeight.w600
          ),),
        ),

        SizedBox(height: SizeConfig.heightMultiplier * 1,),

        // Measurements

        Container(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.06,
            margin: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [

                Column(
                  children: [
                    Text('Width',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 2,
                        color: appColorSecondary.withOpacity(0.6),
                        fontWeight: FontWeight.w600
                    ),),
                    Text('$productWidth Sq/ft',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        color: appColorSecondary,
                        fontWeight: FontWeight.w400
                    ),),
                  ],
                ),
                Column(
                  children: [
                    Text('Height',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 2,
                        color: appColorSecondary.withOpacity(0.6),
                        fontWeight: FontWeight.w600
                    ),),
                    Text('$productHeight Sq/ft',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        color: appColorSecondary,
                        fontWeight: FontWeight.w400
                    ),),
                  ],
                ),
                Column(
                  children: [
                    Text('Breath',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 2,
                        color: appColorSecondary.withOpacity(0.6),
                        fontWeight: FontWeight.w600
                    ),),
                    Text('$productBreath Sq/ft',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        color: appColorSecondary,
                        fontWeight: FontWeight.w400
                    ),),
                  ],
                ),

              ],
            )
        ),

        Container(
          margin: const EdgeInsets.only(left: 14),
          child: Text('Pricing:',style: TextStyle(
              fontSize: SizeConfig.textMultiplier * 2.5,
              color: appColorSecondary,
              fontWeight: FontWeight.w600
          ),),
        ),

        Container(
          margin: const EdgeInsets.only(left: 14),
          child: Text('$productPrice / Unit',style: TextStyle(
              fontSize: SizeConfig.textMultiplier * 1.5,
              color: appColorSecondary.withOpacity(0.6),
              fontWeight: FontWeight.w600
          ),),
        ),
      ],
    );
  }
}
