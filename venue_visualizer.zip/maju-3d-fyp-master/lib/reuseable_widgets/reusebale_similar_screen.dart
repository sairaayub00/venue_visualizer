import 'package:flutter/material.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/views/main_navbar/description_screen.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomSimilarWidget extends StatelessWidget {
  const CustomSimilarWidget({
    super.key,
    required this.getProductCategory,
    required this.getProductID,
  });

  final String getProductCategory;
  final String getProductID;

  @override
  Widget build(BuildContext context) {
    final ProductService productService = ProductService();
    return SizedBox(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.4,
      child: StreamBuilder(stream: productService.getProductCategory(getProductCategory), builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting){
          return const Center(child: Text('Getting Similar Products'),);
        } else if (snapshot.hasData){
          return snapshot.data!.length != 0 ?
          ListView.builder(
            physics: const ScrollPhysics(),
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemCount: snapshot.data!.length >= 3 ? 3 : snapshot.data!.length,
            itemBuilder: (context, index) {
              ProductModel data = snapshot.data![index];
              String pID = data.productId;
              String pName = data.productName!;
              String pImage = data.getProductImage!;
              String pCate = data.productCategory!;
              String pPrice = data.productPrice!;
                return GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => DescriptionScreen(productID: pID),));
                  },
                  child: Container(
                    width: SizeConfig.screenWidth * 1,
                    height: SizeConfig.screenHeight * 0.14,
                    margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
                    padding: const EdgeInsets.all(6.0),
                    decoration: BoxDecoration(
                        color: appColorPrimary,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                              color: appColorSecondary.withOpacity(0.4),
                              spreadRadius: 1,
                              blurRadius: 6
                          )
                        ]
                    ),
                    child: Row(
                      children: [
                        // Image Container
                        Container(
                          width: SizeConfig.screenWidth * 0.3,
                          height: SizeConfig.screenHeight * 0.14,
                          decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(14),
                              image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: NetworkImage(pImage))
                          ),
                        ),

                        SizedBox(width: SizeConfig.widthMultiplier * 2,),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(pName,style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.8,
                                color: appColorSecondary,
                                fontWeight: FontWeight.w600
                            ),),
                            SizedBox(height: SizeConfig.heightMultiplier * 1,),
                            Text(pCate,style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.4,
                                color: appColorSecondary,
                                fontWeight: FontWeight.w600
                            ),),
                            SizedBox(height: SizeConfig.heightMultiplier * 1,),
                            Text('$pPrice / Unit',style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.4,
                                color: appColorSecondary.withOpacity(0.6),
                                fontWeight: FontWeight.w400
                            ),),
                          ],
                        )
                      ],
                    ),
                  ),
                );

            },) :
          const Center(child: Text('No Similar Product Found'),);
        } else{
          return const Center(child: Icon(Icons.error,color: Colors.red,),);
        }
      },),
    );
  }
}
