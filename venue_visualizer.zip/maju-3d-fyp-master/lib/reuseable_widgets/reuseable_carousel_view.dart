import 'dart:ui';

import 'package:flutter/material.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomCarouselView extends StatelessWidget {
  const CustomCarouselView({
    super.key,
    required this.carouselImages,
  });

  final String carouselImages;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [

        Container(
          width: SizeConfig.screenWidth * 1,
          height: SizeConfig.screenHeight * 0.24,
          alignment: Alignment.bottomLeft,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(carouselImages))
          ),
        ),

        Positioned(
          bottom: 20,
          left: 10,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX:40 ,sigmaY: 40),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                decoration: BoxDecoration(
                    border: Border.all(color: appColorPrimary.withOpacity(0.4), width: 1),
                    borderRadius: BorderRadius.circular(14)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Avail 50% Sale',style: TextStyle(
                        color: appColorPrimary,
                        fontSize: SizeConfig.textMultiplier * 2,
                        fontWeight: FontWeight.w600
                    ),),
                    Text('All on Spring Collection till 28 Dec 2024',style: TextStyle(
                        color: appColorPrimary,
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w400
                    ),),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
