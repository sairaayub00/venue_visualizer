import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';

import '../constants/app_color.dart';
import '../constants/size_config.dart';

class CustomReviewWidget extends StatelessWidget {
  const CustomReviewWidget({
    super.key,
    required this.reviews
  });

  final List<dynamic> reviews;

  @override
  Widget build(BuildContext context) {
    
    UserServices userServices = UserServices();
    
    return Container(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.4,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      child: reviews.length != 0 ? ListView.builder(
        physics: const ScrollPhysics(),
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: reviews.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading:  StreamBuilder(stream: userServices.getUser(reviews[index]["userEmail"]), builder: (context, snapshot) {
              if(snapshot.connectionState == ConnectionState.waiting){
                return const Text("Loading Review");
              }
              else if(snapshot.hasData){
                UserModel data = snapshot.data![0];
                return CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage(data.getImage!),
                );
              }
              else{
                return const Icon(Icons.error,color: Colors.red,);
              }
            },),
            title:  StreamBuilder(stream: userServices.getUser(reviews[index]["userEmail"]), builder: (context, snapshot) {
              if(snapshot.connectionState == ConnectionState.waiting){
                return const Text("Loading Review");
              }
              else if(snapshot.hasData){
                UserModel data = snapshot.data![0];
                return Text(data.userName!,style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w800
                ),);
              }
              else{
                return const Icon(Icons.error,color: Colors.red,);
              }
            },),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(reviews[index]["feedback"],style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.3,
                    color: appColorSecondary.withOpacity(0.6),
                    fontWeight: FontWeight.w600
                ),),
                SizedBox(height: SizeConfig.heightMultiplier * 1,),
                RatingBarIndicator(
                  rating: double.parse(reviews[index]["rating"].toString()),
                  itemBuilder: (context, index) => const Icon(
                    Icons.star,
                    color: Colors.amber,
                  ),
                  itemCount: 5,
                  itemSize: 14,
                  direction: Axis.horizontal,
                ),
              ],
            ),
          );
        },) : const Center(child: Text('No Review Found'),),
    );
  }
}