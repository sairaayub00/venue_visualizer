import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/views/main_navbar/sub_product_screen.dart';
import '../../reuseable_widgets/reuseable_category_screen.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {

  final searchController = TextEditingController();

  final List<String> productImage = [
    'https://images.pexels.com/photos/4345158/pexels-photo-4345158.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/7214333/pexels-photo-7214333.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/6707631/pexels-photo-6707631.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/20337842/pexels-photo-20337842/free-photo-of-a-soft-light-colored-sofa-and-a-wooden-chair-in-a-modern-living-room.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/1090638/pexels-photo-1090638.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/6692136/pexels-photo-6692136.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  ];

  final List<String> productCategoryName = [
    'Modern Minimal Chairs',
    'Modern Wooden Stylish Beds',
    'Unique Flasks / Vases',
    'Minimal Sofa Set',
    'Stylish Wooden Home Decor',
    'Home Crockery'
  ];

  final List<String> productUnit = ['100 Units', '50 Units', '200 Units', '10 Units', '20 Units', '500 Units'];

  final List<String> productCate = ["Chair", "Bed", "Vase", "Sofa", "Home Decor", "Home Crockery"];

  List<int> filteredIndexes = [];

  @override
  void initState() {
    super.initState();
    // Initialize with all indexes
    filteredIndexes = List.generate(productCategoryName.length, (index) => index);
    searchController.addListener(_filterProducts);
  }

  void _filterProducts() {
    String query = searchController.text.toLowerCase();

    setState(() {
      filteredIndexes = List.generate(productCategoryName.length, (index) => index).where((index) {
        return productCategoryName[index].toLowerCase().contains(query) ||
            productCate[index].toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    searchController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SingleChildScrollView(
        physics: const ScrollPhysics(),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [

              SizedBox(height: SizeConfig.heightMultiplier * 6,),


              TextFormField(
                controller: searchController,
                validator: (val){
                  if(val == null || val == " " || val.isEmpty){
                    return 'Field not be empty';
                  } else{
                    return null;
                  }
                },
                style: TextStyle(
                    color: appColorSecondary
                ),
                decoration: InputDecoration(
                    prefixIcon: Icon(Iconsax.search_favorite, color: appColorSecondary,),
                    hintText: 'Search Items',
                    hintStyle: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: SizeConfig.textMultiplier * 1.8,
                        color: appColorSecondary
                    ),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(color: appColorPrimary)
                    ),
                    focusedBorder: InputBorder.none
                ),
              ),

              SizedBox(height: SizeConfig.heightMultiplier * 2,),


              ListView.builder(
                itemCount: filteredIndexes.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                scrollDirection: Axis.vertical,
                itemBuilder: (context, index) {
                  int originalIndex = filteredIndexes[index];
                return CustomCategoryCard(
                  produuctImage: productImage[originalIndex],
                  productCategoryName: productCategoryName[originalIndex],
                  productUnit: productUnit[originalIndex],
                  action: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SubProductScreen(productName: productCategoryName[originalIndex], productImage: productImage[originalIndex],productCategory: productCate[originalIndex],),));
                  },
                );
              },)

            ],
          ),
        ),
      ),
    );
  }
}

