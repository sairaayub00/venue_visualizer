import 'dart:io';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/about_app.dart';
import 'package:majumodel/app_policy.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/feedback/feedback_model.dart';
import 'package:majumodel/firebase_services/feedback/feedback_services.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/reuseable_widgets/reuseable_product_container.dart';
import 'package:majumodel/views/main_navbar/description_screen.dart';
import 'package:uuid/uuid.dart';
import '../../constants/app_color.dart';
import '../../firebase_services/user/user_model.dart';
import '../../firebase_services/user/user_services.dart';
import '../../reuseable_widgets/reuseable_carousel_view.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {


  List<String> carouselImages = [
    'https://images.pexels.com/photos/6492402/pexels-photo-6492402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/6707628/pexels-photo-6707628.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/12322849/pexels-photo-12322849.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    'https://images.pexels.com/photos/6480201/pexels-photo-6480201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'];

  final UserServices userServices = UserServices();
  String userEmail = '';

  final ProductService _productService = ProductService();

  final TextEditingController feedbackController = TextEditingController();

  final FeedbackServices _feedbackServices = FeedbackServices();

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    feedbackController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) => exit(0),
      child: Scaffold(
          backgroundColor: appColorPrimary,
        drawer: Drawer(
          backgroundColor: appColorPrimary,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ListTile(
                onTap: (){
                  showDialog(context: context, builder: (context) {
                    return AlertDialog(
                      content: Container(
                        width: SizeConfig.screenWidth * 1,
                        height: SizeConfig.screenHeight * 0.4,
                        margin: const EdgeInsets.symmetric(horizontal: 2,vertical: 2),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                            Center(child: Text('Give Feedback',style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.8,
                                fontWeight: FontWeight.w600,
                                color: appColorSecondary
                            ),),),

                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                            TextFormField(
                          controller: feedbackController,
                          validator: (val){
                            if(val == null || val == " " || val.isEmpty){
                              return 'Text is Required';
                            } else{
                              return null;
                            }
                          },
                              maxLines: 3,
                              maxLength: 500,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(500)
                              ],
                          style: TextStyle(
                              color: appColorSecondary
                          ),
                          decoration: InputDecoration(
                              prefixIcon: Icon(Iconsax.edit, color: appColorSecondary.withOpacity(0.4),),
                              hintText: '\nWrite your words',
                              hintStyle: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: SizeConfig.textMultiplier * 1.8,
                                  color: appColorSecondary.withOpacity(0.4)
                              ),
                              border: UnderlineInputBorder(
                                  borderSide: BorderSide(color: appColorPrimary)
                              ),
                              focusedBorder: InputBorder.none
                          ),
                        ),

                            SizedBox(height: SizeConfig.heightMultiplier * 6,),

                            Align(
                              alignment: Alignment.bottomRight,
                              child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                  ),
                                  onPressed: (){
                                    _feedbackServices.addFeedback(FeedbackModel(
                                        const Uuid().v1(),
                                        userEmail,
                                        feedbackController.text.toString()), context);
                                  }, child: Text('Submit',style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.6,
                                fontWeight: FontWeight.w600,
                                color: appColorPrimary
                              ),)),
                            )

                          ],
                        ),
                      ),
                    );
                  },);
                },
                leading: const Icon(Iconsax.edit),
                title: const Text('Give Feedback'),
              ),
              ListTile(
                onTap: (){
                 Navigator.push(context, MaterialPageRoute(builder: (context) => const AppPolicyPage(),));
                },
                leading: const Icon(Iconsax.document_1),
                title: const Text('App Policy'),
              ),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const AboutApplicationScreen(),));
                },
                leading: const Icon(Iconsax.medal_star),
                title: const Text('About Application'),
              ),
              ListTile(
                onTap: (){
                  userServices.userLogout(context);
                },
                leading: const Icon(Iconsax.logout),
                title: const Text('Logout'),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                SizedBox(height: SizeConfig.heightMultiplier * 2,),

               StreamBuilder(stream: userServices.getUser(userEmail), builder: (context, snapshot) {
                 if(snapshot.connectionState == ConnectionState.waiting) {
                   return Center(child: Text('Loading',style: TextStyle(
                       color: appColorPrimary,
                       fontSize: SizeConfig.textMultiplier * 3,
                       fontWeight: FontWeight.w600
                   ),),);
                 }
                 else if(snapshot.hasData){
                   return ListView.builder(
                     itemCount: snapshot.data!.length,
                     shrinkWrap: true,
                     itemBuilder: (context, index) {
                     UserModel userModel = snapshot.data![index];
                     final String? userName = userModel.userName;
                     final String? userEmail = userModel.userEmail;
                     final String? getImage = userModel.getImage;

                     return Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       crossAxisAlignment: CrossAxisAlignment.start,
                       children: [
                         Builder(builder: (context) {
                           return IconButton(onPressed: (){
                             Scaffold.of(context).openDrawer();
                           }, icon: const Icon(Iconsax.category));

                         },),
                         Column(
                           mainAxisAlignment: MainAxisAlignment.center,
                           children: [
                             Text(userName!,style: TextStyle(
                                 color: appColorSecondary.withOpacity(0.6),
                                 fontSize: SizeConfig.textMultiplier * 1.8,
                                 fontWeight: FontWeight.w600
                             ),),
                             Text(userEmail!,style: TextStyle(
                                 color: appColorSecondary.withOpacity(0.4),
                                 fontSize: SizeConfig.textMultiplier * 1.4,
                                 fontWeight: FontWeight.w600
                             ),),
                           ],
                         ),

                         CircleAvatar(
                           radius: 20,
                           backgroundImage: NetworkImage(getImage!),
                         ),
                       ],
                     );
                   },);
                 }
                 else{
                   return const Center(child: Icon(Icons.error,color: Colors.red,));
                 }
               },),

                CarouselSlider(items: List.generate(carouselImages.length, (index) => CustomCarouselView(carouselImages: carouselImages[index]),
                ), options: CarouselOptions(
                  autoPlay: true,
                  viewportFraction: 1,
                  enlargeCenterPage: true,
                )),

                SizedBox(height: SizeConfig.heightMultiplier * 2,),


                Text('Top Viewed',style: TextStyle(
                    color: appColorSecondary,
                    fontSize: SizeConfig.textMultiplier * 2,
                    fontWeight: FontWeight.w800
                ),),


                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                // Product Container

                SizedBox(
                  width: SizeConfig.screenWidth * 1,
                  height: SizeConfig.screenHeight * 0.36,
                  child: StreamBuilder(stream: _productService.getAllProduct(), builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return const Center(child: Text('Loading Products'),);
                    }
                    else if(snapshot.hasData){
                      return snapshot.data!.length != 0 ? ListView.builder(
                        physics: const ScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        itemCount: 5,
                        itemBuilder: (context, index) {
                          ProductModel pData = snapshot.data![index];
                          String productID = pData.productId;
                          String productName = pData.productName!;
                          String productImage = pData.getProductImage!;
                          String productWidth = pData.productWidth!;
                          String productHeight = pData.productHeight!;
                          String productPrice = pData.productPrice!;
                          String productStatus = pData.productStatus!;
                          return productStatus == "Live" ? GestureDetector(
                            onTap: (){
                              Navigator.push(context,  MaterialPageRoute(builder: (context) =>  DescriptionScreen(productID: productID,),));
                            },
                            child: CustomProductContainer(
                                productImage: productImage,
                                productName: productName,
                                productSize: 'Size $productWidth ft / $productHeight ft',
                                productPrice: productPrice),
                          ) : Container();
                        },) : const Center(child: Text('No Product Found'),);
                    }
                    else{
                      return const Center(child: Icon(Icons.error,color: Colors.red,),);
                    }
                  },)
                ),


                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                Text('Our Products',style: TextStyle(
                    color: appColorSecondary,
                    fontSize: SizeConfig.textMultiplier * 2,
                    fontWeight: FontWeight.w800
                ),),


                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                // Product Container

                SizedBox(
                    width: SizeConfig.screenWidth * 1,
                    height: SizeConfig.screenHeight * 0.36,
                    child: StreamBuilder(stream: _productService.getAllProduct(), builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return const Center(child: Text('Loading Products'),);
                      }
                      else if(snapshot.hasData){
                        return snapshot.data!.length != 0 ? ListView.builder(
                          physics: const ScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: true,
                          itemCount: 5,
                          itemBuilder: (context, index) {
                            ProductModel pData = snapshot.data![index];
                            String productID = pData.productId;
                            String productName = pData.productName!;
                            String productImage = pData.getProductImage!;
                            String productWidth = pData.productWidth!;
                            String productHeight = pData.productHeight!;
                            String productPrice = pData.productPrice!;
                            String productStatus = pData.productStatus!;
                            return productStatus == "Live" ? GestureDetector(
                              onTap: (){
                                Navigator.push(context,  MaterialPageRoute(builder: (context) =>  DescriptionScreen(productID: productID,),));
                              },
                              child: CustomProductContainer(
                                  productImage: productImage,
                                  productName: productName,
                                  productSize: 'Size $productWidth ft / $productHeight ft',
                                  productPrice: productPrice),
                            ) : Container();
                          },): const Center(child: Text('No Product found'),);
                      }
                      else{
                        return const Center(child: Icon(Icons.error,color: Colors.red,),);
                      }
                    },)
                ),

                SizedBox(height: SizeConfig.heightMultiplier * 8,),

              ],
            ),
          ),
        )
      ),
    );
  }
}



