import 'package:flutter/material.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/card/card_services.dart';
import 'package:majumodel/firebase_services/cart/cart_services.dart';
import 'package:majumodel/firebase_services/order/order_model.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/shipping/shipping_model.dart';
import 'package:majumodel/firebase_services/shipping/shipping_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:uuid/uuid.dart';

import '../../firebase_services/card/card_model.dart';
import '../../firebase_services/cart/cart_model.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {

  final CartService _cartService = CartService();
  final OrderService _orderService = OrderService();
  final ShippingService _shippingService = ShippingService();
  final CardService _cardService = CardService();


  String userEmail = "";
  String sellerID = "";

  String orderPrice = "";

  List orderItem = [];

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    orderItem.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
      body: StreamBuilder(stream: _cartService.getCart(userEmail), builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting){
          return const Center(child: Text('Fetching Cart Data'),);
        }
        else if(snapshot.hasData){
          return  SizedBox(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 1,
            child: SingleChildScrollView(
              physics: const ScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  SizedBox(height: SizeConfig.heightMultiplier * 4,),

                  Container(
                    margin: const EdgeInsets.only(left: 14, top: 10),
                    child: Text('Your Cart: (${snapshot.data!.length} items)', style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 2,
                        color: appColorSecondary,
                        fontWeight: FontWeight.w600
                    ),),
                  ),

                  SizedBox(
                    width: SizeConfig.screenWidth * 1,
                    height: SizeConfig.screenHeight * 0.75,
                    child: snapshot.data!.length != 0 ? ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      physics: const ScrollPhysics(),
                      itemCount: snapshot.data!.length,
                      itemBuilder: (context, index) {
                        CartModel data = snapshot.data![index];
                        final String cardID = data.cartID;
                        sellerID = data.sellerEmail;
                        final String productID = data.productID;
                        final String productImage = data.productImage;
                        final String productName = data.productName;
                        final String productPrice = data.productPrice;
                        final String productQuantity = data.productQuantity;

                        orderItem.add({
                          "pID": productID,
                          "pImage": productImage,
                          "pName": productName,
                          "pPrice": productPrice,
                          "pQuantity": productQuantity,
                          "sellerID" : sellerID
                        });

                        debugPrint("Order Item: $orderItem");
                        return Container(
                          width: SizeConfig.screenWidth * 1,
                          height: SizeConfig.screenHeight * 0.14,
                          margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
                          padding: const EdgeInsets.all(6.0),
                          decoration: BoxDecoration(
                              color: appColorPrimary,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                    color: appColorSecondary.withOpacity(0.4),
                                    spreadRadius: 1,
                                    blurRadius: 6
                                )
                              ]
                          ),
                          child: Row(
                            children: [
                              // Image Container
                              Container(
                                width: SizeConfig.screenWidth * 0.3,
                                height: SizeConfig.screenHeight * 0.14,
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade300,
                                    borderRadius: BorderRadius.circular(14),
                                    image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: NetworkImage(productImage))
                                ),
                              ),

                              SizedBox(width: SizeConfig.widthMultiplier * 2,),

                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: SizeConfig.screenWidth * 0.55,
                                    child: Text(productName,style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier * 1.8,
                                        color: appColorSecondary,
                                        fontWeight: FontWeight.w600
                                    ),maxLines: 2,overflow: TextOverflow.ellipsis,),
                                  ),
                                  SizedBox(height: SizeConfig.heightMultiplier * 1,),
                                  SizedBox(
                                    width: SizeConfig.screenWidth * 0.55,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('$productPrice / Unit',style: TextStyle(
                                            fontSize: SizeConfig.textMultiplier * 1.4,
                                            color: appColorSecondary.withOpacity(0.6),
                                            fontWeight: FontWeight.w400
                                        ),),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [

                                            GestureDetector(
                                              onTap:(){
                                                _cartService.deleteCart(cardID, context);
                                                _cartService.calculateTotalPrice(userEmail);
                                                orderItem.clear();
                                              },
                                              child: Text('Remove item', style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 1.6,
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.w600
                                              ),),
                                            ),


                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        );
                      },) : const Center(child: Text('No Item found'),),
                  ),

                  FutureBuilder(future: _cartService.calculateTotalPrice(userEmail), builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return const Center(child: Text('--/--'),);
                    }
                    else if(snapshot.hasData){
                      orderPrice = snapshot.data!.toStringAsFixed(2);
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment:MainAxisAlignment.center,
                              children: [

                                Container(
                                  margin: const EdgeInsets.only(left: 14, top: 10),
                                  child: Text('Your Total:', style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 2,
                                      color: appColorSecondary,
                                      fontWeight: FontWeight.w600
                                  ),),
                                ),

                                  Container(
                                  margin: const EdgeInsets.only(left: 14, top: 10),
                                  child: Text('${snapshot.data!.toStringAsFixed(2)} PKR', style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier * 2,
                                  color: appColorSecondary,
                                  fontWeight: FontWeight.w600
                                  ),),
                                  ),
                               
                              ],
                            ),
                            ElevatedButton(
                              style: ButtonStyle(
                                backgroundColor: MaterialStatePropertyAll(appColorAccent),
                              ),
                              onPressed: (){
                                String shippingID = "";
                                String cardID = "";
                                showModalBottomSheet(
                                  backgroundColor: Colors.transparent,
                                  context: context, builder: (context) {
                                  return StatefulBuilder(builder: (context, setState) {
                                    return Container(
                                      width: SizeConfig.screenWidth * 0.8,
                                      height: SizeConfig.screenHeight * 0.6,
                                        margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 20),
                                        decoration: BoxDecoration(
                                            color: appColorPrimary,
                                            borderRadius: BorderRadius.circular(14)
                                        ),
                                        child: StreamBuilder(stream: _shippingService.getShipping(userEmail), builder: (context, snapshot) {
                                          if(snapshot.connectionState == ConnectionState.waiting){
                                            return const Center(child: Text('Getting Location Data'),);
                                          }
                                          else if(snapshot.hasData){
                                            return snapshot.data!.length != 0 ?
                                            Column(
                                              children: [

                                                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                const Text('Select Shipping Address'),

                                                SizedBox(height: SizeConfig.heightMultiplier * 1,),


                                                ListView.builder(
                                                  itemCount: snapshot.data!.length,
                                                  shrinkWrap: true,
                                                  itemBuilder: (context, index) {
                                                    ShippingModel shipData = snapshot.data![index];
                                                    return ListTile(
                                                      onTap: (){
                                                        shippingID = shipData.shippingID;
                                                        Navigator.pop(context);
                                                        showModalBottomSheet(
                                                          backgroundColor: Colors.transparent,
                                                          context: context, builder: (context) {
                                                          return StatefulBuilder(builder: (context, setState) {
                                                            return Container(
                                                                width: SizeConfig.screenWidth * 0.8,
                                                                height: SizeConfig.screenHeight * 0.6,
                                                                margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 20),
                                                                decoration: BoxDecoration(
                                                                    color: appColorPrimary,
                                                                    borderRadius: BorderRadius.circular(14)
                                                                ),
                                                                child: StreamBuilder(stream: _cardService.getCard(userEmail), builder: (context, snapshot) {
                                                                  if(snapshot.connectionState == ConnectionState.waiting){
                                                                    return const Center(child: Text('Getting Bank Card Data'),);
                                                                  }
                                                                  else if(snapshot.hasData){
                                                                    return snapshot.data!.length != 0 ?
                                                                    Column(
                                                                      children: [

                                                                        SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                        const Text('Select Your Card'),

                                                                        SizedBox(height: SizeConfig.heightMultiplier * 1,),

                                                                        ListView.builder(
                                                                          itemCount: snapshot.data!.length,
                                                                          shrinkWrap: true,
                                                                          itemBuilder: (context, index) {
                                                                            CardModel cardData = snapshot.data![index];
                                                                            return ListTile(
                                                                              onTap: (){
                                                                                cardID = cardData.cardID;
                                                                                _orderService.addOrder(OrderModel(
                                                                                    orderID: const Uuid().v1(),
                                                                                    sellerID: sellerID,
                                                                                    userEmailID: userEmail,
                                                                                    orderPrice: orderPrice,
                                                                                    orderItem: orderItem,
                                                                                    orderStatus: 'Pending',
                                                                                    shippingID: shippingID,
                                                                                    cardID: cardID,
                                                                                    createdAt: DateTime.now().toString()), context);
                                                                              },
                                                                              leading: CircleAvatar(backgroundColor: appColorPrimary,child: Center(child: Text("${index + 1}"),),),
                                                                              title: Text(cardData.cardHolderName),
                                                                              subtitle: Text(cardData.cardNumber),
                                                                            );
                                                                          },),
                                                                      ],
                                                                    )
                                                                    : const Center(child: Text('No Bank Card Detail Found'),);
                                                                  }
                                                                  else{
                                                                    return const Center(child: Icon(Icons.error,color: Colors.red,),);
                                                                  }
                                                                },)
                                                            );
                                                          },);
                                                        },);
                                                      },
                                                      leading: CircleAvatar(backgroundColor: appColorPrimary,child: Center(child: Text("${index + 1}"),),),
                                                      title: Text(shipData.shippingTitle),
                                                      subtitle: Text(shipData.shippingAddress),
                                                    );
                                                  },),
                                              ],
                                            )
                                            : const Center(child: Text('No Shipping Address Found'),);
                                          }
                                          else{
                                            return const Center(child: Icon(Icons.error,color: Colors.red,),);
                                          }
                                        },)
                                    );
                                  },);
                                },);

                              }, child:   Text('Proceed to Payment', style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.4,
                                color: appColorPrimary,
                                fontWeight: FontWeight.w600
                            ),),)
                          ],
                        ),
                      );
                    }
                    else {
                      return const Center(child: Icon(Icons.error,color: Colors.red,),);
                    }
                  },),
                  SizedBox(height: SizeConfig.heightMultiplier * 10,),
                ],
              ),
            ),
          );
        }
        else {
          return const Center(child: Icon(Icons.error,color: Colors.red,),);
        }
      },)
    );
  }
}
