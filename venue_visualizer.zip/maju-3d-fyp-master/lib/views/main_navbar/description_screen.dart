import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_bloc.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_event.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_state.dart';
import 'package:majumodel/bloc/product_tab/product_tab_bloc.dart';
import 'package:majumodel/bloc/product_tab/product_tab_event.dart';
import 'package:majumodel/bloc/product_tab/product_tab_state.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/file_service/model_file.dart';
import 'package:majumodel/firebase_services/cart/cart_model.dart';
import 'package:majumodel/firebase_services/cart/cart_services.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/reuseable_widgets/reuseable_description_screen.dart';
import 'package:uuid/uuid.dart';
import '../../constants/app_color.dart';
import '../../reuseable_widgets/reuseable_review_sceen.dart';
import '../../reuseable_widgets/reusebale_similar_screen.dart';

class DescriptionScreen extends StatefulWidget {
  const DescriptionScreen({super.key, required this.productID});
  final String productID;

  @override
  State<DescriptionScreen> createState() => _DescriptionScreenState();
}

class _DescriptionScreenState extends State<DescriptionScreen> {

  List<IconData> descIcon = [Iconsax.note, Iconsax.star, Iconsax.magic_star];
  List<String> descTag = ['Description', ' Reviews', 'Similar'];

  final ProductService _productService = ProductService();
  final CartService _cartService = CartService();
  final FileService _fileService = FileService();


  String userEmail = "";


  @override
  void initState() {
    super.initState();
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    BlocProvider.of<ProductQuantityBloc>(context).add(ProductQuantityChange(1));
    BlocProvider.of<ProductTabBloc>(context).add(ProductTabChanger(0));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
        body: StreamBuilder(stream: _productService.getProduct(widget.productID), builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.waiting){
            return const Center(child: Text('Getting Product Details'),);
          } else if(snapshot.hasData){
            return ListView.builder(
              itemCount: 1,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                ProductModel data = snapshot.data![index];

                String pID = data.productId;
                String pName = data.productName!;
                String sEmail = data.sellerEmail;
                String pImage = data.getProductImage!;
                String pDesc = data.productDescription!;
                String pCate = data.productCategory!;
                String pHeight = data.productHeight!;
                String pWidth = data.productWidth!;
                String pBreath = data.productBreath!;
                String pPrice = data.productPrice!;
                String glbUrl = data.glbFormat!;
                var pReviews = data.productReviews ?? [];
                debugPrint("Reviews: $pReviews");

                return SingleChildScrollView(
                  physics: const ScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Stack(
                        children: [

                          // Background Image Container

                          Container(
                            width: SizeConfig.screenWidth * 1,
                            height: SizeConfig.screenHeight * 0.6,
                            decoration:  BoxDecoration(
                                color: Colors.black,
                                image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: NetworkImage(pImage))
                            ),
                          ),

                          // Back Button and AR View
                          Positioned(
                            left: 10,
                            top: 40,
                            right: 10,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(14),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                    child: Container(
                                      width: SizeConfig.screenWidth * 0.2,
                                      height: SizeConfig.screenHeight * 0.04,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(14)
                                      ),
                                      child: GestureDetector(
                                        onTap: (){Navigator.pop(context);},
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment
                                              .spaceEvenly,
                                          children: [
                                            Icon(Icons.chevron_left,
                                              color: appColorPrimary,),
                                            Text('Back', style: TextStyle(
                                                color: appColorPrimary,
                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                fontWeight: FontWeight.w600
                                            ),),
                                            SizedBox(
                                              width: SizeConfig.widthMultiplier * 0.6,)
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(14),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                    child: GestureDetector(
                                      onTap: (){
                                        _fileService.downloadFile(glbUrl, pID, context);
                                      },
                                      child: Container(
                                        width: SizeConfig.screenWidth * 0.25,
                                        height: SizeConfig.screenHeight * 0.04,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(14)
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment
                                              .spaceEvenly,
                                          children: [
                                            Icon(
                                              Iconsax.d_square, color: appColorPrimary,),
                                            Text('AR View', style: TextStyle(
                                                color: appColorPrimary,
                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                fontWeight: FontWeight.w600
                                            ),),
                                            SizedBox(
                                              width: SizeConfig.widthMultiplier * 0.6,)
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),

                          Positioned(
                            left: 10,
                            bottom: 80,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: BackdropFilter(
                                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(14)
                                  ),
                                  child: SizedBox(
                                    width: SizeConfig.screenWidth * 0.6,
                                    child: Text(pName,
                                      style: TextStyle(
                                          color: appColorPrimary,
                                          fontSize: SizeConfig.textMultiplier * 2,
                                          fontWeight: FontWeight.w600
                                      ), maxLines: 2, overflow: TextOverflow.fade,),
                                  ),
                                ),
                              ),
                            ),
                          ),

                          Positioned(
                            bottom: 20,
                            child: Container(
                              width: SizeConfig.screenWidth * 1,
                              height: SizeConfig.screenHeight * 0.05,
                              alignment: Alignment.center,
                              child: ListView.builder(
                                itemCount: descIcon.length,
                                shrinkWrap: true,
                                scrollDirection: Axis.horizontal,
                                physics: const ScrollPhysics(),
                                itemBuilder: (context, index) {
                                  return Container(
                                    margin: const EdgeInsets.symmetric(horizontal: 6),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: BackdropFilter(
                                        filter: ImageFilter.blur(
                                            sigmaX: 20, sigmaY: 20),
                                        child: GestureDetector(
                                          onTap: () {
                                            BlocProvider.of<ProductTabBloc>(context).add(ProductTabChanger(index));
                                          },
                                          child: BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                                            if(state is ProductTabChanged){
                                              return Container(
                                                width: SizeConfig.screenWidth * 0.3,
                                                height: SizeConfig.screenHeight * 0.03,
                                                decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                    color: state.newTab == index
                                                        ? appColorAccent
                                                        : Colors.transparent
                                                ),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment
                                                      .spaceEvenly,
                                                  children: [
                                                    Icon(descIcon[index],
                                                      color: appColorPrimary, size: 18,),
                                                    SizedBox(
                                                      height: SizeConfig.heightMultiplier *
                                                          2,
                                                      child: VerticalDivider(
                                                        color: appColorPrimary,
                                                        width: 2,
                                                      ),
                                                    ),
                                                    Text(descTag[index], style: TextStyle(
                                                        color: appColorPrimary,
                                                        fontSize: SizeConfig
                                                            .textMultiplier * 1.2,
                                                        fontWeight: FontWeight.w600
                                                    ),
                                                      maxLines: 1,
                                                      overflow: TextOverflow.fade,),
                                                  ],
                                                ),
                                              );
                                            } else {
                                              return const Text('Something went wrong');
                                            }
                                          },),
                                        ),
                                      ),
                                    ),
                                  );
                                },),
                            ),
                          )
                        ],
                      ),

                      // Description heading
                      BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                      if(state is ProductTabChanged){
                       return state.newTab == 0 ?  Column(
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [
                           CustomDescriptionWidget(
                                productDescription: pDesc,
                                productWidth: pWidth,
                                productHeight: pHeight,
                                productBreath: pBreath,
                                productPrice: pPrice),
                           Container(
                             width: SizeConfig.screenWidth * 1,
                             height: SizeConfig.screenHeight * 0.07,
                             margin: const EdgeInsets.symmetric(horizontal: 14),

                             child: BlocBuilder<ProductQuantityBloc, ProductQuantityState>(builder: (context, state) {
                               if(state is ProductQuantityChanger) {
                                 return Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [

                                     SizedBox(
                                         width: SizeConfig.screenWidth * 0.4,
                                         height: SizeConfig.screenHeight * 0.05,
                                         child: Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceAround,
                                           children: [

                                             GestureDetector(
                                               onTap: () {
                                                 if (state.newQuantity > 1) {
                                                   BlocProvider.of<ProductQuantityBloc>(context).add(
                                                       ProductQuantityChange(state.newQuantity - 1));
                                                 }
                                               },
                                               child: Container(
                                                 alignment: Alignment.center,
                                                 decoration: BoxDecoration(
                                                     shape: BoxShape.circle,
                                                     color: appColorPrimary
                                                 ),
                                                 child: const Icon(Iconsax.minus),
                                               ),
                                             ),

                                             Text('${state.newQuantity}', style: TextStyle(
                                                 fontSize: SizeConfig.textMultiplier * 2,
                                                 color: appColorSecondary.withOpacity(0.6),
                                                 fontWeight: FontWeight.w600
                                             ),),

                                             GestureDetector(
                                               onTap: () {
                                                 if (state.newQuantity < 10) {
                                                   BlocProvider.of<ProductQuantityBloc>(context).add(
                                                       ProductQuantityChange(state.newQuantity + 1));
                                                 }
                                               },
                                               child: Container(
                                                 alignment: Alignment.center,
                                                 decoration: BoxDecoration(
                                                     shape: BoxShape.circle,
                                                     color: appColorPrimary
                                                 ),
                                                 child: const Icon(Iconsax.add),
                                               ),
                                             ),

                                           ],
                                         )


                                     ),

                                     ElevatedButton(
                                         style: ButtonStyle(
                                             backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                         ),
                                         onPressed: () {
                                           int convertedPrice = int.parse(pPrice);
                                           int priceCalculation = convertedPrice * state.newQuantity ;
                                           _cartService.addCart(CartModel(
                                               cartID: const Uuid().v1(),
                                               productID: pID,
                                               userEmail: userEmail,
                                               sellerEmail: sEmail,
                                               productName: pName,
                                               productImage: pImage,
                                               productQuantity: '${state.newQuantity}',
                                               productPrice: "$priceCalculation"), context);
                                         },
                                         child: Text('Add to Cart', style: TextStyle(
                                             color: appColorPrimary,
                                             fontSize: SizeConfig.textMultiplier * 1.4),))

                                   ],
                                 );
                               } else{
                                 return const Center(child: Text('Something went wrong'),);
                               }
                             },),
                           )
                         ],
                       ) : state.newTab == 1 ?
                         CustomReviewWidget(reviews: pReviews,) :  CustomSimilarWidget( getProductCategory: pCate, getProductID: pID,);

                      } else {
                        return const Center(child: Text('Something went wrong'),);
                      }
                      },),




                    ],
                  ),
                );
              },);
          } else{
            return const Center(child: Icon(Icons.error,color: Colors.red,),);
          }
        },),
    );
  }
}


