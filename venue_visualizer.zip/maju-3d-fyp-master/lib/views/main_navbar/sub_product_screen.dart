import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';

import '../../constants/app_color.dart';
import '../../reuseable_widgets/reuseable_product_container.dart';
import 'description_screen.dart';

class SubProductScreen extends StatefulWidget {
  const SubProductScreen({super.key,required this.productName, required this.productImage, required this.productCategory});

  final String productName;
  final String productImage;
  final String productCategory;

  @override
  State<SubProductScreen> createState() => _SubProductScreenState();
}

class _SubProductScreenState extends State<SubProductScreen> {

  final TextEditingController searchController = TextEditingController();
  final ProductService _productService = ProductService();

  bool isSearch = false;

  void searchListner(){
    if(searchController.text.isNotEmpty){
      setState(() {
        isSearch = true;
      });
    }else{
      setState(() {
        isSearch = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    searchController.addListener(searchListner);
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 1,
        child: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              SizedBox(height: SizeConfig.heightMultiplier * 6,),

              SizedBox(
                width: SizeConfig.screenWidth * 1,
                child: Row(
                    children: [

                      IconButton(onPressed: (){Navigator.pop(context);}, icon: Icon(Icons.chevron_left,color: appColorSecondary,)),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(left: 14),
                            child: Text(widget.productName,style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2,
                                fontWeight: FontWeight.w600,
                                color: appColorSecondary
                            ),),
                          ),

                          Container(
                            width: SizeConfig.screenWidth * 0.8,
                            margin: const EdgeInsets.only(left: 14),
                            child: Text('Browse through your favourite ${widget.productName}',style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 1.4,
                                fontWeight: FontWeight.w400,
                                color: appColorSecondary
                            ),maxLines: 2, overflow: TextOverflow.ellipsis,),
                          ),
                        ],
                      )
                    ]
                ),
              ),

              SizedBox(height: SizeConfig.heightMultiplier * 2,),

              TextFormField(
                controller: searchController,
                validator: (val){
                  if(val == null || val == " " || val.isEmpty){
                    return 'Field not be empty';
                  } else{
                    return null;
                  }
                },
                style: TextStyle(
                    color: appColorSecondary
                ),
                decoration: InputDecoration(
                    prefixIcon: Icon(Iconsax.search_favorite, color: appColorSecondary,),
                    hintText: 'Search Items',
                    hintStyle: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: SizeConfig.textMultiplier * 1.8,
                        color: appColorSecondary
                    ),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(color: appColorPrimary)
                    ),
                    focusedBorder: InputBorder.none
                ),
              ),

              SizedBox(height: SizeConfig.heightMultiplier * 2,),

              SizedBox(
                width: SizeConfig.screenWidth * 1,
                height: SizeConfig.screenHeight * 0.74,
                child: SingleChildScrollView(
                  physics: const ScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  child: StreamBuilder(stream: isSearch ? _productService.searchProduct(searchController.text, widget.productCategory) : _productService.getProductCategory(widget.productCategory), builder: (context, AsyncSnapshot<List<ProductModel>> snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return const Center(child: Text('Getting Desire Product'),);
                    }
                    else if(snapshot.hasData){
                      return snapshot.data!.length != 0 ? GridView(gridDelegate:  const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 5,
                          childAspectRatio: 155/240
                      ),
                        shrinkWrap: true,
                        physics: const ScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        children: List.generate(snapshot.data!.length, (index) {
                          ProductModel pData = snapshot.data![index];
                          String pID = pData.productId;
                          String pName = pData.productName!;
                          String pImage = pData.getProductImage!;
                          String pWidth = pData.productWidth!;
                          String pHeight = pData.productHeight!;
                          String pPrice = pData.productPrice!;
                          String pStatus = pData.productStatus!;
                          return pStatus == "Live" ? GestureDetector(
                            onTap: (){
                              Navigator.push(context,  MaterialPageRoute(builder: (context) =>  DescriptionScreen(productID: pID,),));
                            },
                            child: CustomProductContainer(
                                productImage: pImage,
                                productName: pName,
                                productSize: 'Size $pWidth ft / $pHeight ft',
                                productPrice: pPrice),
                          ) : Container();
                        },),
                      ) : const Center(child: Text('No Product found here'),);
                    }
                    else{
                      return const Center(child: Icon(Icons.error,color: Colors.red,),);
                    }
                  },)
                ),
              )

            ],
          ),
        )
      ),
    );
  }
}
