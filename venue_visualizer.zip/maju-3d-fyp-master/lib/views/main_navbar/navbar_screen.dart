import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/bloc/main_navbar_bloc/navbar_bloc.dart';
import 'package:majumodel/bloc/main_navbar_bloc/navbar_event.dart';
import 'package:majumodel/bloc/main_navbar_bloc/navbar_state.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/views/main_navbar/cart_screen.dart';
import 'package:majumodel/views/main_navbar/home_screen.dart';
import 'package:majumodel/views/main_navbar/product_screen.dart';
import 'package:majumodel/views/main_navbar/profile_screen.dart';

class MainNavbarScreen extends StatefulWidget {
  const MainNavbarScreen({super.key});

  @override
  State<MainNavbarScreen> createState() => _MainNavbarScreenState();
}

class _MainNavbarScreenState extends State<MainNavbarScreen> {

  void pageShifter(index){
    BlocProvider.of<NavbarBloc>(context).add(PageShifter(index));
  }

  final List<Widget> myScreens = const [
    HomeScreen(),
    ProductScreen(),
    CartScreen(),
    ProfileScreen()
  ];

  @override
  void initState() {
    // TODO: implement initState
    BlocProvider.of<NavbarBloc>(context).add(PageShifter(0));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (didPop) => exit(0),
      child: BlocBuilder<NavbarBloc, NavbarState>(builder: (context, state) {
        if(state is PageCounter){
          return Scaffold(
            extendBody: true,
            body: myScreens[state.pageCount],
            bottomNavigationBar: Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  // image: const DecorationImage(
                  //     fit: BoxFit.cover,
                  //     image: AssetImage('images/navbar_background/navbar_background_image.jpg'))
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                    child: GNav(
                      selectedIndex: state.pageCount,
                      onTabChange: pageShifter,
                      gap: 10,
                      haptic: false,
                      padding: const EdgeInsets.all(14.0),
                      style: GnavStyle.google,
                      backgroundColor: Colors.transparent,
                      textStyle: TextStyle(
                          color: appColorAccent,
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w600
                      ),
                      tabBackgroundColor: Colors.transparent,
                      activeColor: appColorAccent,
                      tabs: [
                        GButton(icon: Iconsax.home, iconColor:appColorSecondary, text: 'Home',),
                        GButton(icon: Iconsax.category4, iconColor:appColorSecondary, text: 'Products',),
                        GButton(icon: Iconsax.shopping_cart, iconColor:appColorSecondary, text: 'Cart',),
                        GButton(icon: Iconsax.user, iconColor:appColorSecondary, text: 'Profile',),
                      ],
                    ),
                  ),
                )
            ),
          );
        } else {
          return Text('State is $state');
        }
      },),
    );
  }
}
