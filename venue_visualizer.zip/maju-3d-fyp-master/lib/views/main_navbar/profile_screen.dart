import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_event.dart';
import 'package:majumodel/bloc/loader_bloc/loader_state.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/views/order_screens/completed_orders.dart';
import 'package:majumodel/views/order_screens/pending_orders.dart';
import 'package:majumodel/views/order_screens/rejected_orders.dart';
import 'package:majumodel/views/profile_options/bank_cards.dart';
import 'package:majumodel/views/profile_options/shipping_address.dart';

import '../../reuseable_widgets/reuseable_textfield.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  final UserServices userServices = UserServices();
  String userEmail = '';

  final TextEditingController userName = TextEditingController();
  final TextEditingController userAge = TextEditingController();
  final TextEditingController userPhone = TextEditingController();

  final List<String> _gender = ['Male', 'Female']; // Option 2

  File? userProfile; // For mobile

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    userName.dispose();
    userAge.dispose();
    userPhone.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: StreamBuilder(stream: userServices.getUser(userEmail), builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: Column(
            children: [
              CircularProgressIndicator(color: appColorSecondary,),
              Text('Loading',style: TextStyle(
                  color: appColorPrimary,
                  fontSize: SizeConfig.textMultiplier * 3,
                  fontWeight: FontWeight.w600
              ),),
            ],
          ),);
        }
        else if(snapshot.hasData){
          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              UserModel userModel = snapshot.data![index];
              String? uID = userModel.userID;
              String? uName = userModel.userName;
              String? uRole = userModel.userRole;
              String? getImage = userModel.getImage;
              String? uAge = userModel.userAge;
              String? uGender = userModel.userGender;
              String? uPhone = userModel.userPhone;
              String? uEmail = userModel.userEmail;
              String uPassword = userModel.userPassword;
              bool? uStatus = userModel.userStatus;
              String? createdAt = userModel.createdAt;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                SizedBox(height: SizeConfig.heightMultiplier * 6,),

                Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: NetworkImage(getImage!),
                  ),
                ),

                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                Center(
                  child: Text(uName!,style: TextStyle(
                      color: appColorSecondary,
                      fontSize: SizeConfig.textMultiplier * 2,
                      fontWeight: FontWeight.w800
                  ),),
                ),

                Center(
                  child: Text(uEmail!,style: TextStyle(
                      color: appColorSecondary.withOpacity(0.6),
                      fontSize: SizeConfig.textMultiplier * 1.5,
                      fontWeight: FontWeight.w600
                  ),),
                ),

                SizedBox(height: SizeConfig.heightMultiplier * 2,),


                Center(
                  child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll(appColorAccent)
                    ),
                    onPressed: (){
                      userName.text = uName;
                      userAge.text = uAge!;
                      userPhone.text = uPhone!;
                      showDialog(
                        context: context, builder: (context) {
                        return StatefulBuilder(builder:  (context, setState) {
                          return AlertDialog(
                            backgroundColor: appColorSecondary.withOpacity(0.4),
                            content: SingleChildScrollView(
                              physics: const ScrollPhysics(),
                              child: Column(
                                children: [

                                  userProfile == null ? GestureDetector(
                                    onTap:()async{
                                      XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                      if(selectedImage != null){

                                        File convertedFile = File(selectedImage.path);
                                        setState(() {
                                          userProfile = convertedFile;
                                        });
                                        if(context.mounted){
                                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                        }
                                      }
                                      else{
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                        }
                                      }
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.symmetric(vertical: 10),
                                      alignment: Alignment.center,
                                      child: CircleAvatar(
                                        radius: 30,
                                        backgroundColor: appColorPrimary,
                                        backgroundImage: NetworkImage(getImage),
                                      ),
                                    ),
                                  ) :
                                  GestureDetector(
                                    onTap:()async{
                                      XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                      if(selectedImage != null){
                                        File convertedFile = File(selectedImage.path);
                                        setState(() {
                                          userProfile = convertedFile;
                                        });
                                        if(context.mounted){
                                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                        }
                                      }
                                      else{
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                        }
                                      }
                                    },
                                    child: Container(
                                      alignment: Alignment.center,
                                      margin: const EdgeInsets.symmetric(vertical: 10),
                                      child: CircleAvatar(
                                        radius: 30,
                                        backgroundImage: userProfile != null ? FileImage(userProfile!) : null,
                                      ),
                                    ),
                                  ),

                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 2,
                                  ),

                                  CustomTextField(
                                      fieldController: userName,
                                      hintText: 'Enter Your Name Here',
                                      fieldIcon: Iconsax.user,
                                      errorText: 'username is Required'),

                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 2,
                                  ),

                                  CustomTextField(
                                      fieldController: userAge,
                                      hintText: 'Enter Your Age Here',
                                      fieldIcon: Iconsax.graph,
                                      errorText: 'Age is Required'),


                                  Container(
                                    margin: const EdgeInsets.only(left: 10),
                                    width: SizeConfig.screenWidth * 0.8,
                                    child: DropdownButton(
                                      isExpanded: true,
                                      iconEnabledColor: appColorPrimary,
                                      hint: Text('Your Gender', style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),), // Not necessary for Option 1
                                      value: uGender,
                                      onChanged: (newValue) {
                                        setState(() {
                                          uGender = newValue;
                                        });
                                      },
                                      items: _gender.map((location) {
                                        return DropdownMenuItem(
                                          value: location,
                                          child: Text(location, style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),),
                                        );
                                      }).toList(),
                                    ),
                                  ),

                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 2,
                                  ),

                                  CustomTextField(
                                      fieldController: userPhone,
                                      hintText: 'Enter Your Phone Number Here',
                                      fieldIcon: Iconsax.call,
                                      errorText: 'Phone number is Required'),

                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 2,
                                  ),

                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: BlocBuilder<LoaderBloc, LoaderState>(builder: (context, state) {
                                      if(state is LoadState){
                                        return state.onLoad ? CircularProgressIndicator(color: appColorAccent,) : ElevatedButton(
                                            style: ButtonStyle(
                                                backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                            ),
                                            onPressed: (){
                                              if(userProfile == null){
                                                userServices.userUpdate(UserModel(
                                                  userID: uID,
                                                  userName: userName.text.toString(),
                                                  userAge: userAge.text.toString(),
                                                  userRole: uRole,
                                                  userGender: uGender,
                                                  userPhone: userPhone.text.toString(),
                                                  userEmail: uEmail,
                                                  userPassword: uPassword,
                                                  userStatus: uStatus,
                                                  getImage: getImage,
                                                  createdAt: createdAt,
                                                ), context);
                                              } else {
                                                userServices.userUpdate(UserModel(
                                                  userID: uID,
                                                  userName: userName.text.toString(),
                                                  userAge: userAge.text.toString(),
                                                  userRole: uRole,
                                                  userGender: uGender,
                                                  userPhone: userPhone.text.toString(),
                                                  userEmail: uEmail,
                                                  userPassword: uPassword,
                                                  userStatus: uStatus,
                                                  getImage: getImage,
                                                  userImage: userProfile!,
                                                  createdAt: createdAt,
                                                ), context);
                                              }

                                            }, child: Text('Update',style: TextStyle(
                                            fontSize: SizeConfig.textMultiplier * 2,
                                            fontWeight: FontWeight.w600,
                                            color: appColorPrimary
                                        ),));
                                      } else {
                                        return const Text("Something went wrong");
                                      }
                                    },)
                                  ),

                                ],
                              ),
                            ),
                          );
                        },);
                      },);
                          }, child: Text('Edit Profile',style: TextStyle(
                      color: appColorPrimary,
                      fontSize: SizeConfig.textMultiplier * 1.5,
                      fontWeight: FontWeight.w600
                  ),),),
                ),

                SizedBox(height: SizeConfig.heightMultiplier * 2,),

                SizedBox(
                  width: SizeConfig.screenWidth * 1,
                  height: SizeConfig.screenHeight * 0.62,
                  child: SingleChildScrollView(
                    physics: const ScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(left: 14),
                          child: Text('Password',style: TextStyle(
                              color: appColorSecondary,
                              fontSize: SizeConfig.textMultiplier * 1.5,
                              fontWeight: FontWeight.w600
                          ),),
                        ),

                        Container(
                          width: SizeConfig.screenWidth * 1,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: appColorPrimary
                          ),
                          child: ListTile(
                            onTap: (){
                              userServices.userPasswordRequest(userEmail, context);
                            },
                            leading: const Icon(Iconsax.password_check),
                            title: Text('Request Password Change',style: TextStyle(
                                color: appColorSecondary,
                                fontSize: SizeConfig.textMultiplier * 1.5,
                                fontWeight: FontWeight.w600
                            ),),
                            trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                          ),
                        ),

                        SizedBox(height: SizeConfig.heightMultiplier * 2,),

                        Container(
                          margin: const EdgeInsets.only(left: 14),
                          child: Text('Order Management',style: TextStyle(
                              color: appColorSecondary,
                              fontSize: SizeConfig.textMultiplier * 1.5,
                              fontWeight: FontWeight.w600
                          ),),
                        ),

                        GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const PendingOrders(),));
                          },
                          child: Container(
                            width: SizeConfig.screenWidth * 1,
                            margin: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                                color: appColorPrimary
                            ),
                            child: ListTile(
                              leading: const Icon(Iconsax.refresh),
                              title: Text('Pending Orders',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const CompletedOrders(),));
                          },
                          child: Container(
                            width: SizeConfig.screenWidth * 1,
                            margin: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                                color: appColorPrimary
                            ),
                            child: ListTile(
                              leading: const Icon(Iconsax.tick_circle),
                              title: Text('Completed Orders',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const RejectedOrders(),));
                          },
                          child: Container(
                            width: SizeConfig.screenWidth * 1,
                            margin: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                                color: appColorPrimary
                            ),
                            child: ListTile(
                              leading: const Icon(Iconsax.close_circle),
                              title: Text('Rejected Orders',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                            ),
                          ),
                        ),

                        SizedBox(height: SizeConfig.heightMultiplier * 2,),

                        Container(
                          margin: const EdgeInsets.only(left: 14),
                          child: Text('Payment Management',style: TextStyle(
                              color: appColorSecondary,
                              fontSize: SizeConfig.textMultiplier * 1.5,
                              fontWeight: FontWeight.w600
                          ),),
                        ),

                        Container(
                          width: SizeConfig.screenWidth * 1,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: appColorPrimary
                          ),
                          child: GestureDetector(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context) => const BankCards(),));
                            },
                            child: ListTile(
                              leading: const Icon(Iconsax.card),
                              title: Text('Bank Cards',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                            ),
                          ),
                        ),
                        Container(
                          width: SizeConfig.screenWidth * 1,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: appColorPrimary
                          ),
                          child: GestureDetector(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context) => const ShippingAddress(),));
                            },
                            child: ListTile(
                              leading: const Icon(Iconsax.box),
                              title: Text('Shipping Address',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                            ),
                          ),
                        ),

                        SizedBox(height: SizeConfig.heightMultiplier * 2,),

                        Container(
                          margin: const EdgeInsets.only(left: 14),
                          child: Text('Account Management',style: TextStyle(
                              color: appColorSecondary,
                              fontSize: SizeConfig.textMultiplier * 1.5,
                              fontWeight: FontWeight.w600
                          ),),
                        ),

                        Container(
                          width: SizeConfig.screenWidth * 1,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: appColorPrimary
                          ),
                          child: GestureDetector(
                            onTap: (){
                              userServices.userLogout(context);
                            },
                            child: ListTile(
                              leading: const Icon(Iconsax.logout),
                              title: Text('Log out',style: TextStyle(
                                  color: appColorSecondary,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                            ),
                          ),
                        ),
                        Container(
                          width: SizeConfig.screenWidth * 1,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: appColorPrimary
                          ),
                          child: GestureDetector(
                            onTap: (){
                             userServices.userDelete(uID, getImage, context);
                            },
                            child: ListTile(
                              leading: const Icon(Iconsax.trash, color: Colors.red,),
                              title: Text('Delete Account',style: TextStyle(
                                  color: Colors.red,
                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                  fontWeight: FontWeight.w600
                              ),),
                            ),
                          ),
                        ),
                        SizedBox(height: SizeConfig.heightMultiplier * 12,),
                      ],
                    ),
                  ),
                )
              ],
            );
          },);
        }
        else{
          return const Center(child: Icon(Icons.error,color: Colors.red,));
        }
      },)
    );
  }
}
