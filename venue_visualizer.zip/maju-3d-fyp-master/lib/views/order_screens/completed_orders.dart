import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import '../../constants/app_color.dart';
import '../../firebase_services/order/order_model.dart';
import '../../firebase_services/user/user_model.dart';
import '../main_navbar/description_screen.dart';
import '../seller/seller_reuseable_widgets/reuseable_order_status_widget.dart';

class CompletedOrders extends StatefulWidget {
  const CompletedOrders({super.key});

  @override
  State<CompletedOrders> createState() => _CompletedOrdersState();
}

class _CompletedOrdersState extends State<CompletedOrders> {

  final OrderService _orderService = OrderService();
  final ProductService _productService = ProductService();
  final UserServices _userServices = UserServices();

  final TextEditingController reviewController = TextEditingController();
  String userEmail = "";
  double ratingValue = 3;

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    reviewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SizedBox(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 1,
        child: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Column(
            children: [

              SizedBox(height: SizeConfig.heightMultiplier * 6,),

              Center(
                child: Text('Order Completed',style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    fontWeight: FontWeight.w600,
                    color: appColorSecondary
                ),),
              ),

              Center(
                child: Text('History of your all Completed Orders',style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    fontWeight: FontWeight.w400,
                    color: appColorSecondary
                ),),
              ),

              SizedBox(
                height: SizeConfig.heightMultiplier * 2,
              ),

              SizedBox(
                width: SizeConfig.screenWidth * 1,
                height: SizeConfig.screenHeight * 0.85,
                child: StreamBuilder(stream: _orderService.getUserOrder(userEmail), builder:  (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return const Center(child: CircularProgressIndicator(),);
                  }
                  else if(snapshot.hasData){
                    return snapshot.data!.length != 0  ? ListView.builder(
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      physics: const ScrollPhysics(),
                      itemBuilder: (context, index) {
                        OrderModel data = snapshot.data![index];
                        final String orderID = data.orderID;
                        final String userID = data.userEmailID;
                        var orderItem = data.orderItem;
                        final String productPrice = data.orderPrice;
                        final String orderStatus = data.orderStatus;
                        final List orderProducts = data.orderItem;
                        return orderStatus == "Completed" ? GestureDetector(
                          onTap: (){
                            showModalBottomSheet(
                              backgroundColor: Colors.transparent,
                              context: context, builder: (context) {
                              return Container(
                                width: SizeConfig.screenWidth * 1,
                                height: SizeConfig.screenHeight * 0.25,
                                margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: appColorPrimary
                                ),
                                child: ListView.builder(
                                  itemCount: orderProducts.length,
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onDoubleTap: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (context) => DescriptionScreen(productID: orderItem[index]['pID']),));
                                      },
                                      onTap: (){
                                        Navigator.pop(context);
                                        showDialog(
                                          context: context, builder: (context) {
                                          return AlertDialog(
                                            backgroundColor: appColorPrimary,
                                            title: const Text('Add Review'),
                                            content: SizedBox(
                                              height: SizeConfig.screenHeight * 0.3,
                                              child: Column(
                                                children: [

                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                              RatingBar.builder(
                                                initialRating: 3,
                                                minRating: 1,
                                                direction: Axis.horizontal,
                                                allowHalfRating: true,
                                                itemCount: 5,
                                                itemSize: 24,
                                                itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
                                                itemBuilder: (context, _) =>const Icon(
                                                  Icons.star,
                                                  color: Colors.amber,
                                                ),
                                                onRatingUpdate: (rating) {
                                                  setState(() {
                                                    ratingValue = rating;
                                                  });
                                                },
                                              ),

                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                  TextFormField(
                                                    controller: reviewController,
                                                    validator: (val){
                                                      if(val == null || val == " " || val.isEmpty){
                                                        return 'Text is Required';
                                                      } else{
                                                        return null;
                                                      }
                                                    },
                                                    maxLines: 3,
                                                    style: TextStyle(
                                                        color: appColorSecondary
                                                    ),
                                                    decoration: InputDecoration(
                                                        prefixIcon: Icon(Iconsax.message, color: appColorSecondary.withOpacity(0.4),),
                                                        hintText: '\nWrite Review',
                                                        hintStyle: TextStyle(
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: SizeConfig.textMultiplier * 1.8,
                                                            color: appColorSecondary.withOpacity(0.4)
                                                        ),
                                                        border: UnderlineInputBorder(
                                                            borderSide: BorderSide(color: appColorPrimary)
                                                        ),
                                                        focusedBorder: InputBorder.none
                                                    ),
                                                  ),

                                                ],
                                              ),
                                            ),
                                            actions: [
                                              TextButton(onPressed: (){
                                                Navigator.pop(context);
                                                reviewController.clear();
                                              }, child: Text('Cancel',style: TextStyle(color: appColorSecondary),)),
                                              ElevatedButton(
                                                style: ButtonStyle(
                                                  backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                                ),
                                                  onPressed: (){
                                                _productService.addProductReview(
                                                    orderItem[index]['pID'],
                                                    userEmail,
                                                    ratingValue,
                                                    reviewController.text,context);
                                                reviewController.clear();
                                              }, child: Text('Add Review',style: TextStyle(
                                                color: appColorPrimary
                                              ),)),
                                            ],
                                          );
                                        },);
                                      },
                                      child: Container(
                                        width: SizeConfig.screenWidth * 1,
                                        height: SizeConfig.screenHeight * 0.14,
                                        margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
                                        padding: const EdgeInsets.all(6.0),
                                        decoration: BoxDecoration(
                                            color: appColorPrimary,
                                            borderRadius: BorderRadius.circular(20),
                                            boxShadow: [
                                              BoxShadow(
                                                  color: appColorSecondary.withOpacity(0.4),
                                                  spreadRadius: 1,
                                                  blurRadius: 6
                                              )
                                            ]
                                        ),
                                        child: Row(
                                          children: [
                                            // Image Container
                                            Container(
                                              width: SizeConfig.screenWidth * 0.2,
                                              height: SizeConfig.screenHeight * 0.14,
                                              decoration: BoxDecoration(
                                                  color: Colors.grey.shade300,
                                                  borderRadius: BorderRadius.circular(14),
                                                  image: DecorationImage(
                                                      fit: BoxFit.cover,
                                                      image: NetworkImage(orderItem[index]['pImage']))
                                              ),
                                            ),

                                            SizedBox(width: SizeConfig.widthMultiplier * 2,),

                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child: Text(orderItem[index]['pName'],style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 1.8,
                                                      color: appColorSecondary,
                                                      fontWeight: FontWeight.w600
                                                  ),maxLines: 2,overflow: TextOverflow.ellipsis,),
                                                ),
                                                SizedBox(height: SizeConfig.heightMultiplier * 1,),
                                                SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text('${orderItem[index]['pPrice']} / Unit',style: TextStyle(
                                                          fontSize: SizeConfig.textMultiplier * 1.4,
                                                          color: appColorSecondary.withOpacity(0.6),
                                                          fontWeight: FontWeight.w400
                                                      ),),
                                                    ],
                                                  ),
                                                ),
                                                StreamBuilder(stream: _userServices.getUser(orderItem[index]['sellerID']), builder: (context, snapshot) {
                                                  if(snapshot.connectionState == ConnectionState.waiting){
                                                    return const Text("Getting Seller Details");
                                                  }
                                                  else if(snapshot.hasData){
                                                    UserModel sellerDataName = snapshot.data![0];
                                                    return Text("Product By: ${sellerDataName.userName}");
                                                  }
                                                  else{
                                                    return const Icon(Icons.error,color: Colors.red,);
                                                  }
                                                },)                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },),
                              );
                            },);
                          },
                          child: CustomOrderStatusWidget(
                            orderID: orderID,
                            productName: userID,
                            productQty: orderItem.length.toString(),
                            productPrice: productPrice,
                            orderStatus: orderStatus,
                          ),
                        ) : Container();
                      },) : const Text('No Order to Show');
                  }
                  else{
                    return const Center(child: Icon(Icons.error,color: Colors.red,),);
                  }
                },),
              )

            ],
          ),
        ),
      ),
    );
  }
}
