import 'package:flutter/material.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/views/one_time_screen/page__two.dart';
import 'package:majumodel/views/one_time_screen/page_one.dart';
import 'package:majumodel/views/one_time_screen/page_three.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  final PageController _controller = PageController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // PageView to switch between screens
          PageView.builder(
            controller: _controller,
            itemCount: 3,
            itemBuilder: (context, index) {
              // Load corresponding pages based on index
              if (index == 0) {
                return const PageOne();
              } else if (index == 1) {
                return const PageTwo();
              } else {
                return const PageThree();
              }
            },
          ),
          // Positioned Smooth Page Indicator
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Center(
              child: SmoothPageIndicator(
                controller: _controller, // PageView controller
                count: 3, // Number of screens
                effect:  ExpandingDotsEffect(
                  dotWidth: 10,
                  dotHeight: 10,
                  activeDotColor: appColorPrimary,
                  dotColor: appColorSecondary,
                ), // Custom effect for the indicator
              ),
            ),
          ),
        ],
      ),
    );
  }
}
