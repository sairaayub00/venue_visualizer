import 'package:flutter/material.dart';
import 'package:majumodel/views/credentials_screen/login_screen.dart';
import '../../reuseable_widgets/reuseable_onboard_screen.dart';

class PageThree extends StatefulWidget {
  const PageThree({super.key});

  @override
  State<PageThree> createState() => _PageThreeState();
}

class _PageThreeState extends State<PageThree> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: [
            CustomOnBoardScreen(
              action: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
              },
                title: 'Try Before You Buy',
                subTitle: 'Use Augmented Reality to visualize furniture in your home before making a purchase.',
                image: 'https://images.pexels.com/photos/6474485/pexels-photo-6474485.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
          ],
        )
    );
  }
}
