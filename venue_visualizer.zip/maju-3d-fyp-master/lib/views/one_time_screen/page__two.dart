import 'package:flutter/material.dart';
import 'package:majumodel/reuseable_widgets/reuseable_onboard_screen.dart';

class PageTwo extends StatefulWidget {
  const PageTwo({super.key});

  @override
  State<PageTwo> createState() => _PageTwoState();
}

class _PageTwoState extends State<PageTwo> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
        body: CustomOnBoardScreen(
            title: 'Shop With Confidence',
            subTitle: 'Experience a seamless shopping journey, ensuring the perfect fit for your home.',
            image: 'https://images.pexels.com/photos/20450977/pexels-photo-20450977/free-photo-of-photo-of-a-muslim-woman-sitting-on-an-armchair-and-making-notes.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')
    );
  }
}
