import 'package:flutter/material.dart';
import 'package:majumodel/reuseable_widgets/reuseable_onboard_screen.dart';

class PageOne extends StatefulWidget {
  const PageOne({super.key});

  @override
  State<PageOne> createState() => _PageOneState();
}

class _PageOneState extends State<PageOne> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: CustomOnBoardScreen(
          title: 'Explore Our Collection',
          subTitle: 'Discover the finest furniture for every room in your home, tailored to your style and space.',
          image: 'https://images.pexels.com/photos/20437637/pexels-photo-20437637/free-photo-of-armchair-and-table-in-white-room.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')
    );
  }
}

