import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/shipping/shipping_model.dart';
import 'package:majumodel/firebase_services/shipping/shipping_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:uuid/uuid.dart';

import '../../constants/app_color.dart';

class ShippingAddress extends StatefulWidget {
  const ShippingAddress({super.key});

  @override
  State<ShippingAddress> createState() => _ShippingAddressState();
}

class _ShippingAddressState extends State<ShippingAddress> {

  TextEditingController title = TextEditingController();
  TextEditingController location = TextEditingController();

  final ShippingService _shippingService = ShippingService();

  String? userEmail = '';

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((value) {
      setState(() {
        userEmail = value['email'];
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    title.dispose();
    location.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SingleChildScrollView(
        physics: const ScrollPhysics(),
        child: Column(
          children: [

            SizedBox(height: SizeConfig.heightMultiplier * 6,),

            Container(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.1,
              margin: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                  Text('Shipping Details:', style: TextStyle(
                      fontSize: SizeConfig.textMultiplier * 2,
                      color: appColorSecondary,
                      fontWeight: FontWeight.w600
                  ),),

                  ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll(appColorAccent)
                    ),
                    onPressed: (){
                      showModalBottomSheet(
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        context: context, builder: (context) {
                        return Padding(
                          padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom, // Adjusts for the keyboard
                          ),
                          child: StatefulBuilder(builder: (context, setState) {
                            return Container(
                              width: SizeConfig.screenWidth * 1,
                              height: SizeConfig.screenHeight * 0.4,
                              margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              decoration: BoxDecoration(
                                color: appColorPrimary,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: SingleChildScrollView(
                                physics: const ScrollPhysics(),
                                child: Column(
                                  children: [

                                    SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                    Text('Add Address', style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier * 2,
                                        color: appColorSecondary,
                                        fontWeight: FontWeight.w600
                                    ),),

                                    SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                    TextFormField(
                                      controller: title,
                                      decoration: InputDecoration(
                                        border: const UnderlineInputBorder(),
                                        hintStyle: TextStyle(
                                          color: appColorSecondary,
                                        ),
                                        hintText: 'Name:',
                                      ),
                                      style: TextStyle(
                                        color: appColorSecondary,
                                      ),
                                    ),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    TextFormField(
                                      controller: location,
                                      decoration: InputDecoration(
                                        border: const UnderlineInputBorder(),
                                        hintStyle: TextStyle(
                                          color: appColorSecondary,
                                        ),
                                        hintText: 'Location:',
                                      ),
                                      style: TextStyle(
                                        color: appColorSecondary,
                                      ),
                                      keyboardType: TextInputType.text,
                                    ),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    ElevatedButton(
                                        style: ButtonStyle(
                                          backgroundColor: MaterialStatePropertyAll(appColorAccent),
                                        ),
                                        onPressed: (){
                                          _shippingService.addShipping(ShippingModel(
                                              shippingID: const Uuid().v1(),
                                              userEmail: userEmail!,
                                              shippingTitle: title.text,
                                              shippingAddress: location.text),
                                              context);
                                        }, child: Text('Add Address',style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        color: appColorPrimary
                                    ),)),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                  ],
                                ),
                              ),
                            );
                          },),
                        );
                      },);
                    }, child: Row(
                    children: [

                      Icon(Iconsax.add,color: appColorPrimary,),

                      Text('Add Address', style: TextStyle(
                          fontSize: SizeConfig.textMultiplier * 1.5,
                          color: appColorPrimary,
                          fontWeight: FontWeight.w600
                      ),),
                    ],
                  ),)

                ],
              ),
            ),


            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.8,
              child: StreamBuilder(
                  stream: _shippingService.getShipping(userEmail),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        shrinkWrap: true,
                        physics: const ScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, index) {
                          ShippingModel data = snapshot.data![index];
                          String sID = data.shippingID;
                          String sTitle = data.shippingTitle;
                          String sLocation = data.shippingAddress;
                          return GestureDetector(
                            onTap: (){
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                context: context, builder: (context) {
                                return Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.15,
                                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    decoration: BoxDecoration(
                                      color: appColorPrimary,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: SingleChildScrollView(
                                      physics: const ScrollPhysics(),
                                      child: Column(
                                        children: [

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          Text('Actions', style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier * 2,
                                              color: appColorSecondary,
                                              fontWeight: FontWeight.w600
                                          ),),

                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    Navigator.pop(context);
                                                    showModalBottomSheet(
                                                      backgroundColor: Colors.transparent,
                                                      isScrollControlled: true,
                                                      context: context, builder: (context) {
                                                      return Padding(
                                                        padding: EdgeInsets.only(
                                                          bottom: MediaQuery.of(context).viewInsets.bottom, // Adjusts for the keyboard
                                                        ),
                                                        child: StatefulBuilder(builder: (context, setState) {
                                                          title.text = sTitle;
                                                          location.text = sLocation;
                                                          return Container(
                                                            width: SizeConfig.screenWidth * 1,
                                                            height: SizeConfig.screenHeight * 0.4,
                                                            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                            padding: const EdgeInsets.symmetric(horizontal: 8),
                                                            decoration: BoxDecoration(
                                                              color: appColorPrimary,
                                                              borderRadius: BorderRadius.circular(14),
                                                            ),
                                                            child: SingleChildScrollView(
                                                              physics: const ScrollPhysics(),
                                                              child: Column(
                                                                children: [

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                                                  Text('Update Address', style: TextStyle(
                                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                                      color: appColorSecondary,
                                                                      fontWeight: FontWeight.w600
                                                                  ),),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                                                  TextFormField(
                                                                    controller: title,
                                                                    decoration: InputDecoration(
                                                                      border: const UnderlineInputBorder(),
                                                                      hintStyle: TextStyle(
                                                                        color: appColorSecondary,
                                                                      ),
                                                                      hintText: 'Name:',
                                                                    ),
                                                                    style: TextStyle(
                                                                      color: appColorSecondary,
                                                                    ),
                                                                  ),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                  TextFormField(
                                                                    controller: location,
                                                                    decoration: InputDecoration(
                                                                      border: const UnderlineInputBorder(),
                                                                      hintStyle: TextStyle(
                                                                        color: appColorSecondary,
                                                                      ),
                                                                      hintText: 'Location:',
                                                                    ),
                                                                    style: TextStyle(
                                                                      color: appColorSecondary,
                                                                    ),
                                                                    keyboardType: TextInputType.text,
                                                                  ),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                  ElevatedButton(
                                                                      style: ButtonStyle(
                                                                        backgroundColor: MaterialStatePropertyAll(appColorAccent),
                                                                      ),
                                                                      onPressed: (){
                                                                        _shippingService.updateShipping(ShippingModel(
                                                                            shippingID: sID,
                                                                            userEmail: userEmail!,
                                                                            shippingTitle: title.text,
                                                                            shippingAddress: location.text),
                                                                            context);
                                                                      }, child: Text('Update Address',style: TextStyle(
                                                                      fontSize: SizeConfig.textMultiplier * 1.4,
                                                                      color: appColorPrimary
                                                                  ),)),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },),
                                                      );
                                                    },);
                                                  }, child: Text('Update',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: appColorAccent
                                                  ),))
                                              ),

                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _shippingService.deleteShipping(sID, context);
                                                  }, child: Text('Delete',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.red
                                                  ),))
                                              ),
                                            ],
                                          ),

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                        ],
                                      ),
                                    ),
                                  );

                              },);
                            },
                            child: ListTile(
                              leading: const Icon(Iconsax.location),
                              title: Text(sTitle,style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier * 2,
                                  color: appColorSecondary,
                                  fontWeight: FontWeight.w600
                              ),),
                              subtitle: Text(sLocation,style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier * 1.4,
                                  color: appColorSecondary.withOpacity(0.6),
                                  fontWeight: FontWeight.w600
                              ),maxLines: 3, overflow: TextOverflow.ellipsis,),
                            ),
                          );
                        },);
                    } else if (snapshot.hasError) {
                      return const Center(child: Icon(Icons.error_outline));
                    } else {
                      return const Center(child: CircularProgressIndicator());
                    }
                  }),
            )
          ],
        ),
      ),
    );
  }
}
