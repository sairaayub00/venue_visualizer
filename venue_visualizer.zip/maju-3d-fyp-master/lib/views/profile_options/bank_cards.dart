import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/card/card_model.dart';
import 'package:majumodel/firebase_services/card/card_services.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:uuid/uuid.dart';

import '../../constants/app_color.dart';

class BankCards extends StatefulWidget {
  const BankCards({super.key});

  @override
  State<BankCards> createState() => _BankCardsState();
}

class _BankCardsState extends State<BankCards> {

  TextEditingController holderName = TextEditingController();
  TextEditingController cardNumber = TextEditingController();
  TextEditingController cardExpiry = TextEditingController();
  TextEditingController cardCvv = TextEditingController();

  final CardService _cardServices = CardService();

  String userEmail = '';

  @override
  void dispose() {
    // TODO: implement dispose
    holderName.dispose();
    cardNumber.dispose();
    cardExpiry.dispose();
    cardCvv.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        userEmail = val['email'];
      });
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SingleChildScrollView(
        physics: const ScrollPhysics(),
        child: Column(
          children: [

            SizedBox(height: SizeConfig.heightMultiplier * 6,),

            Container(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.1,
              margin: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                  Text('Bank Card Details:', style: TextStyle(
                      fontSize: SizeConfig.textMultiplier * 2,
                      color: appColorSecondary,
                      fontWeight: FontWeight.w600
                  ),),

                  ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(appColorAccent)
                    ),
                    onPressed: (){
                      showModalBottomSheet(
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        context: context, builder: (context) {
                        return Padding(
                          padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom, // Adjusts for the keyboard
                          ),
                          child: StatefulBuilder(builder: (context, setState) {
                            return Container(
                              width: SizeConfig.screenWidth * 1,
                              height: SizeConfig.screenHeight * 0.6,
                              margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              decoration: BoxDecoration(
                                color: appColorPrimary,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: SingleChildScrollView(
                                physics: const ScrollPhysics(),
                                child: Column(
                                  children: [

                                    SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                    Text('Add Bank Card', style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier * 2,
                                        color: appColorSecondary,
                                        fontWeight: FontWeight.w600
                                    ),),

                                    SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                    TextFormField(
                                      controller: holderName,
                                      decoration: InputDecoration(
                                          border: const UnderlineInputBorder(),
                                          hintStyle: TextStyle(
                                            color: appColorSecondary,
                                          ),
                                          hintText: 'Card Holder Name',
                                          prefixIcon: const Icon(Iconsax.user)
                                      ),
                                      style: TextStyle(
                                        color: appColorSecondary,
                                      ),
                                    ),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    TextFormField(
                                      controller: cardNumber,
                                      decoration: InputDecoration(
                                          border: const UnderlineInputBorder(),
                                          hintStyle: TextStyle(
                                            color: appColorSecondary,
                                          ),
                                          hintText: 'Card Number',
                                          prefixIcon: const Icon(Iconsax.card)
                                      ),
                                      style: TextStyle(
                                        color: appColorSecondary,
                                      ),
                                      keyboardType: TextInputType.number,
                                    ),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        SizedBox(
                                          width: SizeConfig.screenWidth * 0.4,
                                          child:  TextFormField(
                                            controller: cardExpiry,
                                            decoration: InputDecoration(
                                                border: const UnderlineInputBorder(),
                                                hintStyle: TextStyle(
                                                  color: appColorSecondary,
                                                ),
                                                hintText: 'Card Expiry',
                                                prefixIcon: const Icon(Iconsax.calendar)
                                            ),
                                            style: TextStyle(
                                              color: appColorSecondary,
                                            ),
                                            keyboardType: TextInputType.datetime,
                                          ),
                                        ),

                                        SizedBox(
                                          width: SizeConfig.screenWidth * 0.4,
                                          child:  TextFormField(
                                            controller: cardCvv,
                                            decoration: InputDecoration(
                                                border: const UnderlineInputBorder(),
                                                hintStyle: TextStyle(
                                                  color: appColorSecondary,
                                                ),
                                                hintText: 'Card CVV',
                                                prefixIcon: const Icon(Iconsax.personalcard)
                                            ),
                                            style: TextStyle(
                                              color: appColorSecondary,
                                            ),
                                            keyboardType: TextInputType.number,
                                          ),
                                        )
                                      ],
                                    ),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    ElevatedButton(
                                        style: ButtonStyle(
                                          backgroundColor: MaterialStatePropertyAll(appColorAccent),
                                        ),
                                        onPressed: (){
                                          _cardServices.addCard(CardModel(
                                              cardID: const Uuid().v1(),
                                              userEmail: userEmail,
                                              cardHolderName: holderName.text,
                                              cardNumber: cardNumber.text,
                                              expiryDate: cardExpiry.text,
                                              cardCvv: cardCvv.text), context);
                                        }, child: Text('Add Card',style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        color: appColorPrimary
                                    ),)),

                                    SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                  ],
                                ),
                              ),
                            );
                          },),
                        );
                      },);
                    }, child: Row(
                      children: [

                        Icon(Iconsax.add,color: appColorPrimary,),

                        Text('Add Card', style: TextStyle(
                          fontSize: SizeConfig.textMultiplier * 1.5,
                          color: appColorPrimary,
                          fontWeight: FontWeight.w600
                                        ),),
                      ],
                    ),)

                ],
              ),
            ),


            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.8,
              child: StreamBuilder(
                  stream: _cardServices.getCard(userEmail),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        shrinkWrap: true,
                        physics: const ScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, index) {
                          CardModel data = snapshot.data![index];
                          String cID = data.cardID;
                          String hName = data.cardHolderName;
                          String cNumber = data.cardNumber;
                          String cExpiry = data.expiryDate;
                          String cCvv = data.cardCvv;
                          return GestureDetector(
                            onTap: (){
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                context: context, builder: (context) {
                                return StatefulBuilder(builder: (context, setState) {
                                  return Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.15,
                                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    decoration: BoxDecoration(
                                      color: appColorPrimary,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: SingleChildScrollView(
                                      physics: const ScrollPhysics(),
                                      child: Column(
                                        children: [

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          Text('Actions', style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier * 2,
                                              color: appColorSecondary,
                                              fontWeight: FontWeight.w600
                                          ),),

                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    Navigator.pop(context);
                                                    showModalBottomSheet(
                                                      backgroundColor: Colors.transparent,
                                                      isScrollControlled: true,
                                                      context: context, builder: (context) {
                                                      return Padding(
                                                        padding: EdgeInsets.only(
                                                          bottom: MediaQuery.of(context).viewInsets.bottom, // Adjusts for the keyboard
                                                        ),                                                        child: StatefulBuilder(builder: (context, setState) {
                                                          holderName.text = hName;
                                                          cardNumber.text = cNumber;
                                                          cardExpiry.text = cExpiry;
                                                          cardCvv.text = cCvv;
                                                          return Container(
                                                            width: SizeConfig.screenWidth * 1,
                                                            height: SizeConfig.screenHeight * 0.6,
                                                            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                            padding: const EdgeInsets.symmetric(horizontal: 8),
                                                            decoration: BoxDecoration(
                                                              color: appColorPrimary,
                                                              borderRadius: BorderRadius.circular(14),
                                                            ),
                                                            child: SingleChildScrollView(
                                                              physics: const ScrollPhysics(),
                                                              child: Column(
                                                                children: [

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                                                  Text('Update Bank Card', style: TextStyle(
                                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                                      color: appColorSecondary,
                                                                      fontWeight: FontWeight.w600
                                                                  ),),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                                                  TextFormField(
                                                                    controller: holderName,
                                                                    decoration: InputDecoration(
                                                                        border: const UnderlineInputBorder(),
                                                                        hintStyle: TextStyle(
                                                                          color: appColorSecondary,
                                                                        ),
                                                                        hintText: 'Card Holder Name',
                                                                        prefixIcon: const Icon(Iconsax.user)
                                                                    ),
                                                                    style: TextStyle(
                                                                      color: appColorSecondary,
                                                                    ),
                                                                  ),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                  TextFormField(
                                                                    controller: cardNumber,
                                                                    decoration: InputDecoration(
                                                                        border: const UnderlineInputBorder(),
                                                                        hintStyle: TextStyle(
                                                                          color: appColorSecondary,
                                                                        ),
                                                                        hintText: 'Card Number',
                                                                        prefixIcon: const Icon(Iconsax.card)
                                                                    ),
                                                                    style: TextStyle(
                                                                      color: appColorSecondary,
                                                                    ),
                                                                    keyboardType: TextInputType.number,
                                                                  ),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                  Row(
                                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                    children: [
                                                                      SizedBox(
                                                                        width: SizeConfig.screenWidth * 0.4,
                                                                        child:  TextFormField(
                                                                          controller: cardExpiry,
                                                                          decoration: InputDecoration(
                                                                              border: const UnderlineInputBorder(),
                                                                              hintStyle: TextStyle(
                                                                                color: appColorSecondary,
                                                                              ),
                                                                              hintText: 'Card Expiry',
                                                                              prefixIcon: const Icon(Iconsax.calendar)
                                                                          ),
                                                                          style: TextStyle(
                                                                            color: appColorSecondary,
                                                                          ),
                                                                          keyboardType: TextInputType.datetime,
                                                                        ),
                                                                      ),

                                                                      SizedBox(
                                                                        width: SizeConfig.screenWidth * 0.4,
                                                                        child:  TextFormField(
                                                                          controller: cardCvv,
                                                                          decoration: InputDecoration(
                                                                              border: const UnderlineInputBorder(),
                                                                              hintStyle: TextStyle(
                                                                                color: appColorSecondary,
                                                                              ),
                                                                              hintText: 'Card CVV',
                                                                              prefixIcon: const Icon(Iconsax.personalcard)
                                                                          ),
                                                                          style: TextStyle(
                                                                            color: appColorSecondary,
                                                                          ),
                                                                          keyboardType: TextInputType.number,
                                                                        ),
                                                                      )
                                                                    ],
                                                                  ),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                  ElevatedButton(
                                                                      style: ButtonStyle(
                                                                        backgroundColor: MaterialStatePropertyAll(appColorAccent),
                                                                      ),
                                                                      onPressed: (){
                                                                        _cardServices.updateCard(CardModel(
                                                                            cardID: cID,
                                                                            userEmail: userEmail,
                                                                            cardHolderName: holderName.text,
                                                                            cardNumber: cardNumber.text,
                                                                            expiryDate: cardExpiry.text,
                                                                            cardCvv: cardCvv.text), context);
                                                                      }, child: Text('Update Card',style: TextStyle(
                                                                      fontSize: SizeConfig.textMultiplier * 1.4,
                                                                      color: appColorPrimary
                                                                  ),)),

                                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },),
                                                      );
                                                    },);
                                                  }, child: Text('Update',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: appColorAccent
                                                  ),))
                                              ),

                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _cardServices.deleteCard(cID, context);
                                                  }, child: Text('Delete',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.red
                                                  ),))
                                              ),
                                            ],
                                          ),

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                        ],
                                      ),
                                    ),
                                  );
                                },);
                              },);
                            },
                            child: CustomBankCard(
                              holderName: hName,
                              cardNumber: cNumber,
                              cardExpiry: cExpiry,
                              cardCvv: cCvv,
                            ),
                          );
                        },);
                    } else if (snapshot.hasError) {
                      return const Center(child: Icon(Icons.error_outline));
                    } else {
                      return const Center(child: CircularProgressIndicator());
                    }
                  }),
            )
          ],
        ),
      ),
    );
  }
}

class CustomBankCard extends StatelessWidget {
  const CustomBankCard({
    super.key,
    required this.holderName,
    required this.cardNumber,
    required this.cardExpiry,
    required this.cardCvv
  });
  final String holderName;
  final String cardNumber;
  final String cardExpiry;
  final String cardCvv;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.2,
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      alignment: Alignment.center,
      decoration: BoxDecoration(
          color: appColorPrimary,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: appColorSecondary.withOpacity(0.4),
                blurRadius: 8,
                spreadRadius: 1
            )
          ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Container(
            margin: const EdgeInsets.only(left: 14,top: 10),
            child: Text('Card Holder Name:', style: TextStyle(
                fontSize: SizeConfig.textMultiplier * 1.4,
                color: appColorSecondary.withOpacity(0.6),
                fontWeight: FontWeight.w600
            ),),
          ),

          Container(
            width: SizeConfig.screenWidth * 0.5,
            margin: const EdgeInsets.only(left: 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                const Icon(Iconsax.user),
                Text(holderName, style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w600
                ),overflow: TextOverflow.fade,maxLines: 2,),
              ],
            ),
          ),

          Container(
            margin: const EdgeInsets.only(left: 14,top: 10),
            child: Text('Card Number:', style: TextStyle(
                fontSize: SizeConfig.textMultiplier * 1.4,
                color: appColorSecondary.withOpacity(0.6),
                fontWeight: FontWeight.w600
            ),),
          ),

          Container(
            width: SizeConfig.screenWidth * 0.55,
            margin: const EdgeInsets.only(left: 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                const Icon(Iconsax.card),
                Text(cardNumber, style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w600
                ),),
              ],
            ),
          ),

          Row(
            children: [
              Container(
                margin: const EdgeInsets.only(left: 14,top: 10),
                child: Text('Card Expiry:', style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    color: appColorSecondary.withOpacity(0.6),
                    fontWeight: FontWeight.w600
                ),),
              ),

              Container(
                width: SizeConfig.screenWidth * 0.15,
                margin: const EdgeInsets.only(left: 14),
                child:   Text(cardExpiry, style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w600
                ),),
              ),

              Container(
                margin: const EdgeInsets.only(left: 14,top: 10),
                child: Text('Card CVV:', style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    color: appColorSecondary.withOpacity(0.6),
                    fontWeight: FontWeight.w600
                ),),
              ),

              Container(
                width: SizeConfig.screenWidth * 0.15,
                margin: const EdgeInsets.only(left: 14),
                child: Text(cardCvv, style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 2,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w600
                ),),
              ),
            ],
          )


        ],
      ),
    );
  }
}
