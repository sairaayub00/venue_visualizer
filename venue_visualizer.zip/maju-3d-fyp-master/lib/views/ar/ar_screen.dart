import 'package:flutter/material.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';

class ARView extends StatefulWidget {
  final String filePath;

  const ARView({super.key, required this.filePath});

  @override
  State<ARView> createState() => _ARViewState();
}

class _ARViewState extends State<ARView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: widget.filePath == null
            ? const CircularProgressIndicator()
            : ModelViewer(
          src: "file://${widget.filePath}",
          ar: true,
          autoRotate: true,
          cameraControls: true,
        ),
      ),
    );
  }
}
