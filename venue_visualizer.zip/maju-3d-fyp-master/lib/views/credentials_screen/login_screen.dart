import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_event.dart';
import 'package:majumodel/bloc/loader_bloc/loader_state.dart';
import 'package:majumodel/bloc/password/password_check_bloc.dart';
import 'package:majumodel/bloc/password/password_check_event.dart';
import 'package:majumodel/bloc/password/password_check_state.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/reuseable_widgets/reuseable_textfield.dart';
import 'package:majumodel/views/credentials_screen/register_screen.dart';
import '../../constants/app_color.dart';
import '../../constants/size_config.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController userEmail = TextEditingController();
  final TextEditingController userPassword = TextEditingController();

  final formKey = GlobalKey<FormState>();

  final UserServices _userServices = UserServices();

  @override
  void initState() {
    // TODO: implement initState
    BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(true));
    BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(true));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (didPop) => exit(0),
      child: Scaffold(
        backgroundColor: appColorPrimary,
        body: Container(
          width: SizeConfig.screenWidth * 1,
          alignment: Alignment.center,
          margin: const EdgeInsets.symmetric(horizontal: 10),
          child: Form(
            key: formKey,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                height: SizeConfig.screenHeight * 0.6,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    image: const DecorationImage(
                        fit: BoxFit.cover,
                        image: NetworkImage('https://images.pexels.com/photos/2082092/pexels-photo-2082092.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'))
                ),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Login.',style: TextStyle(
                          color: appColorPrimary,
                          fontSize: SizeConfig.textMultiplier * 3,
                          fontWeight: FontWeight.w600
                      ),),
                      Text('Welcome Back. Login again!.',style: TextStyle(
                          color: appColorPrimary,
                          fontSize: SizeConfig.textMultiplier * 1.5,
                          fontWeight: FontWeight.w400
                      ),),

                      SizedBox(
                        height: SizeConfig.heightMultiplier * 4,
                      ),

                      CustomTextField(
                        fieldController: userEmail,
                        hintText: 'Enter Your Email Here',
                        fieldIcon: Icons.email,
                        errorText: 'Email is Required',
                      ),

                      SizedBox(
                        height: SizeConfig.heightMultiplier * 2,
                      ),

                      BlocBuilder<PasswordCheckBloc, PasswordCheckState>(builder: (context, state) {
                        if(state is HiddenChecked){
                          return TextFormField(
                            controller: userPassword,
                            obscureText: state.isHidden,
                            validator: (val){
                              if(val == null || val == " " || val.isEmpty){
                                return 'Password is Required';
                              } else{
                                return null;
                              }
                            },
                            style: TextStyle(
                                color: appColorPrimary
                            ),
                            decoration: InputDecoration(
                                suffixIcon: IconButton(onPressed: (){
                                  BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(!state.isHidden));
                                }, icon: state.isHidden ? Icon(Iconsax.eye,color: appColorPrimary,) : Icon(Iconsax.eye_slash, color: appColorPrimary,)),
                                prefixIcon: Icon(Iconsax.password_check, color: appColorPrimary,),
                                hintText: 'Enter Your Password Here',
                                hintStyle: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: SizeConfig.textMultiplier * 1.8,
                                    color: appColorPrimary
                                ),
                                border: UnderlineInputBorder(
                                    borderSide: BorderSide(color: appColorPrimary)
                                ),
                                focusedBorder: InputBorder.none
                            ),
                          );
                        }
                        else{
                          return const Center(child: Text('Something went wrong'),);
                        }
                      },),

                      SizedBox(
                        height: SizeConfig.heightMultiplier * 2,
                      ),

                      Align(
                        alignment: Alignment.centerRight,
                        child: BlocBuilder<LoaderBloc, LoaderState>(builder:  (context, state) {
                          if(state is LoadState){
                            return state.onLoad ? CircularProgressIndicator(color: appColorAccent,) : ElevatedButton(
                                style: ButtonStyle(
                                    backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                ),
                                onPressed: (){
                                  if(formKey.currentState!.validate()){
                                    _userServices.userLogin(UserModel(
                                        userEmail: userEmail.text.toString(),
                                        userPassword: userPassword.text.toString()), context);
                                  }
                                }, child: Text('Login',style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2,
                                fontWeight: FontWeight.w600,
                                color: appColorPrimary
                            ),));
                          } else{
                            return const Text("Something went wrong");
                          }
                        },)
                      ),

                      SizedBox(
                        height: SizeConfig.heightMultiplier * 2,
                      ),

                     TextButton(onPressed: (){
                       Navigator.push(context, MaterialPageRoute(builder: (context) => const RegisterScreen(),));
                     }, child: Text("Don't Have an Account! Create One",style: TextStyle(
                         fontSize: SizeConfig.textMultiplier * 1.4,
                         fontWeight: FontWeight.w400,
                         color: appColorPrimary
                     ),))
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

