import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_state.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/views/credentials_screen/login_screen.dart';
import '../../bloc/password/password_check_bloc.dart';
import '../../bloc/password/password_check_event.dart';
import '../../bloc/password/password_check_state.dart';
import '../../constants/app_color.dart';
import '../../constants/size_config.dart';
import '../../reuseable_widgets/reuseable_textfield.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final TextEditingController userName = TextEditingController();
  final TextEditingController userAge = TextEditingController();
  final TextEditingController userPhone = TextEditingController();
  final TextEditingController userEmail = TextEditingController();
  final TextEditingController userPassword = TextEditingController();

  final formKey = GlobalKey<FormState>();
  final List<String> _roles = ['User', 'Seller']; // Option 2
  String? _selectedRole;

  final List<String> _gender = ['Male', 'Female']; // Option 2
  String? _selectedGender;// Option 2

  final UserServices _userServices = UserServices();

  File? userProfile; // For mobile
  @override
  void initState() {
    // TODO: implement initState
    BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(true));
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    userName.dispose();
    userAge.dispose();
    userPhone.dispose();
    userEmail.dispose();
    userPassword.dispose();
    BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(true));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: Container(
        width: SizeConfig.screenWidth * 1,
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(horizontal: 10),
        child: Form(
          key: formKey,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Container(
              height: SizeConfig.screenHeight * 0.8,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image: const DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage('https://images.pexels.com/photos/2082092/pexels-photo-2082092.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'))
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: SingleChildScrollView(
                  physics: const ScrollPhysics(),
                  child: Stack(
                    children: [

                      userProfile == null ? GestureDetector(
                        onTap:()async{
                          XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                          if(selectedImage != null){

                              File convertedFile = File(selectedImage.path);
                              setState(() {
                                userProfile = convertedFile;
                              });
                              if(context.mounted){
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                              }
                          }
                          else{
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                            }
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          alignment: Alignment.center,
                          child: CircleAvatar(
                            radius: 30,
                              backgroundColor: appColorPrimary
                          ),
                        ),
                      ) : GestureDetector(
                        onTap:()async{
                          XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                          if(selectedImage != null){
                              File convertedFile = File(selectedImage.path);
                              setState(() {
                                userProfile = convertedFile;
                              });
                              if(context.mounted){
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                              }
                          }
                          else{
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                            }
                          }
                        },
                        child: Container(
                          alignment: Alignment.center,
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          child: CircleAvatar(
                            radius: 30,
                              backgroundImage: userProfile != null ? FileImage(userProfile!) : null,
                          ),
                        ),
                      ),

                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 4,
                          ),

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 4,
                          ),

                          CustomTextField(
                              fieldController: userName,
                              hintText: 'Enter Your Name Here',
                              fieldIcon: Iconsax.user,
                              errorText: 'username is Required'),

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 2,
                          ),

                          CustomTextField(
                              fieldController: userAge,
                              hintText: 'Enter Your Age Here',
                              fieldIcon: Iconsax.graph,
                              errorText: 'Age is Required'),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [


                              SizedBox(
                                width: SizeConfig.screenWidth * 0.35,
                                child: DropdownButton(
                                  iconEnabledColor: appColorPrimary,
                                  hint: Text('Select Role', style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),), // Not necessary for Option 1
                                  value: _selectedRole,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _selectedRole = newValue;
                                    });
                                  },
                                  items: _roles.map((location) {
                                    return DropdownMenuItem(
                                      value: location,
                                      child: Text(location, style: TextStyle(color: appColorSecondary, fontSize: SizeConfig.textMultiplier * 2),),
                                    );
                                  }).toList(),
                                ),
                              ),

                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: SizeConfig.screenWidth * 0.35,
                                child: DropdownButton(
                                  iconEnabledColor: appColorPrimary,
                                  hint: Text('Your Gender', style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),), // Not necessary for Option 1
                                  value: _selectedGender,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _selectedGender = newValue;
                                    });
                                  },
                                  items: _gender.map((location) {
                                    return DropdownMenuItem(
                                      value: location,
                                      child: Text(location, style: TextStyle(color: appColorSecondary, fontSize: SizeConfig.textMultiplier * 2),),
                                    );
                                  }).toList(),
                                ),
                              )

                            ],
                          ),

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 2,
                          ),

                          CustomTextField(
                              fieldController: userPhone,
                              hintText: 'Enter Your Phone Number Here',
                              fieldIcon: Iconsax.call,
                              errorText: 'Phone number is Required'),

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 2,
                          ),

                          CustomTextField(
                            fieldController: userEmail,
                            hintText: 'Enter Your Email Here',
                            fieldIcon: Icons.email,
                            errorText: 'Email is Required',
                          ),

                          SizedBox(
                            height: SizeConfig.heightMultiplier * 2,
                          ),

                          BlocBuilder<PasswordCheckBloc, PasswordCheckState>(builder: (context, state) {
                            if(state is HiddenChecked){
                              return TextFormField(
                                controller: userPassword,
                                obscureText: state.isHidden,
                                validator: (val){
                                  if(val == null || val == " " || val.isEmpty){
                                    return 'Password is Required';
                                  } else{
                                    return null;
                                  }
                                },
                                style: TextStyle(
                                    color: appColorPrimary
                                ),
                                decoration: InputDecoration(
                                    suffixIcon: IconButton(onPressed: (){
                                      BlocProvider.of<PasswordCheckBloc>(context).add(CheckHidden(!state.isHidden));
                                    }, icon: state.isHidden ? Icon(Iconsax.eye,color: appColorPrimary,) : Icon(Iconsax.eye_slash, color: appColorPrimary,)),
                                    prefixIcon: Icon(Iconsax.password_check, color: appColorPrimary,),
                                    hintText: 'Enter Your Password Here',
                                    hintStyle: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: SizeConfig.textMultiplier * 1.8,
                                        color: appColorPrimary
                                    ),
                                    border: UnderlineInputBorder(
                                        borderSide: BorderSide(color: appColorPrimary)
                                    ),
                                    focusedBorder: InputBorder.none
                                ),
                              );
                            }
                            else{
                              return const Center(child: Text('Something went wrong'),);
                            }
                          },),


                          SizedBox(
                            height: SizeConfig.heightMultiplier * 2,
                          ),

                          Align(
                            alignment: Alignment.centerRight,
                            child: BlocBuilder<LoaderBloc, LoaderState>(builder: (context, state) {
                              if(state is LoadState){
                                return state.onLoad ? CircularProgressIndicator(color: appColorAccent,) : ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                    ),
                                    onPressed: (){
                                      if(formKey.currentState!.validate()){

                                        if (userProfile != null) {
                                          _userServices.userRegister(UserModel(
                                            userName: userName.text.toString(),
                                            userAge: userAge.text.toString(),
                                            userRole: _selectedRole,
                                            userGender: _selectedGender,
                                            userPhone: userPhone.text.toString(),
                                            userEmail: userEmail.text.toString(),
                                            userPassword: userPassword.text.toString(),
                                            userStatus: true,
                                            userImage: userProfile!,
                                            createdAt: DateTime.now().toString(),
                                          ), context);
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                        }
                                      }
                                    }, child: Text('Register',style: TextStyle(
                                    fontSize: SizeConfig.textMultiplier * 2,
                                    fontWeight: FontWeight.w600,
                                    color: appColorPrimary
                                ),));
                              } else {
                                return const Text("Something went wrong");
                              }
                            },),
                          ),


                          TextButton(onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen(),));
                          }, child: Text("Already Have an Account? Login In.",style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.4,
                              fontWeight: FontWeight.w400,
                              color: appColorPrimary
                          ),))
                        ],
                      ),
                    ],
                  )
                ),
              ),
            ),
          ),
        ),
      ),
    );

  }
}
