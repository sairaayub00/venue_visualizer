import 'dart:async';
import 'package:flutter/material.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/views/admin/admin_home_screen.dart';
import 'package:majumodel/views/credentials_screen/login_screen.dart';
import 'package:majumodel/views/main_navbar/navbar_screen.dart';
import 'package:majumodel/views/seller/main_screens/seller_home_screen.dart';
import '../../constants/app_color.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  final UserServices userServices = UserServices();
  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      if(val['email'] != null){
        if(val['role'] == 'User'){
          Timer(const Duration(milliseconds: 2000), () => Navigator.push(context,MaterialPageRoute(builder: (context) => const MainNavbarScreen(),)),);
        } else if(val['role'] == 'Seller'){
          Timer(const Duration(milliseconds: 2000), () => Navigator.push(context,MaterialPageRoute(builder: (context) => const SellerHomeScreen(),)),);
        } else if(val['role'] == 'Admin'){
          Timer(const Duration(milliseconds: 2000), () => Navigator.push(context,MaterialPageRoute(builder: (context) => const AdminHomeScreen(),)),);
        }
      }
      else{
        Timer(const Duration(milliseconds: 2000), () => Navigator.push(context,MaterialPageRoute(builder: (context) => const LoginScreen(),)),);
      }
    });
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Container(
              width: SizeConfig.screenWidth * 0.3,
              height: SizeConfig.screenHeight * 0.15,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: appColorPrimary,
                image:const DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage('images/splash/splash.png'))
              ),
            ),

            SizedBox(height: SizeConfig.heightMultiplier * 1,),

            Text('Venue Visualizer',style: TextStyle(
                color: appColorSecondary.withOpacity(0.6),
                fontSize: SizeConfig.textMultiplier * 1.8,
                fontWeight: FontWeight.w600
            ),),

          ],
        ),
      ),
    );
  }
}
