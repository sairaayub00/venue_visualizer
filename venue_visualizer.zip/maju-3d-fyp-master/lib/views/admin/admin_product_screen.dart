import 'dart:io';
import 'package:flutter/material.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import '../../../constants/app_color.dart';
import '../../../constants/size_config.dart';
import '../seller/seller_reuseable_widgets/reuseable_product_status_widget.dart';

class AdminProductScreen extends StatefulWidget {
  const AdminProductScreen({super.key});

  @override
  State<AdminProductScreen> createState() => _AdminProductScreenState();
}

class _AdminProductScreenState extends State<AdminProductScreen> {
  final List<String> productStatus = ['All', 'Pending', 'Live', 'Blocked'];
  int currentIndex = 0;
  File? productImage;
  File? updatedproductImage;

  final TextEditingController productName = TextEditingController();
  final TextEditingController productDescription = TextEditingController();
  final TextEditingController productPrice = TextEditingController();
  final TextEditingController productWidth = TextEditingController();
  final TextEditingController productHeight = TextEditingController();
  final TextEditingController productBreath = TextEditingController();

  final ProductService _productServices = ProductService();

  String? sellerEmail;

  bool isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((value){
      setState(() {
        sellerEmail = value['email'];
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    productName.dispose();
    productDescription.dispose();
    productPrice.dispose();
    productWidth.dispose();
    productHeight.dispose();
    productBreath.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
    body: SingleChildScrollView(
      physics: const ScrollPhysics(),
      child: Column(
          children: [

            SizedBox(height: SizeConfig.heightMultiplier * 6,),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(onPressed: (){
                  Navigator.pop(context);
                }, icon: Icon(Icons.chevron_left,color: appColorSecondary,)),
                Text('Product Management',style: TextStyle(
                    color: appColorSecondary,
                    fontSize: SizeConfig.textMultiplier * 2,
                    fontWeight: FontWeight.w600
                ),),

                Icon(Icons.chevron_left,color: appColorPrimary,)
              ],
            ),

            SizedBox(height: SizeConfig.heightMultiplier * 2,),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.05,
              child: ListView.builder(
                itemCount: productStatus.length,
                scrollDirection: Axis.horizontal,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        currentIndex = index;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: currentIndex == index ? appColorAccent : Colors.transparent
                      ),
                      alignment: Alignment.center,
                      child: Text(productStatus[index],style: TextStyle(
                          color: currentIndex == index ? appColorPrimary : appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  );
                },),
            ),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.75,
              child: StreamBuilder(
                    stream: _productServices.getAllProduct(),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {

                        return snapshot.data!.length != 0 ? ListView.builder(
                          itemCount: snapshot.data!.length,
                          physics: const ScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            ProductModel data = snapshot.data![index];
                            String pID = data.productId;
                            String sEmail = data.sellerEmail;
                            String pName = data.productName!;
                            String pDesc = data.productDescription!;
                            String pCate = data.productCategory!;
                            String pImage = data.getProductImage!;
                            String pPrice = data.productPrice!;
                            String pWidth = data.productWidth!;
                            String pBreath = data.productBreath!;
                            String pHeight = data.productHeight!;
                            String pStatus = data.productStatus!;
                            String pFlx = data.fbxFormat!;
                            String pGlb = data.glbFormat!;
                            String pObj = data.objFormat!;
                            String pCreatedAt = data.createdAt!;
                            // All
                            return productStatus[currentIndex] == 'All' ? GestureDetector(
                              onLongPress: (){
                                showDialog(
                                  context: context, builder: (context) {
                                  return AlertDialog(
                                    backgroundColor: appColorPrimary,
                                    title: const Text("Delete Product"),
                                    content: Text("Are you sure you want to Delete $pName"),
                                    actions: [
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor: MaterialStatePropertyAll(appColorPrimary)
                                          ),
                                          onPressed: (){
                                            _productServices.productDelete(pID, pImage, context);
                                          }, child: const Text("Delete",style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600),)),
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor: MaterialStatePropertyAll(appColorPrimary)
                                          ),
                                          onPressed: (){
                                            Navigator.pop(context);
                                          }, child: Text("Cancel",style: TextStyle(color: appColorAccent, fontWeight: FontWeight.w600),)),

                                    ],
                                  );
                                },);
                              },
                              child: CustomProductStatusWidget(
                                productID: pID,
                                productName: pName,
                                productImage: pImage,
                                productPrice: pPrice,
                                productCategory: pCate,
                                productStatus: pStatus,
                                productOptions: (){
                                  showModalBottomSheet(
                                    backgroundColor: Colors.transparent,
                                    context: context, builder: (context) {
                                    return StatefulBuilder(builder: (context, setState) {
                                      return Container(
                                        width: SizeConfig.screenWidth * 1,
                                        height: SizeConfig.screenHeight * 0.15,
                                        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                        padding: const EdgeInsets.symmetric(horizontal: 8),
                                        decoration: BoxDecoration(
                                          color: appColorPrimary,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: SingleChildScrollView(
                                          physics: const ScrollPhysics(),
                                          child: Column(
                                            children: [

                                              SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                              Text('Actions', style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: appColorSecondary,
                                                  fontWeight: FontWeight.w600
                                              ),),

                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  SizedBox(
                                                      width: SizeConfig.screenWidth * 0.4,
                                                      child:  TextButton(onPressed: (){
                                                        _productServices.productUpdate(ProductModel(
                                                            productId: pID,
                                                            sellerEmail: sEmail,
                                                          productName: pName,
                                                          productPrice: pPrice,
                                                          productHeight: pHeight,
                                                          productWidth: pWidth,
                                                          productBreath: pBreath,
                                                          productDescription: pDesc,
                                                          productCategory: pCate,
                                                          getProductImage: pImage,
                                                          fbxFormat: pFlx,
                                                          glbFormat: pGlb,
                                                          objFormat: pObj,
                                                          createdAt: pCreatedAt,
                                                          productStatus: 'Live'
                                                        ),
                                                            context);
                                                      }, child: Text('Live',style: TextStyle(
                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                          color: Colors.green
                                                      ),))
                                                  ),

                                                  SizedBox(
                                                      width: SizeConfig.screenWidth * 0.4,
                                                      child:  TextButton(onPressed: (){
                                                        _productServices.productUpdate(ProductModel(
                                                            productId: pID,
                                                            sellerEmail: sEmail,
                                                            productName: pName,
                                                            productPrice: pPrice,
                                                            productHeight: pHeight,
                                                            productWidth: pWidth,
                                                            productBreath: pBreath,
                                                            productDescription: pDesc,
                                                            productCategory: pCate,
                                                            getProductImage: pImage,
                                                            fbxFormat: pFlx,
                                                            glbFormat: pGlb,
                                                            objFormat: pObj,
                                                            createdAt: pCreatedAt,
                                                            productStatus: 'Blocked'
                                                        ),
                                                            context);
                                                      }, child: Text('Block',style: TextStyle(
                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                          color: Colors.red
                                                      ),))
                                                  ),
                                                ],
                                              ),

                                              SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                            ],
                                          ),
                                        ),
                                      );
                                    },);
                                  },);

                                },
                                productDescription: (){
                                  // Navigator.push(context, MaterialPageRoute(builder: (context) => const DescriptionScreen(),));
                                },
                              ),
                            ) : pStatus == productStatus[currentIndex] ?
                            GestureDetector(
                              onLongPress: (){
                                showDialog(
                                  context: context, builder: (context) {
                                  return AlertDialog(
                                    backgroundColor: appColorPrimary,
                                    title: const Text("Delete Product"),
                                    content: Text("Are you sure you want to Delete $pName"),
                                    actions: [
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor: MaterialStatePropertyAll(appColorPrimary)
                                          ),
                                          onPressed: (){
                                            _productServices.productDelete(pID, pImage, context);
                                          }, child: const Text("Delete",style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600),)),
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor: MaterialStatePropertyAll(appColorPrimary)
                                          ),
                                          onPressed: (){
                                            Navigator.pop(context);
                                          }, child: Text("Cancel",style: TextStyle(color: appColorAccent, fontWeight: FontWeight.w600),)),

                                    ],
                                  );
                                },);
                              },
                              child: CustomProductStatusWidget(
                                productID: pID,
                                productName: pName,
                                productImage: pImage,
                                productPrice: pPrice,
                                productCategory: pCate,
                                productStatus: pStatus,
                                productOptions: (){
                                  showModalBottomSheet(
                                    backgroundColor: Colors.transparent,
                                    context: context, builder: (context) {
                                    return StatefulBuilder(builder: (context, setState) {
                                      return Container(
                                        width: SizeConfig.screenWidth * 1,
                                        height: SizeConfig.screenHeight * 0.15,
                                        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                        padding: const EdgeInsets.symmetric(horizontal: 8),
                                        decoration: BoxDecoration(
                                          color: appColorPrimary,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: SingleChildScrollView(
                                          physics: const ScrollPhysics(),
                                          child: Column(
                                            children: [

                                              SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                              Text('Actions', style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: appColorSecondary,
                                                  fontWeight: FontWeight.w600
                                              ),),

                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  SizedBox(
                                                      width: SizeConfig.screenWidth * 0.4,
                                                      child:  TextButton(onPressed: (){
                                                        _productServices.productUpdate(ProductModel(
                                                            productId: pID,
                                                            sellerEmail: sEmail,
                                                            productName: pName,
                                                            productPrice: pPrice,
                                                            productHeight: pHeight,
                                                            productWidth: pWidth,
                                                            productBreath: pBreath,
                                                            productDescription: pDesc,
                                                            productCategory: pCate,
                                                            getProductImage: pImage,
                                                            fbxFormat: pFlx,
                                                            glbFormat: pGlb,
                                                            objFormat: pObj,
                                                            createdAt: pCreatedAt,
                                                            productStatus: 'Live'
                                                        ),
                                                            context);
                                                      }, child: Text('Live',style: TextStyle(
                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                          color: Colors.green
                                                      ),))
                                                  ),

                                                  SizedBox(
                                                      width: SizeConfig.screenWidth * 0.4,
                                                      child:  TextButton(onPressed: (){
                                                        _productServices.productUpdate(ProductModel(
                                                            productId: pID,
                                                            sellerEmail: sEmail,
                                                            productName: pName,
                                                            productPrice: pPrice,
                                                            productHeight: pHeight,
                                                            productWidth: pWidth,
                                                            productBreath: pBreath,
                                                            productDescription: pDesc,
                                                            productCategory: pCate,
                                                            getProductImage: pImage,
                                                            fbxFormat: pFlx,
                                                            glbFormat: pGlb,
                                                            objFormat: pObj,
                                                            createdAt: pCreatedAt,
                                                            productStatus: 'Blocked'
                                                        ),
                                                            context);
                                                      }, child: Text('Block',style: TextStyle(
                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                          color: Colors.red
                                                      ),))
                                                  ),
                                                ],
                                              ),

                                              SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                            ],
                                          ),
                                        ),
                                      );
                                    },);
                                  },);

                                },
                                productDescription: (){
                                  // Navigator.push(context, MaterialPageRoute(builder: (context) => const DescriptionScreen(),));
                                },
                              ),
                            ):
                            Container();
                          },) : Center(child: Text('Added Product Will be shown here',style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 1.4
                        ),),);
                      } else if (snapshot.hasError) {
                        return const Center(child: Icon(Icons.error_outline,color: Colors.red,));
                      } else {
                        return  Center(child: CircularProgressIndicator(color: appColorSecondary,));
                      }
                    }))



          ]),
    )
    );
  }
}
