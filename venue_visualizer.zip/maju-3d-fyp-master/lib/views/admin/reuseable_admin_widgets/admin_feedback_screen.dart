import 'package:flutter/material.dart';
import 'package:majumodel/constants/size_config.dart';

import '../../../constants/app_color.dart';

class AdminFeedbackScreen extends StatefulWidget {
  const AdminFeedbackScreen({super.key});

  @override
  State<AdminFeedbackScreen> createState() => _AdminFeedbackScreenState();
}

class _AdminFeedbackScreenState extends State<AdminFeedbackScreen> {

  final List<String> feedBackStatus = ['All', 'Pending', 'Answered'];
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SizedBox(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 1,
        child: Column(
          children: [

            SizedBox(
              height: SizeConfig.heightMultiplier * 6,
            ),

            Center(
              child: Text('Feedback Screen',style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 2,
                  fontWeight: FontWeight.w600,
                  color: appColorSecondary
              ),),
            ),

            Center(
              child: Text('Manage All the feedbacks',style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 1.4,
                  fontWeight: FontWeight.w400,
                  color: appColorSecondary
              ),),
            ),

            SizedBox(height: SizeConfig.heightMultiplier * 2,),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.05,
              child: ListView.builder(
                itemCount: feedBackStatus.length,
                scrollDirection: Axis.horizontal,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        currentIndex = index;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: currentIndex == index ? appColorAccent : Colors.transparent
                      ),
                      alignment: Alignment.center,
                      child: Text(feedBackStatus[index],style: TextStyle(
                          color: currentIndex == index ? appColorPrimary : appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  );
                },),
            ),



            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.8,
              child: ListView.builder(
                itemCount: 10,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                physics: const ScrollPhysics(),
                itemBuilder: (context, index) {
                  return ExpansionTile(
                    expandedCrossAxisAlignment: CrossAxisAlignment.start,
                    expandedAlignment: Alignment.centerLeft,
                    childrenPadding: const EdgeInsets.all(10.0),
                    leading: const CircleAvatar(
                      radius: 40,
                      backgroundImage: AssetImage('images/person/personimage.jpg'),
                    ),
                    title: Text('Abdullah Haroon',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 2,
                        fontWeight: FontWeight.w600,
                        color: appColorSecondary
                    ),),
                    subtitle: Text('abdullah@gmail.com',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w400,
                        color: appColorSecondary.withOpacity(0.4)
                    ),),
                    children: [
                      Text('Such an amazing App! Wonderful.',style: TextStyle(
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w400,
                          color: appColorSecondary.withOpacity(0.6)
                      ),),

                      Container(
                        padding: const EdgeInsets.only(top: 10, right: 20),
                        width: SizeConfig.screenWidth * 1,
                        alignment: Alignment.bottomRight,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(appColorAccent),
                          ),
                          onPressed: (){}, child: Text('response',style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 1.4,
                            fontWeight: FontWeight.w600,
                            color: appColorPrimary
                        ),),),
                      )
                    ],
                  );
                },),
            ),

          ],
        ),
      ),
    );
  }
}
