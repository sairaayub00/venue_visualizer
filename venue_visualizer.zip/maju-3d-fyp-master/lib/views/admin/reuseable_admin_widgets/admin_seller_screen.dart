import 'package:flutter/material.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';

import '../../../constants/app_color.dart';


class AdminSellerScreen extends StatefulWidget {
  const AdminSellerScreen({super.key, required this.headingName});
  final String headingName;

  @override
  State<AdminSellerScreen> createState() => _AdminSellerScreenState();
}

class _AdminSellerScreenState extends State<AdminSellerScreen> {

  final List sellerStatus = ['All', true, false];
  int currentIndex = 0;
  
  final UserServices _userServices = UserServices();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorPrimary,
      body: SizedBox(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 1,
        child: Column(
          children: [



            SizedBox(
              height: SizeConfig.heightMultiplier * 6,
            ),

            Center(
              child: Text('${widget.headingName} Screen',style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 2,
                  fontWeight: FontWeight.w600,
                  color: appColorSecondary
              ),),
            ),

            Center(
              child: Text('Manage All the ${widget.headingName}',style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 1.4,
                  fontWeight: FontWeight.w400,
                  color: appColorSecondary
              ),),
            ),

            SizedBox(height: SizeConfig.heightMultiplier * 2,),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.05,
              child: ListView.builder(
                itemCount: sellerStatus.length,
                scrollDirection: Axis.horizontal,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        currentIndex = index;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: currentIndex == index ? appColorAccent : Colors.transparent
                      ),
                      alignment: Alignment.center,
                      child: Text(sellerStatus[index] == true ? 'Active' : sellerStatus[index] == false ? 'Blocked' : 'All',style: TextStyle(
                          color: currentIndex == index ? appColorPrimary : appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  );
                },),
            ),

           SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.75,
              child: StreamBuilder(
                  stream: _userServices.getUserByRole(widget.headingName),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        physics: const ScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          UserModel data = snapshot.data![index];
                          String userID = data.userID!;
                          String userName = data.userName!;
                          String userAge = data.userAge!;
                          String userGender = data.userGender!;
                          String userRole = data.userRole!;
                          String userPhone = data.userPhone!;
                          String userImage = data.getImage!;
                          String userEmail = data.userEmail!;
                          String userPassword = data.userPassword;
                          String userCreatedAt = data.createdAt!;
                          bool userStatus = data.userStatus!;
                          // All
                          return sellerStatus[currentIndex] == "All" ? GestureDetector(
                            onTap:(){
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                context: context, builder: (context) {
                                return StatefulBuilder(builder: (context, setState) {
                                  return Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.15,
                                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    decoration: BoxDecoration(
                                      color: appColorPrimary,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: SingleChildScrollView(
                                      physics: const ScrollPhysics(),
                                      child: Column(
                                        children: [

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          Text('Actions', style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier * 2,
                                              color: appColorSecondary,
                                              fontWeight: FontWeight.w600
                                          ),),

                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _userServices.userUpdate(UserModel(
                                                      userID: userID,
                                                        userName: userName,
                                                        userGender: userGender,
                                                        userAge: userAge,
                                                        userRole: userRole,
                                                        userPhone: userPhone,
                                                        getImage: userImage,
                                                        userEmail: userEmail,
                                                        userPassword: userPassword,
                                                      createdAt: userCreatedAt,
                                                      userStatus: true
                                                    ), context);
                                                  }, child: Text('Live',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.green
                                                  ),))
                                              ),

                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _userServices.userUpdate(UserModel(
                                                        userID: userID,
                                                        userName: userName,
                                                        userGender: userGender,
                                                        userAge: userAge,
                                                        userRole: userRole,
                                                        userPhone: userPhone,
                                                        getImage: userImage,
                                                        userEmail: userEmail,
                                                        userPassword: userPassword,
                                                        createdAt: userCreatedAt,
                                                        userStatus: false
                                                    ), context);
                                                  }, child: Text('Block',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.red
                                                  ),))
                                              ),
                                            ],
                                          ),

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                        ],
                                      ),
                                    ),
                                  );
                                },);
                              },);
                            },
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 40,
                                backgroundImage: NetworkImage(userImage),
                              ),
                              title: Text(userName),
                              subtitle: Text(userEmail),
                              trailing: userStatus == true ? const Text('Active',style: TextStyle(color: Colors.green),) : const Text('Blocked',style: TextStyle(color: Colors.red),) ,
                            ),
                          ) : userStatus == sellerStatus[currentIndex] ? GestureDetector(
                            onTap:(){
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                context: context, builder: (context) {
                                return StatefulBuilder(builder: (context, setState) {
                                  return Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.15,
                                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    decoration: BoxDecoration(
                                      color: appColorPrimary,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: SingleChildScrollView(
                                      physics: const ScrollPhysics(),
                                      child: Column(
                                        children: [

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          Text('Actions', style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier * 2,
                                              color: appColorSecondary,
                                              fontWeight: FontWeight.w600
                                          ),),

                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _userServices.userUpdate(UserModel(
                                                        userID: userID,
                                                        userName: userName,
                                                        userGender: userGender,
                                                        userAge: userAge,
                                                        userRole: userRole,
                                                        userPhone: userPhone,
                                                        getImage: userImage,
                                                        userEmail: userEmail,
                                                        userPassword: userPassword,
                                                        createdAt: userCreatedAt,
                                                        userStatus: true
                                                    ), context);
                                                  }, child: Text('Live',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.green
                                                  ),))
                                              ),

                                              SizedBox(
                                                  width: SizeConfig.screenWidth * 0.4,
                                                  child:  TextButton(onPressed: (){
                                                    _userServices.userUpdate(UserModel(
                                                        userID: userID,
                                                        userName: userName,
                                                        userGender: userGender,
                                                        userAge: userAge,
                                                        userRole: userRole,
                                                        userPhone: userPhone,
                                                        getImage: userImage,
                                                        userEmail: userEmail,
                                                        userPassword: userPassword,
                                                        createdAt: userCreatedAt,
                                                        userStatus: false
                                                    ), context);
                                                  }, child: Text('Block',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 2,
                                                      color: Colors.red
                                                  ),))
                                              ),
                                            ],
                                          ),

                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                        ],
                                      ),
                                    ),
                                  );
                                },);
                              },);
                            },
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 40,
                                backgroundImage: NetworkImage(userImage),
                              ),
                              title: Text(userName),
                              subtitle: Text(userEmail),
                              trailing: userStatus == true ? const Text('Active',style: TextStyle(color: Colors.green),) : const Text('Blocked',style: TextStyle(color: Colors.red),) ,
                            ),
                          ) :  Container();
                        },);
                    } else if (snapshot.hasError) {
                      return const Center(child: Icon(Icons.error_outline));
                    } else {
                      return const Center(child: CircularProgressIndicator());
                    }
                  }),
            ) 
          ],
        ),
      ),
    );
  }
}
