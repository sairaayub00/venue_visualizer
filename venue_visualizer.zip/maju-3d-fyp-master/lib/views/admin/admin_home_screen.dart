import 'dart:io';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:majumodel/constants/app_color.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/feedback/feedback_model.dart';
import 'package:majumodel/firebase_services/feedback/feedback_services.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/views/admin/admin_order_screen.dart';
import 'package:majumodel/views/admin/reuseable_admin_widgets/admin_seller_screen.dart';
import 'admin_product_screen.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {

  final ProductService _productService = ProductService();
  final UserServices _userServices = UserServices();
  final OrderService _orderService = OrderService();
  final FeedbackServices _feedbackServices = FeedbackServices();
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) => exit(0),
      child: Scaffold(
        backgroundColor: appColorPrimary,
        body: Container(
          width: SizeConfig.screenWidth * 1,
          margin: const EdgeInsets.symmetric(horizontal: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              SizedBox(
                height: SizeConfig.heightMultiplier * 6,
              ),

              Center(
                child: Text('Admin Panel',style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 2,
                  fontWeight: FontWeight.w600,
                  color: appColorSecondary
                ),),
              ),

              Center(
                child: Text('Manage Users, Seller and Products',style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    fontWeight: FontWeight.w400,
                    color: appColorSecondary
                ),),
              ),

              SizedBox(
                height: SizeConfig.heightMultiplier * 2,
              ),


              Container(
                width: SizeConfig.screenWidth * 1,
                height: SizeConfig.screenHeight * 0.12,
                alignment: Alignment.center,
                margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                decoration: BoxDecoration(
                  color: appColorPrimary,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: appColorSecondary.withOpacity(0.2),
                      blurRadius: 6,
                      spreadRadius: 0.6
                    )
                  ]
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [

                    GestureDetector(
                      onTap:(){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const AdminOrderScreen(),));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Iconsax.dcube,color: appColorSecondary,),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          StreamBuilder(
                              stream: _orderService.getAllOrder(),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (snapshot.hasData) {
                                  return Text('${snapshot.data!.length}',style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 2,
                                      fontWeight: FontWeight.w600,
                                      color: appColorSecondary
                                  ),);
                                } else if (snapshot.hasError) {
                                  return const Center(child: Icon(Icons.error_outline));
                                } else {
                                  return const Center(child: Text("--"));
                                }
                              }),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          Text('Orders',style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.6,
                              fontWeight: FontWeight.w600,
                              color: appColorSecondary.withOpacity(0.4)
                          ),),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const AdminProductScreen(),));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Iconsax.clipboard,color: appColorSecondary,),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          StreamBuilder(
                              stream: _productService.getAllProduct(),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (snapshot.hasData) {
                                  return Text('${snapshot.data!.length}',style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 2,
                                      fontWeight: FontWeight.w600,
                                      color: appColorSecondary
                                  ),);
                                } else if (snapshot.hasError) {
                                  return const Center(child: Icon(Icons.error_outline));
                                } else {
                                  return const Center(child: Text("--"));
                                }
                              }),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          Text('Products',style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.6,
                              fontWeight: FontWeight.w600,
                              color: appColorSecondary.withOpacity(0.4)
                          ),),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap:(){
                        Navigator.push(context,  MaterialPageRoute(builder: (context) => const AdminSellerScreen(headingName: 'Seller',),));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Iconsax.convertshape,color: appColorSecondary,),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          StreamBuilder(
                              stream: _userServices.getUserByRole('Seller'),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (snapshot.hasData) {
                                  return Text('${snapshot.data!.length}',style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 2,
                                      fontWeight: FontWeight.w600,
                                      color: appColorSecondary
                                  ),);
                                } else if (snapshot.hasError) {
                                  return const Center(child: Icon(Icons.error_outline));
                                } else {
                                  return const Center(child: Text("--"));
                                }
                              }),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          Text('Sellers',style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.6,
                              fontWeight: FontWeight.w600,
                              color: appColorSecondary.withOpacity(0.4)
                          ),),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap:(){
                        Navigator.push(context,  MaterialPageRoute(builder: (context) => const AdminSellerScreen(headingName: 'User',),));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Iconsax.user,color: appColorSecondary,),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          StreamBuilder(
                              stream: _userServices.getUserByRole('User'),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (snapshot.hasData) {
                                  return Text('${snapshot.data!.length}',style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 2,
                                      fontWeight: FontWeight.w600,
                                      color: appColorSecondary
                                  ),);
                                } else if (snapshot.hasError) {
                                  return const Center(child: Icon(Icons.error_outline));
                                } else {
                                  return const Center(child: Text("--"));
                                }
                              }),

                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),

                          Text('Users',style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.6,
                              fontWeight: FontWeight.w600,
                              color: appColorSecondary.withOpacity(0.4)
                          ),),
                        ],
                      ),
                    ),

                  ],
                ),
              ),

              Container(
                margin: const EdgeInsets.only(left: 14,top: 10,right: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Feedbacks',style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 1.6,
                        fontWeight: FontWeight.w600,
                        color: appColorSecondary.withOpacity(0.4)
                    ),),
                    SizedBox(
                      width: SizeConfig.screenWidth * 0.2,
                    )
                  ],
                ),
              ),

              SizedBox(
                width: SizeConfig.screenWidth * 1,
                height: SizeConfig.screenHeight * 0.4,
                child: StreamBuilder(stream: _feedbackServices.getFeedback(), builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return Container();
                  }
                  else if(snapshot.hasData){
                    return ListView.builder(
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      physics: const ScrollPhysics(),
                      itemBuilder: (context, index) {
                        FeedbackModel data = snapshot.data![index];

                        String fID = data.feedbackID;
                        String userEmail = data.userEmail;
                        String feedback = data.userFeedback;

                        return ExpansionTile(
                          expandedCrossAxisAlignment: CrossAxisAlignment.start,
                          expandedAlignment: Alignment.centerLeft,
                          childrenPadding: const EdgeInsets.all(10.0),
                          title: Text(userEmail,style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 2,
                              fontWeight: FontWeight.w600,
                              color: appColorSecondary
                          ),),
                          subtitle: Text(fID,style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 1.4,
                              fontWeight: FontWeight.w400,
                              color: appColorSecondary.withOpacity(0.4)
                          ),),
                          children: [
                            Text(feedback,style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2,
                                fontWeight: FontWeight.w400,
                                color: appColorSecondary.withOpacity(0.6)
                            ),),
                          ],
                        );
                      },);
                  }
                  else{
                    return const Center(child: Icon(Icons.error,color: Colors.red,),);
                  }
                },),
              ),

              SizedBox(height: SizeConfig.heightMultiplier * 1,),

              Container(
                margin: const EdgeInsets.only(left: 14,top: 10,right: 14),
                child: Text('Account Management',style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.6,
                    fontWeight: FontWeight.w600,
                    color: appColorSecondary.withOpacity(0.4)
                ),),
              ),

              ListTile(
                onTap: (){
                  _userServices.userLogout(context);
                },
                leading: const Icon(Iconsax.logout,color: Colors.red,),
                title: Text('Logout',style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.6,
                    fontWeight: FontWeight.w600,
                    color: Colors.red
                ),),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

