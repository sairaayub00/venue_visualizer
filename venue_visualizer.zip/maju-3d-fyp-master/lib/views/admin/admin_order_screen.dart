import 'package:flutter/material.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/order/order_model.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';

import '../../../constants/app_color.dart';
import '../seller/seller_reuseable_widgets/reuseable_order_status_widget.dart';

class AdminOrderScreen extends StatefulWidget {
  const AdminOrderScreen({super.key});

  @override
  State<AdminOrderScreen> createState() => _AdminOrderScreenState();
}

class _AdminOrderScreenState extends State<AdminOrderScreen> {

  final List<String> orderOption = ['All', 'Pending', 'Completed', 'Rejected'];
  int currentIndex = 0;

  final OrderService _orderService  = OrderService();

  String sellerEmail = "";

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        sellerEmail = val['email'];
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
      body: Column(
        children: [

        SizedBox(height: SizeConfig.heightMultiplier * 6,),

      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.chevron_left,color: appColorSecondary,)),
          Text('Order Management',style: TextStyle(
              color: appColorSecondary,
              fontSize: SizeConfig.textMultiplier * 2,
              fontWeight: FontWeight.w600
          ),),
         const Icon(Icons.chevron_left,color: Colors.transparent,),
        ],
      ),

          SizedBox(height: SizeConfig.heightMultiplier * 2,),

          SizedBox(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.05,
            child: ListView.builder(
              itemCount: orderOption.length,
              scrollDirection: Axis.horizontal,
              physics: const ScrollPhysics(),
              shrinkWrap: true,
              itemBuilder: (context, index) {
              return GestureDetector(
                onTap: (){
                  setState(() {
                    currentIndex = index;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: currentIndex == index ? appColorAccent : Colors.transparent
                  ),
                  alignment: Alignment.center,
                  child: Text(orderOption[index],style: TextStyle(
                      color: currentIndex == index ? appColorPrimary : appColorSecondary,
                      fontSize: SizeConfig.textMultiplier * 2,
                      fontWeight: FontWeight.w600
                  ),),
                ),
              );
            },),
          ),

          SizedBox(height: SizeConfig.heightMultiplier * 2,),


          SizedBox(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.75,
            child: StreamBuilder(stream: _orderService.getAllOrder(), builder: (context, snapshot) {
              if(snapshot.connectionState == ConnectionState.waiting){
                return const Center(child: CircularProgressIndicator(),);
              }
              else if(snapshot.hasData){
                return snapshot.data!.length != 0 ? ListView.builder(
                  itemCount: snapshot.data!.length,
                  physics: const ScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {

                    OrderModel data = snapshot.data![index];

                    final String orderID = data.orderID;
                    final String userID = data.userEmailID;
                    var orderItem = data.orderItem;
                    final String productPrice = data.orderPrice;
                    final String orderStatus = data.orderStatus;

                    return orderOption[currentIndex] == 'All' ? CustomOrderStatusWidget(
                      orderID: orderID,
                      productName: userID,
                      productQty: orderItem.length.toString(),
                      productPrice: productPrice,
                      orderStatus: orderStatus,

                    ) :  orderStatus == orderOption[currentIndex] ? CustomOrderStatusWidget(
                      orderID: orderID,
                      productName: userID,
                      productQty: orderItem.length.toString(),
                      productPrice: productPrice,
                      orderStatus: orderStatus,
                    ) : Container();
                  },) :  const Center(child: Text('Nothing to Show'),);
              }
              else{
                return const Center(child: Icon(Icons.error,color: Colors.red,),);
              }
            },),
          )

        ])
    );
  }
}
