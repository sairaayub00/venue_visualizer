import 'package:flutter/material.dart';

import '../../../constants/app_color.dart';
import '../../../constants/size_config.dart';


class CustomProductStatusWidget extends StatelessWidget {
  const CustomProductStatusWidget({
    super.key,
    required this.productID,
    required this.productName,
    required this.productImage,
    required this.productCategory,
    required this.productPrice,
    required this.productStatus,
    this.productOptions,
    this.productDescription,
  });

  final String productID;
  final String productName;
  final String productImage;
  final String productCategory;
  final String productPrice;
  final String productStatus;
  final VoidCallback? productOptions;
  final VoidCallback? productDescription;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: productOptions,
      onDoubleTap: productDescription,
      child: Container(
        width: SizeConfig.screenWidth * 1,
        height: SizeConfig.screenHeight * 0.14,
        margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
        padding: const EdgeInsets.all(6.0),
        decoration: BoxDecoration(
            color: appColorPrimary,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                  color: appColorSecondary.withOpacity(0.4),
                  spreadRadius: 1,
                  blurRadius: 6
              )
            ]
        ),
        child: Row(
          children: [
            // Image Container
            Container(
              width: SizeConfig.screenWidth * 0.3,
              height: SizeConfig.screenHeight * 0.14,
              decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(14),
                  image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(productImage))
              ),
            ),

            SizedBox(width: SizeConfig.widthMultiplier * 2,),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: SizeConfig.screenWidth * 0.45,
                  child: Text(productName,style: TextStyle(
                      fontSize: SizeConfig.textMultiplier * 1.8,
                      color: appColorSecondary,
                      fontWeight: FontWeight.w600
                  ),maxLines: 2,overflow: TextOverflow.ellipsis,),
                ),
                SizedBox(height: SizeConfig.heightMultiplier * 1,),
                Text(productCategory,style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 1.4,
                    color: appColorSecondary,
                    fontWeight: FontWeight.w600
                ),),
                SizedBox(height: SizeConfig.heightMultiplier * 1,),
                SizedBox(
                  width: SizeConfig.screenWidth * 0.45,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: SizeConfig.screenWidth * 0.27,
                        child: Text('$productPrice / Unit',style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 1.4,
                            color: appColorSecondary.withOpacity(0.6),
                            fontWeight: FontWeight.w400
                        ),),
                      ),
                      Row(children: [
                        CircleAvatar(
                          radius: 4,
                          backgroundColor: productStatus == 'Live' ? Colors.green : productStatus == 'Blocked' ? Colors.red : appColorSecondary,
                        ),
                        SizedBox(width: SizeConfig.widthMultiplier * 1,),
                        Text(productStatus,style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 1.4,
                            color: productStatus == 'Live' ? Colors.green : productStatus == 'Blocked' ? Colors.red : appColorSecondary,
                            fontWeight: FontWeight.w400
                        ),),
                      ],)
                    ],
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
