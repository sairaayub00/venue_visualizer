import 'package:flutter/material.dart';

import '../../../constants/app_color.dart';
import '../../../constants/size_config.dart';

class CustomOrderStatusWidget extends StatelessWidget {
  const CustomOrderStatusWidget({
    super.key,
    required this.orderID,
    required this.productName,
    required this.productQty,
    required this.productPrice,
    required this.orderStatus,
  });

  final String orderID;
  final String productName;
  final String productQty;
  final String productPrice;
  final String orderStatus;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth * 1,
      height: SizeConfig.screenHeight * 0.18,
      padding: const EdgeInsets.all(10.0),
      margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
      decoration: BoxDecoration(
          color: appColorPrimary,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: appColorSecondary.withOpacity(0.4),
                spreadRadius: 1,
                blurRadius: 6
            )
          ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Order ID:',style: TextStyle(
              color: appColorSecondary,
              fontSize: SizeConfig.textMultiplier * 1.4,
              fontWeight: FontWeight.w600
          ),),

          Text(orderID,style: TextStyle(
              color: appColorSecondary.withOpacity(0.4),
              fontSize: SizeConfig.textMultiplier * 1.4,
              fontWeight: FontWeight.w600
          ),),

          SizedBox(height: SizeConfig.heightMultiplier * 1,),

          SizedBox(
            width: SizeConfig.screenWidth * 0.8,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: SizeConfig.screenWidth * 0.42,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('User Email:',style: TextStyle(
                          color: appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 1.4,
                          fontWeight: FontWeight.w600
                      ),),

                      SizedBox(
                        width: SizeConfig.screenWidth * 0.4,
                        child: Text(productName,style: TextStyle(
                            color: appColorSecondary.withOpacity(0.4),
                            fontSize: SizeConfig.textMultiplier * 1.4,
                            fontWeight: FontWeight.w600
                        ),overflow: TextOverflow.ellipsis,maxLines: 2,),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: SizeConfig.screenWidth * 0.2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Qty:',style: TextStyle(
                          color: appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 1.4,
                          fontWeight: FontWeight.w600
                      ),),

                      Text('x$productQty',style: TextStyle(
                          color: appColorSecondary.withOpacity(0.4),
                          fontSize: SizeConfig.textMultiplier * 1.4,
                          fontWeight: FontWeight.w600
                      ),),
                    ],
                  ),
                )
              ],
            ),
          ),

          SizedBox(height: SizeConfig.heightMultiplier * 1,),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: SizeConfig.screenWidth * 0.4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Price:',style: TextStyle(
                        color: appColorSecondary,
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w600
                    ),),

                    SizedBox(
                      width: SizeConfig.screenWidth * 0.4,
                      child: Text('$productPrice PKR',style: TextStyle(
                          color: appColorSecondary.withOpacity(0.4),
                          fontSize: SizeConfig.textMultiplier * 1.4,
                          fontWeight: FontWeight.w600
                      ),overflow: TextOverflow.ellipsis,maxLines: 2,),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: SizeConfig.screenWidth * 0.2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Status:',style: TextStyle(
                        color: appColorSecondary,
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w600
                    ),),

                    Text(orderStatus,style: TextStyle(
                        color: orderStatus == 'Rejected' ? Colors.red : orderStatus == 'Completed' ? Colors.green : appColorSecondary,
                        fontSize: SizeConfig.textMultiplier * 1.4,
                        fontWeight: FontWeight.w600
                    ),),
                  ],
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
