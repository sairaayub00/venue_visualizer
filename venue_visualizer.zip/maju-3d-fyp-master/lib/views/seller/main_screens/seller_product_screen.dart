import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';
import 'package:majumodel/bloc/loader_bloc/loader_bloc.dart';
import 'package:majumodel/bloc/loader_bloc/loader_event.dart';
import 'package:majumodel/bloc/loader_bloc/loader_state.dart';
import 'package:majumodel/firebase_services/product/product_model.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:uuid/uuid.dart';
import '../../../bloc/product_quantity/product_quantity_bloc.dart';
import '../../../bloc/product_quantity/product_quantity_event.dart';
import '../../../bloc/product_tab/product_tab_bloc.dart';
import '../../../bloc/product_tab/product_tab_event.dart';
import '../../../bloc/product_tab/product_tab_state.dart';
import '../../../constants/app_color.dart';
import '../../../constants/size_config.dart';
import '../../../file_service/model_file.dart';
import '../../../reuseable_widgets/reuseable_description_screen.dart';
import '../../../reuseable_widgets/reuseable_review_sceen.dart';
import '../../../reuseable_widgets/reusebale_similar_screen.dart';
import '../seller_reuseable_widgets/reuseable_product_status_widget.dart';

class SellerProductScreen extends StatefulWidget {
  const SellerProductScreen({super.key});

  @override
  State<SellerProductScreen> createState() => _SellerProductScreenState();
}

class _SellerProductScreenState extends State<SellerProductScreen> {
  final List<String> productStatus = ['All', 'Pending', 'Live', 'Blocked'];
  int currentIndex = 0;
  File? productImage;

  final TextEditingController productName = TextEditingController();
  final TextEditingController productDescription = TextEditingController();
  final TextEditingController productPrice = TextEditingController();
  final TextEditingController productWidth = TextEditingController();
  final TextEditingController productHeight = TextEditingController();
  final TextEditingController productBreath = TextEditingController();

  final ProductService _productServices = ProductService();

  final List<String> _productCategory = ['Chair', 'Sofa', 'Bed', 'Vase', 'Home Decor', 'Home Crockery']; // Option 2
  String? _selectedCategory;

  String? sellerEmail;

  bool isLoading = false;

  final FileService _fileService = FileService();

  List<IconData> descIcon = [Iconsax.note, Iconsax.star, Iconsax.magic_star];
  List<String> descTag = ['Description', ' Reviews', 'Similar'];


  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((value){
      setState(() {
        sellerEmail = value['email'];
      });
    });
    super.initState();
    BlocProvider.of<ProductQuantityBloc>(context).add(ProductQuantityChange(1));
    BlocProvider.of<ProductTabBloc>(context).add(ProductTabChanger(0));
    BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    productName.dispose();
    productDescription.dispose();
    productPrice.dispose();
    productWidth.dispose();
    productHeight.dispose();
    productBreath.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
    body: SingleChildScrollView(
      physics: const ScrollPhysics(),
      child: Column(
          children: [

            SizedBox(height: SizeConfig.heightMultiplier * 6,),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(onPressed: (){
                  Navigator.pop(context);
                }, icon: Icon(Icons.chevron_left,color: appColorSecondary,)),
                Text('Product Management',style: TextStyle(
                    color: appColorSecondary,
                    fontSize: SizeConfig.textMultiplier * 2,
                    fontWeight: FontWeight.w600
                ),),
               GestureDetector(
                 onTap: (){
                   showModalBottomSheet(
                     backgroundColor: Colors.transparent,
                     isScrollControlled: true,
                     context: context, builder: (context) {
                     return Padding(
                       padding: EdgeInsets.only(
                         bottom: MediaQuery.of(context).viewInsets.bottom, // Adjusts for the keyboard
                       ),
                       child: StatefulBuilder(builder: (context, setState) {
                         return Container(
                           width: SizeConfig.screenWidth * 1,
                           height: SizeConfig.screenHeight * 0.6,
                           margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                           padding: const EdgeInsets.symmetric(horizontal: 8),
                           decoration: BoxDecoration(
                             color: appColorPrimary,
                             borderRadius: BorderRadius.circular(14),
                           ),
                           child: SingleChildScrollView(
                             physics: const ScrollPhysics(),
                             child: Column(
                               children: [

                                 SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                 Text('Add Product', style: TextStyle(
                                     fontSize: SizeConfig.textMultiplier * 2,
                                     color: appColorSecondary,
                                     fontWeight: FontWeight.w600
                                 ),),

                                 SizedBox(height: SizeConfig.heightMultiplier * 4,),

                                 productImage == null ? Container(
                                   width: double.infinity,
                                   height: 150,
                                   margin: const EdgeInsets.symmetric(horizontal: 20),
                                   decoration: BoxDecoration(
                                       color: appColorSecondary.withOpacity(0.4),
                                       borderRadius: BorderRadius.circular(20)
                                   ),
                                   child: Row(
                                     mainAxisAlignment: MainAxisAlignment.end,
                                     crossAxisAlignment: CrossAxisAlignment.end,
                                     children: [
                                       GestureDetector(
                                         onTap:()async{
                                           XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                           if(selectedImage != null){
                                               File convertedFile = File(selectedImage.path);
                                               setState(() {
                                                 productImage = convertedFile;
                                               });
                                               if(context.mounted){
                                                 ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                               }
                                           }
                                           else{
                                             if (context.mounted) {
                                               ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                             }
                                           }
                                         },
                                         child: Container(
                                           padding: const EdgeInsets.all(4.0),
                                           width: 100,
                                           height: 40,
                                           margin: const EdgeInsets.only(right: 14,bottom: 14),
                                           decoration: BoxDecoration(
                                               color: Colors.transparent,
                                               border: Border.all(color: appColorSecondary.withOpacity(0.3), width: 1),
                                               borderRadius: BorderRadius.circular(10)
                                           ),
                                           child: const Row(
                                             mainAxisAlignment: MainAxisAlignment.spaceAround,
                                             crossAxisAlignment: CrossAxisAlignment.center,
                                             children: [
                                               Icon(Icons.camera, size: 14,),
                                               Text("Choose Photo",style: TextStyle(fontWeight: FontWeight.w600, fontSize: 10),)
                                             ],
                                           ),
                                         ),
                                       )
                                     ],
                                   ),
                                 ) :

                                 Container(
                                   width: double.infinity,
                                   height: 150,
                                   margin: const EdgeInsets.symmetric(horizontal: 20),
                                   decoration: BoxDecoration(
                                       color: Colors.grey.withOpacity(0.2),
                                       borderRadius: BorderRadius.circular(20),
                                       image: DecorationImage(
                                           fit: BoxFit.cover,
                                           image: FileImage(productImage!))
                                   ),
                                   child: Row(
                                     mainAxisAlignment: MainAxisAlignment.end,
                                     crossAxisAlignment: CrossAxisAlignment.end,
                                     children: [
                                       GestureDetector(
                                         onTap:()async{
                                           XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                           if(selectedImage != null){
                                             File convertedFile = File(selectedImage.path);
                                             setState(() {
                                               productImage = convertedFile;
                                             });
                                             if(context.mounted){
                                               ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                             }
                                           }
                                           else{
                                             if (context.mounted) {
                                               ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                             }
                                           }
                                         },
                                         child: Container(
                                           width: 100,
                                           height: 40,
                                           padding: const EdgeInsets.all(4.0),
                                           margin: const EdgeInsets.only(right: 14,bottom: 14),
                                           decoration: BoxDecoration(
                                               color: Colors.white,
                                               border: Border.all(color: Colors.white, width: 1),
                                               borderRadius: BorderRadius.circular(10)
                                           ),
                                           child: const Row(
                                             mainAxisAlignment: MainAxisAlignment.spaceAround,
                                             crossAxisAlignment: CrossAxisAlignment.center,
                                             children: [
                                               Icon(Icons.camera, size: 14,),
                                               Text("Change Photo",style: TextStyle(fontWeight: FontWeight.w600, fontSize: 10),)
                                             ],
                                           ),
                                         ),
                                       )
                                     ],
                                   ),
                                 ),


                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productName,
                                   decoration: InputDecoration(
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                         borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Name',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productDescription,
                                   maxLines: 5,
                                   decoration: InputDecoration(
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                         borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Description',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                   keyboardType: TextInputType.text,
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 SizedBox(
                                   width: SizeConfig.screenWidth * 0.8,
                                   child: DropdownButton(
                                     iconEnabledColor: appColorSecondary,
                                     hint: Text('Select Category', style: TextStyle(color: appColorSecondary, fontSize: SizeConfig.textMultiplier * 2),), // Not necessary for Option 1
                                     value: _selectedCategory,
                                     onChanged: (newValue) {
                                       setState(() {
                                         _selectedCategory = newValue;
                                       });
                                     },
                                     items: _productCategory.map((location) {
                                       return DropdownMenuItem(
                                         value: location,
                                         child: Text(location, style: TextStyle(color: appColorSecondary, fontSize: SizeConfig.textMultiplier * 2),),
                                       );
                                     }).toList(),
                                   ),
                                 ),


                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productPrice,
                                   decoration: InputDecoration(
                                     suffixText: 'in PKR',
                                     suffixStyle: TextStyle(
                                       fontSize: SizeConfig.textMultiplier * 1.4,
                                       color: appColorSecondary.withOpacity(0.6),
                                       fontWeight: FontWeight.w600
                                     ),
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                         borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Price',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                   keyboardType: TextInputType.number,
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productWidth,
                                   decoration: InputDecoration(
                                     suffixText: 'in feet',
                                     suffixStyle: TextStyle(
                                         fontSize: SizeConfig.textMultiplier * 1.4,
                                         color: appColorSecondary.withOpacity(0.6),
                                         fontWeight: FontWeight.w600
                                     ),
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                         borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Width',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                   keyboardType: TextInputType.number,
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productHeight,
                                   decoration: InputDecoration(
                                     suffixText: 'in feet',
                                     suffixStyle: TextStyle(
                                         fontSize: SizeConfig.textMultiplier * 1.4,
                                         color: appColorSecondary.withOpacity(0.6),
                                         fontWeight: FontWeight.w600
                                     ),
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                         borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Height',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                   keyboardType: TextInputType.number,
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 TextFormField(
                                   controller: productBreath,
                                   decoration: InputDecoration(
                                     suffixText: 'in feet',
                                     suffixStyle: TextStyle(
                                         fontSize: SizeConfig.textMultiplier * 1.4,
                                         color: appColorSecondary.withOpacity(0.6),
                                         fontWeight: FontWeight.w600
                                     ),
                                     border: const UnderlineInputBorder(),
                                     focusedBorder: UnderlineInputBorder(
                                       borderSide: BorderSide(color: appColorSecondary.withOpacity(0.6))
                                     ),
                                     hintStyle: TextStyle(
                                       color: appColorSecondary,
                                     ),
                                     hintText: 'Product Breath',
                                   ),
                                   style: TextStyle(
                                     color: appColorSecondary,
                                   ),
                                   keyboardType: TextInputType.number,
                                 ),

                                 SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                 BlocBuilder<LoaderBloc, LoaderState>(builder: (context, state) {
                                   if(state is LoadState){
                                     return state.onLoad ? CircularProgressIndicator(color: appColorAccent) : ElevatedButton(
                                         style: ButtonStyle(
                                           backgroundColor: MaterialStatePropertyAll(appColorAccent),
                                         ),
                                         onPressed: (){
                                           _productServices.productAdd(ProductModel(
                                               productId: const Uuid().v1(),
                                               sellerEmail: sellerEmail!,
                                               productName: productName.text,
                                               productPrice: productPrice.text,
                                               productImage: productImage,
                                               productCategory: _selectedCategory,
                                               productDescription: productDescription.text,
                                               productWidth: productWidth.text,
                                               productHeight: productHeight.text,
                                               productBreath: productBreath.text,
                                               productStatus: "Pending",
                                               createdAt: DateTime.now().toString()

                                           ), context);
                                         }, child: Text('Add Product',style: TextStyle(
                                         fontSize: SizeConfig.textMultiplier * 1.4,
                                         color: appColorPrimary
                                     ),) );
                                   } else {
                                     return const Text("Something went wrong");
                                   }
                                 },),

                                 SizedBox(height: SizeConfig.heightMultiplier * 6,),

                               ],
                             ),
                           ),
                         );
                       },),
                     );
                   },);
                 }, child: Text('Add Product',style: TextStyle(
                   color: appColorAccent,
                   fontSize: SizeConfig.textMultiplier * 1.6,
                   fontWeight: FontWeight.w600
               ),),)
              ],
            ),

            SizedBox(height: SizeConfig.heightMultiplier * 2,),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.05,
              child: ListView.builder(
                itemCount: productStatus.length,
                scrollDirection: Axis.horizontal,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        currentIndex = index;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: currentIndex == index ? appColorAccent : Colors.transparent
                      ),
                      alignment: Alignment.center,
                      child: Text(productStatus[index],style: TextStyle(
                          color: currentIndex == index ? appColorPrimary : appColorSecondary,
                          fontSize: SizeConfig.textMultiplier * 2,
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  );
                },),
            ),

            SizedBox(
              width: SizeConfig.screenWidth * 1,
              height: SizeConfig.screenHeight * 0.75,
              child: StreamBuilder(
                    stream: _productServices.getProductBySeller(sellerEmail),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {

                        return snapshot.data!.length != 0 ? ListView.builder(
                          itemCount: snapshot.data!.length,
                          physics: const ScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            ProductModel data = snapshot.data![index];
                            String pID = data.productId;
                            String pName = data.productName!;
                            String pDesc = data.productDescription!;
                            String pCate = data.productCategory!;
                            String pImage = data.getProductImage!;
                            String pPrice = data.productPrice!;
                            String pWidth = data.productWidth!;
                            String pBreath = data.productBreath!;
                            String pHeight = data.productHeight!;
                            String pStatus = data.productStatus!;
                            String pGlb = data.glbFormat!;
                            var reviews = data.productReviews ?? "";
                            // All
                            return productStatus[currentIndex] == 'All' ? CustomProductStatusWidget(
                              productID: pID,
                              productName: pName,
                              productImage: pImage,
                              productPrice: pPrice,
                              productCategory: pCate,
                              productStatus: pStatus,
                              productOptions: (){
                                showModalBottomSheet(
                                  backgroundColor: Colors.transparent,
                                  context: context, builder: (context) {
                                  return StatefulBuilder(builder: (context, setState) {
                                    return Container(
                                      width: SizeConfig.screenWidth * 1,
                                      height: SizeConfig.screenHeight * 0.15,
                                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                      decoration: BoxDecoration(
                                        color: appColorPrimary,
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: SingleChildScrollView(
                                        physics: const ScrollPhysics(),
                                        child: Column(
                                          children: [

                                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                            Text('Actions', style: TextStyle(
                                                fontSize: SizeConfig.textMultiplier * 2,
                                                color: appColorSecondary,
                                                fontWeight: FontWeight.w600
                                            ),),

                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                SizedBox(
                                                    width: SizeConfig.screenWidth * 0.4,
                                                    child:  TextButton(onPressed: (){
                                                      Navigator.pop(context);
                                                      showDialog(
                                                        context: context, builder: (context) {
                                                        return AlertDialog(
                                                            backgroundColor: appColorPrimary,
                                                            title: Text(pName),
                                                            content: ListView.builder(
                                                              itemCount: 1,
                                                              shrinkWrap: true,
                                                              itemBuilder: (context, index) {

                                                                return SingleChildScrollView(
                                                                  physics: const ScrollPhysics(),
                                                                  child: Column(
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [

                                                                      Stack(
                                                                        children: [

                                                                          // Background Image Container

                                                                          Container(
                                                                            width: SizeConfig.screenWidth * 1,
                                                                            height: SizeConfig.screenHeight * 0.6,
                                                                            decoration:  BoxDecoration(
                                                                                color: Colors.black,
                                                                                image: DecorationImage(
                                                                                    fit: BoxFit.cover,
                                                                                    image: NetworkImage(pImage))
                                                                            ),
                                                                          ),

                                                                          // Back Button and AR View
                                                                          Positioned(
                                                                            left: 10,
                                                                            top: 40,
                                                                            right: 10,
                                                                            child: Row(
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                ClipRRect(
                                                                                  borderRadius: BorderRadius.circular(14),
                                                                                  child: BackdropFilter(
                                                                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                    child: Container(
                                                                                      width: SizeConfig.screenWidth * 0.2,
                                                                                      height: SizeConfig.screenHeight * 0.04,
                                                                                      decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(14)
                                                                                      ),
                                                                                      child: GestureDetector(
                                                                                        onTap: (){Navigator.pop(context);},
                                                                                        child: Row(
                                                                                          mainAxisAlignment: MainAxisAlignment
                                                                                              .spaceEvenly,
                                                                                          children: [
                                                                                            Icon(Icons.chevron_left,
                                                                                              color: appColorPrimary,),
                                                                                            Text('Close', style: TextStyle(
                                                                                                color: appColorPrimary,
                                                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                                                fontWeight: FontWeight.w600
                                                                                            ),),
                                                                                            SizedBox(
                                                                                              width: SizeConfig.widthMultiplier * 0.6,)
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                ClipRRect(
                                                                                  borderRadius: BorderRadius.circular(14),
                                                                                  child: BackdropFilter(
                                                                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                    child: GestureDetector(
                                                                                      onTap: (){
                                                                                        _fileService.downloadFile(pGlb, pID, context);
                                                                                      },
                                                                                      child: Container(
                                                                                        width: SizeConfig.screenWidth * 0.25,
                                                                                        height: SizeConfig.screenHeight * 0.04,
                                                                                        decoration: BoxDecoration(
                                                                                            borderRadius: BorderRadius.circular(14)
                                                                                        ),
                                                                                        child: Row(
                                                                                          mainAxisAlignment: MainAxisAlignment
                                                                                              .spaceEvenly,
                                                                                          children: [
                                                                                            Icon(
                                                                                              Iconsax.d_square, color: appColorPrimary,),
                                                                                            Text('AR View', style: TextStyle(
                                                                                                color: appColorPrimary,
                                                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                                                fontWeight: FontWeight.w600
                                                                                            ),),
                                                                                            SizedBox(
                                                                                              width: SizeConfig.widthMultiplier * 0.6,)
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              ],
                                                                            ),
                                                                          ),

                                                                          Positioned(
                                                                            left: 10,
                                                                            bottom: 80,
                                                                            child: ClipRRect(
                                                                              borderRadius: BorderRadius.circular(14),
                                                                              child: BackdropFilter(
                                                                                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                child: Container(
                                                                                  padding: const EdgeInsets.symmetric(
                                                                                      horizontal: 14, vertical: 8),
                                                                                  decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(14)
                                                                                  ),
                                                                                  child: SizedBox(
                                                                                    width: SizeConfig.screenWidth * 0.6,
                                                                                    child: Text(pName,
                                                                                      style: TextStyle(
                                                                                          color: appColorPrimary,
                                                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                                                          fontWeight: FontWeight.w600
                                                                                      ), maxLines: 2, overflow: TextOverflow.fade,),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          Positioned(
                                                                            bottom: 20,
                                                                            child: Container(
                                                                              width: SizeConfig.screenWidth * 1,
                                                                              height: SizeConfig.screenHeight * 0.05,
                                                                              alignment: Alignment.center,
                                                                              child: ListView.builder(
                                                                                itemCount: descIcon.length,
                                                                                shrinkWrap: true,
                                                                                scrollDirection: Axis.horizontal,
                                                                                physics: const ScrollPhysics(),
                                                                                itemBuilder: (context, index) {
                                                                                  return Container(
                                                                                    margin: const EdgeInsets.symmetric(horizontal: 6),
                                                                                    child: ClipRRect(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      child: BackdropFilter(
                                                                                        filter: ImageFilter.blur(
                                                                                            sigmaX: 20, sigmaY: 20),
                                                                                        child: GestureDetector(
                                                                                          onTap: () {
                                                                                            BlocProvider.of<ProductTabBloc>(context).add(ProductTabChanger(index));
                                                                                          },
                                                                                          child: BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                                                                                            if(state is ProductTabChanged){
                                                                                              return Container(
                                                                                                width: SizeConfig.screenWidth * 0.3,
                                                                                                height: SizeConfig.screenHeight * 0.03,
                                                                                                decoration: BoxDecoration(
                                                                                                    borderRadius: BorderRadius.circular(10),
                                                                                                    color: state.newTab == index
                                                                                                        ? appColorAccent
                                                                                                        : Colors.transparent
                                                                                                ),
                                                                                                child: Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment
                                                                                                      .spaceEvenly,
                                                                                                  children: [
                                                                                                    Icon(descIcon[index],
                                                                                                      color: appColorPrimary, size: 18,),
                                                                                                    SizedBox(
                                                                                                      height: SizeConfig.heightMultiplier *
                                                                                                          2,
                                                                                                      child: VerticalDivider(
                                                                                                        color: appColorPrimary,
                                                                                                        width: 2,
                                                                                                      ),
                                                                                                    ),
                                                                                                    Text(descTag[index], style: TextStyle(
                                                                                                        color: appColorPrimary,
                                                                                                        fontSize: SizeConfig
                                                                                                            .textMultiplier * 1.2,
                                                                                                        fontWeight: FontWeight.w600
                                                                                                    ),
                                                                                                      maxLines: 1,
                                                                                                      overflow: TextOverflow.fade,),
                                                                                                  ],
                                                                                                ),
                                                                                              );
                                                                                            } else {
                                                                                              return const Text('Something went wrong');
                                                                                            }
                                                                                          },),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                },),
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),

                                                                      // Description heading
                                                                      BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                                                                        if(state is ProductTabChanged){
                                                                          return state.newTab == 0 ?  CustomDescriptionWidget(
                                                                              productDescription: pDesc,
                                                                              productWidth: pWidth,
                                                                              productHeight: pHeight,
                                                                              productBreath: pBreath,
                                                                              productPrice: pPrice) : state.newTab == 1 ?
                                                                          CustomReviewWidget(reviews: reviews,) :  CustomSimilarWidget( getProductCategory: pCate, getProductID: pID,);

                                                                        } else {
                                                                          return const Center(child: Text('Something went wrong'),);
                                                                        }
                                                                      },),

                                                                    ],
                                                                  ),
                                                                );
                                                              },)
                                                        );
                                                      },);
                                                    }, child: Text('View',style: TextStyle(
                                                        fontSize: SizeConfig.textMultiplier * 2,
                                                        color: appColorAccent
                                                    ),))
                                                ),

                                                SizedBox(
                                                    width: SizeConfig.screenWidth * 0.4,
                                                    child:  TextButton(onPressed: (){
                                                      _productServices.productDelete(pID, pImage, context);
                                                    }, child: Text('Delete',style: TextStyle(
                                                        fontSize: SizeConfig.textMultiplier * 2,
                                                        color: Colors.red
                                                    ),))
                                                ),
                                              ],
                                            ),

                                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          ],
                                        ),
                                      ),
                                    );
                                  },);
                                },);

                              },
                              productDescription: (){
                                // Navigator.push(context, MaterialPageRoute(builder: (context) => const DescriptionScreen(),));
                              },
                            ) : pStatus == productStatus[currentIndex] ?
                            CustomProductStatusWidget(
                              productID: pID,
                              productName: pName,
                              productImage: pImage,
                              productPrice: pPrice,
                              productCategory: pCate,
                              productStatus: pStatus,
                              productOptions: (){
                                showModalBottomSheet(
                                  backgroundColor: Colors.transparent,
                                  context: context, builder: (context) {
                                  return StatefulBuilder(builder: (context, setState) {
                                    return Container(
                                      width: SizeConfig.screenWidth * 1,
                                      height: SizeConfig.screenHeight * 0.15,
                                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                      decoration: BoxDecoration(
                                        color: appColorPrimary,
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: SingleChildScrollView(
                                        physics: const ScrollPhysics(),
                                        child: Column(
                                          children: [

                                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                            Text('Actions', style: TextStyle(
                                                fontSize: SizeConfig.textMultiplier * 2,
                                                color: appColorSecondary,
                                                fontWeight: FontWeight.w600
                                            ),),

                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                SizedBox(
                                                    width: SizeConfig.screenWidth * 0.4,
                                                    child:  TextButton(onPressed: (){
                                                      Navigator.pop(context);
                                                      showDialog(
                                                        context: context, builder: (context) {
                                                        return AlertDialog(
                                                            backgroundColor: appColorPrimary,
                                                            title: Text(pName),
                                                            content: ListView.builder(
                                                              itemCount: 1,
                                                              shrinkWrap: true,
                                                              itemBuilder: (context, index) {

                                                                return SingleChildScrollView(
                                                                  physics: const ScrollPhysics(),
                                                                  child: Column(
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [

                                                                      Stack(
                                                                        children: [

                                                                          // Background Image Container

                                                                          Container(
                                                                            width: SizeConfig.screenWidth * 1,
                                                                            height: SizeConfig.screenHeight * 0.6,
                                                                            decoration:  BoxDecoration(
                                                                                color: Colors.black,
                                                                                image: DecorationImage(
                                                                                    fit: BoxFit.cover,
                                                                                    image: NetworkImage(pImage))
                                                                            ),
                                                                          ),

                                                                          // Back Button and AR View
                                                                          Positioned(
                                                                            left: 10,
                                                                            top: 40,
                                                                            right: 10,
                                                                            child: Row(
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                ClipRRect(
                                                                                  borderRadius: BorderRadius.circular(14),
                                                                                  child: BackdropFilter(
                                                                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                    child: Container(
                                                                                      width: SizeConfig.screenWidth * 0.2,
                                                                                      height: SizeConfig.screenHeight * 0.04,
                                                                                      decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(14)
                                                                                      ),
                                                                                      child: GestureDetector(
                                                                                        onTap: (){Navigator.pop(context);},
                                                                                        child: Row(
                                                                                          mainAxisAlignment: MainAxisAlignment
                                                                                              .spaceEvenly,
                                                                                          children: [
                                                                                            Icon(Icons.chevron_left,
                                                                                              color: appColorPrimary,),
                                                                                            Text('Close', style: TextStyle(
                                                                                                color: appColorPrimary,
                                                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                                                fontWeight: FontWeight.w600
                                                                                            ),),
                                                                                            SizedBox(
                                                                                              width: SizeConfig.widthMultiplier * 0.6,)
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                ClipRRect(
                                                                                  borderRadius: BorderRadius.circular(14),
                                                                                  child: BackdropFilter(
                                                                                    filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                    child: GestureDetector(
                                                                                      onTap: (){
                                                                                        _fileService.downloadFile(pGlb, pID, context);
                                                                                      },
                                                                                      child: Container(
                                                                                        width: SizeConfig.screenWidth * 0.25,
                                                                                        height: SizeConfig.screenHeight * 0.04,
                                                                                        decoration: BoxDecoration(
                                                                                            borderRadius: BorderRadius.circular(14)
                                                                                        ),
                                                                                        child: Row(
                                                                                          mainAxisAlignment: MainAxisAlignment
                                                                                              .spaceEvenly,
                                                                                          children: [
                                                                                            Icon(
                                                                                              Iconsax.d_square, color: appColorPrimary,),
                                                                                            Text('AR View', style: TextStyle(
                                                                                                color: appColorPrimary,
                                                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                                                fontWeight: FontWeight.w600
                                                                                            ),),
                                                                                            SizedBox(
                                                                                              width: SizeConfig.widthMultiplier * 0.6,)
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              ],
                                                                            ),
                                                                          ),

                                                                          Positioned(
                                                                            left: 10,
                                                                            bottom: 80,
                                                                            child: ClipRRect(
                                                                              borderRadius: BorderRadius.circular(14),
                                                                              child: BackdropFilter(
                                                                                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                                                                                child: Container(
                                                                                  padding: const EdgeInsets.symmetric(
                                                                                      horizontal: 14, vertical: 8),
                                                                                  decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(14)
                                                                                  ),
                                                                                  child: SizedBox(
                                                                                    width: SizeConfig.screenWidth * 0.6,
                                                                                    child: Text(pName,
                                                                                      style: TextStyle(
                                                                                          color: appColorPrimary,
                                                                                          fontSize: SizeConfig.textMultiplier * 2,
                                                                                          fontWeight: FontWeight.w600
                                                                                      ), maxLines: 2, overflow: TextOverflow.fade,),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          Positioned(
                                                                            bottom: 20,
                                                                            child: Container(
                                                                              width: SizeConfig.screenWidth * 1,
                                                                              height: SizeConfig.screenHeight * 0.05,
                                                                              alignment: Alignment.center,
                                                                              child: ListView.builder(
                                                                                itemCount: descIcon.length,
                                                                                shrinkWrap: true,
                                                                                scrollDirection: Axis.horizontal,
                                                                                physics: const ScrollPhysics(),
                                                                                itemBuilder: (context, index) {
                                                                                  return Container(
                                                                                    margin: const EdgeInsets.symmetric(horizontal: 6),
                                                                                    child: ClipRRect(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      child: BackdropFilter(
                                                                                        filter: ImageFilter.blur(
                                                                                            sigmaX: 20, sigmaY: 20),
                                                                                        child: GestureDetector(
                                                                                          onTap: () {
                                                                                            BlocProvider.of<ProductTabBloc>(context).add(ProductTabChanger(index));
                                                                                          },
                                                                                          child: BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                                                                                            if(state is ProductTabChanged){
                                                                                              return Container(
                                                                                                width: SizeConfig.screenWidth * 0.3,
                                                                                                height: SizeConfig.screenHeight * 0.03,
                                                                                                decoration: BoxDecoration(
                                                                                                    borderRadius: BorderRadius.circular(10),
                                                                                                    color: state.newTab == index
                                                                                                        ? appColorAccent
                                                                                                        : Colors.transparent
                                                                                                ),
                                                                                                child: Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment
                                                                                                      .spaceEvenly,
                                                                                                  children: [
                                                                                                    Icon(descIcon[index],
                                                                                                      color: appColorPrimary, size: 18,),
                                                                                                    SizedBox(
                                                                                                      height: SizeConfig.heightMultiplier *
                                                                                                          2,
                                                                                                      child: VerticalDivider(
                                                                                                        color: appColorPrimary,
                                                                                                        width: 2,
                                                                                                      ),
                                                                                                    ),
                                                                                                    Text(descTag[index], style: TextStyle(
                                                                                                        color: appColorPrimary,
                                                                                                        fontSize: SizeConfig
                                                                                                            .textMultiplier * 1.2,
                                                                                                        fontWeight: FontWeight.w600
                                                                                                    ),
                                                                                                      maxLines: 1,
                                                                                                      overflow: TextOverflow.fade,),
                                                                                                  ],
                                                                                                ),
                                                                                              );
                                                                                            } else {
                                                                                              return const Text('Something went wrong');
                                                                                            }
                                                                                          },),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                },),
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),

                                                                      // Description heading
                                                                      BlocBuilder<ProductTabBloc, ProductTabState>(builder: (context, state) {
                                                                        if(state is ProductTabChanged){
                                                                          return state.newTab == 0 ?  CustomDescriptionWidget(
                                                                              productDescription: pDesc,
                                                                              productWidth: pWidth,
                                                                              productHeight: pHeight,
                                                                              productBreath: pBreath,
                                                                              productPrice: pPrice) : state.newTab == 1 ?
                                                                          CustomReviewWidget(reviews: reviews,) :  CustomSimilarWidget( getProductCategory: pCate, getProductID: pID,);

                                                                        } else {
                                                                          return const Center(child: Text('Something went wrong'),);
                                                                        }
                                                                      },),

                                                                    ],
                                                                  ),
                                                                );
                                                              },)
                                                        );
                                                      },);
                                                    }, child: Text('View',style: TextStyle(
                                                        fontSize: SizeConfig.textMultiplier * 2,
                                                        color: appColorAccent
                                                    ),))
                                                ),

                                                SizedBox(
                                                    width: SizeConfig.screenWidth * 0.4,
                                                    child:  TextButton(onPressed: (){
                                                      _productServices.productDelete(pID, pImage, context);
                                                    }, child: Text('Delete',style: TextStyle(
                                                        fontSize: SizeConfig.textMultiplier * 2,
                                                        color: Colors.red
                                                    ),))
                                                ),
                                              ],
                                            ),

                                            SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                          ],
                                        ),
                                      ),
                                    );
                                  },);
                                },);

                              },
                              productDescription: (){
                                // Navigator.push(context, MaterialPageRoute(builder: (context) => const DescriptionScreen(),));
                              },
                            ) :
                            Container();
                          },) : Center(child: Text('Added Product Will be shown here',style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 1.4
                        ),),);
                      } else if (snapshot.hasError) {
                        return const Center(child: Icon(Icons.error_outline,color: Colors.red,));
                      } else {
                        return  Center(child: CircularProgressIndicator(color: appColorSecondary,));
                      }
                    }))



          ]),
    )
    );
  }
}
