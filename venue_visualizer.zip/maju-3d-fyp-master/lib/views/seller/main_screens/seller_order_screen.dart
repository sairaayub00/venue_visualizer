import 'package:flutter/material.dart';
import 'package:majumodel/constants/size_config.dart';
import 'package:majumodel/firebase_services/order/order_model.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';

import '../../../constants/app_color.dart';
import '../seller_reuseable_widgets/reuseable_order_status_widget.dart';

class SellerOrderScreen extends StatefulWidget {
  const SellerOrderScreen({super.key});

  @override
  State<SellerOrderScreen> createState() => _SellerOrderScreenState();
}

class _SellerOrderScreenState extends State<SellerOrderScreen> {

  final List<String> orderOption = ['All', 'Pending', 'Completed', 'Rejected'];
  int currentIndex = 0;

  final OrderService _orderService  = OrderService();

  String sellerEmail = "";

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((val){
      setState(() {
        sellerEmail = val['email'];
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: appColorPrimary,
      body: Column(
        children: [

        SizedBox(height: SizeConfig.heightMultiplier * 6,),

      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.chevron_left,color: appColorSecondary,)),
          Text('Order Management',style: TextStyle(
              color: appColorSecondary,
              fontSize: SizeConfig.textMultiplier * 2,
              fontWeight: FontWeight.w600
          ),),
         const Icon(Icons.chevron_left,color: Colors.transparent,),
        ],
      ),

          SizedBox(height: SizeConfig.heightMultiplier * 2,),

          SizedBox(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.05,
            child: ListView.builder(
              itemCount: orderOption.length,
              scrollDirection: Axis.horizontal,
              physics: const ScrollPhysics(),
              shrinkWrap: true,
              itemBuilder: (context, index) {
              return GestureDetector(
                onTap: (){
                  setState(() {
                    currentIndex = index;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: currentIndex == index ? appColorAccent : Colors.transparent
                  ),
                  alignment: Alignment.center,
                  child: Text(orderOption[index],style: TextStyle(
                      color: currentIndex == index ? appColorPrimary : appColorSecondary,
                      fontSize: SizeConfig.textMultiplier * 2,
                      fontWeight: FontWeight.w600
                  ),),
                ),
              );
            },),
          ),

          SizedBox(height: SizeConfig.heightMultiplier * 2,),


          SizedBox(
            width: SizeConfig.screenWidth * 1,
            height: SizeConfig.screenHeight * 0.75,
            child: StreamBuilder(stream: _orderService.getAllOrder(), builder: (context, snapshot) {
              if(snapshot.connectionState == ConnectionState.waiting){
                return const Center(child: CircularProgressIndicator(),);
              }
              else if(snapshot.hasData){
                return snapshot.data!.length != 0 ? ListView.builder(
                  itemCount: snapshot.data!.length,
                  physics: const ScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {

                    OrderModel data = snapshot.data![index];

                    final String orderID = data.orderID;
                    final String shippingID = data.shippingID;
                    final String userID = data.userEmailID;
                    final String cardID = data.cardID;
                    var orderItem = data.orderItem;
                    final String productPrice = data.orderPrice;
                    final String orderStatus = data.orderStatus;
                    final String createdAt = data.createdAt;

                    return orderOption[currentIndex] == 'All' ?
                    ListView.builder(
                      itemCount: orderItem.length,
                      physics: const ScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                      return orderItem[index]["sellerID"] == sellerEmail ?
                      GestureDetector(
                        onDoubleTap: (){
                          showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            context: context, builder: (context) {
                            return Container(
                              width: SizeConfig.screenWidth * 1,
                              height: SizeConfig.screenHeight * 0.25,
                              margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: appColorPrimary
                              ),
                              child: ListView.builder(
                                itemCount: orderItem.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return orderItem[index]["sellerID"] == sellerEmail ? Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.14,
                                    margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
                                    padding: const EdgeInsets.all(6.0),
                                    decoration: BoxDecoration(
                                        color: appColorPrimary,
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          BoxShadow(
                                              color: appColorSecondary.withOpacity(0.4),
                                              spreadRadius: 1,
                                              blurRadius: 6
                                          )
                                        ]
                                    ),
                                    child: Row(
                                      children: [
                                        // Image Container
                                        Container(
                                          width: SizeConfig.screenWidth * 0.2,
                                          height: SizeConfig.screenHeight * 0.14,
                                          decoration: BoxDecoration(
                                              color: Colors.grey.shade300,
                                              borderRadius: BorderRadius.circular(14),
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: NetworkImage(orderItem[index]['pImage']))
                                          ),
                                        ),

                                        SizedBox(width: SizeConfig.widthMultiplier * 2,),

                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child: Text(orderItem[index]['pName'],style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 1.8,
                                                  color: appColorSecondary,
                                                  fontWeight: FontWeight.w600
                                              ),maxLines: 2,overflow: TextOverflow.ellipsis,),
                                            ),
                                            SizedBox(height: SizeConfig.heightMultiplier * 1,),
                                            SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text('${orderItem[index]['pPrice']} / Unit',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 1.4,
                                                      color: appColorSecondary.withOpacity(0.6),
                                                      fontWeight: FontWeight.w400
                                                  ),),
                                                ],
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ) : Container();
                                },),
                            );
                          },);
                        },
                        onTap: (){
                          showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            context: context, builder: (context) {
                            return StatefulBuilder(builder: (context, setState) {
                              return Container(
                                width: SizeConfig.screenWidth * 1,
                                height: SizeConfig.screenHeight * 0.15,
                                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  color: appColorPrimary,
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: SingleChildScrollView(
                                  physics: const ScrollPhysics(),
                                  child: Column(
                                    children: [

                                      SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                      Text('Actions', style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier * 2,
                                          color: appColorSecondary,
                                          fontWeight: FontWeight.w600
                                      ),),

                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child:  TextButton(onPressed: (){
                                                _orderService.updateOrder(OrderModel(
                                                    orderID: orderID,
                                                    sellerID: sellerEmail,
                                                    orderItem: orderItem,
                                                    orderPrice: productPrice,
                                                    userEmailID: userID,
                                                    orderStatus: "Rejected",
                                                    shippingID: shippingID,
                                                    cardID: cardID,
                                                    createdAt: createdAt
                                                ), context);
                                              }, child: Text('Rejected',style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: Colors.red
                                              ),))
                                          ),

                                          SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child:  TextButton(onPressed: (){
                                                _orderService.updateOrder(OrderModel(
                                                    orderID: orderID,
                                                    sellerID: sellerEmail,
                                                    orderItem: orderItem,
                                                    orderPrice: productPrice,
                                                    orderStatus: "Completed",
                                                    shippingID: shippingID,
                                                    userEmailID: userID,
                                                    cardID: cardID,
                                                    createdAt: createdAt
                                                ), context);
                                              }, child: Text('Completed',style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: Colors.green
                                              ),))
                                          ),
                                        ],
                                      ),

                                      SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    ],
                                  ),
                                ),
                              );
                            },);
                          },);

                        },
                        child: CustomOrderStatusWidget(
                          orderID: orderID,
                          productName: userID,
                          productQty: orderItem.length.toString(),
                          productPrice: productPrice,
                          orderStatus: orderStatus,

                        ),
                      ) :
                      Container();
                    },) :
                    orderStatus == orderOption[currentIndex]  ?
                    ListView.builder(
                      itemCount: orderItem.length,
                      physics: const ScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                      return orderItem[index]["sellerID"] == sellerEmail ?
                      GestureDetector(
                        onDoubleTap: (){
                          showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            context: context, builder: (context) {
                            return Container(
                              width: SizeConfig.screenWidth * 1,
                              height: SizeConfig.screenHeight * 0.25,
                              margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: appColorPrimary
                              ),
                              child: ListView.builder(
                                itemCount: orderItem.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return orderItem[index]["sellerID"] == sellerEmail ? Container(
                                    width: SizeConfig.screenWidth * 1,
                                    height: SizeConfig.screenHeight * 0.14,
                                    margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 14),
                                    padding: const EdgeInsets.all(6.0),
                                    decoration: BoxDecoration(
                                        color: appColorPrimary,
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          BoxShadow(
                                              color: appColorSecondary.withOpacity(0.4),
                                              spreadRadius: 1,
                                              blurRadius: 6
                                          )
                                        ]
                                    ),
                                    child: Row(
                                      children: [
                                        // Image Container
                                        Container(
                                          width: SizeConfig.screenWidth * 0.2,
                                          height: SizeConfig.screenHeight * 0.14,
                                          decoration: BoxDecoration(
                                              color: Colors.grey.shade300,
                                              borderRadius: BorderRadius.circular(14),
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: NetworkImage(orderItem[index]['pImage']))
                                          ),
                                        ),

                                        SizedBox(width: SizeConfig.widthMultiplier * 2,),

                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child: Text(orderItem[index]['pName'],style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 1.8,
                                                  color: appColorSecondary,
                                                  fontWeight: FontWeight.w600
                                              ),maxLines: 2,overflow: TextOverflow.ellipsis,),
                                            ),
                                            SizedBox(height: SizeConfig.heightMultiplier * 1,),
                                            SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text('${orderItem[index]['pPrice']} / Unit',style: TextStyle(
                                                      fontSize: SizeConfig.textMultiplier * 1.4,
                                                      color: appColorSecondary.withOpacity(0.6),
                                                      fontWeight: FontWeight.w400
                                                  ),),
                                                ],
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ) : Container();
                                },),
                            );
                          },);
                        },
                        onTap: (){
                          showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            context: context, builder: (context) {
                            return StatefulBuilder(builder: (context, setState) {
                              return Container(
                                width: SizeConfig.screenWidth * 1,
                                height: SizeConfig.screenHeight * 0.15,
                                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  color: appColorPrimary,
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: SingleChildScrollView(
                                  physics: const ScrollPhysics(),
                                  child: Column(
                                    children: [

                                      SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                      Text('Actions', style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier * 2,
                                          color: appColorSecondary,
                                          fontWeight: FontWeight.w600
                                      ),),

                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child:  TextButton(onPressed: (){
                                                _orderService.updateOrder(OrderModel(
                                                    orderID: orderID,
                                                    sellerID: sellerEmail,
                                                    orderItem: orderItem,
                                                    orderPrice: productPrice,
                                                    userEmailID: userID,
                                                    orderStatus: "Rejected",
                                                    shippingID: shippingID,
                                                    cardID: cardID,
                                                    createdAt: createdAt
                                                ), context);
                                              }, child: Text('Rejected',style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: Colors.red
                                              ),))
                                          ),

                                          SizedBox(
                                              width: SizeConfig.screenWidth * 0.4,
                                              child:  TextButton(onPressed: (){
                                                _orderService.updateOrder(OrderModel(
                                                    orderID: orderID,
                                                    sellerID: sellerEmail,
                                                    orderItem: orderItem,
                                                    orderPrice: productPrice,
                                                    orderStatus: "Completed",
                                                    shippingID: shippingID,
                                                    userEmailID: userID,
                                                    cardID: cardID,
                                                    createdAt: createdAt
                                                ), context);
                                              }, child: Text('Completed',style: TextStyle(
                                                  fontSize: SizeConfig.textMultiplier * 2,
                                                  color: Colors.green
                                              ),))
                                          ),
                                        ],
                                      ),

                                      SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                    ],
                                  ),
                                ),
                              );
                            },);
                          },);

                        },
                        child: CustomOrderStatusWidget(
                          orderID: orderID,
                          productName: userID,
                          productQty: orderItem.length.toString(),
                          productPrice: productPrice,
                          orderStatus: orderStatus,
                        ),
                      ) :
                      Container();
                    },) :
                    Container();
                  },) :  const Center(child: Text('Nothing to Show'),);
              }
              else{
                return const Center(child: Icon(Icons.error,color: Colors.red,),);
              }
            },),
          )

        ])
    );
  }
}
