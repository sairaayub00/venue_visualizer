import 'dart:io';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';
import 'package:majumodel/bloc/loader_bloc/loader_state.dart';
import 'package:majumodel/firebase_services/order/order_model.dart';
import 'package:majumodel/firebase_services/order/order_service.dart';
import 'package:majumodel/firebase_services/product/product_service.dart';
import 'package:majumodel/firebase_services/user/user_model.dart';
import 'package:majumodel/firebase_services/user/user_services.dart';
import 'package:majumodel/views/seller/main_screens/seller_order_screen.dart';
import 'package:majumodel/views/seller/main_screens/seller_product_screen.dart';
import '../../../bloc/loader_bloc/loader_bloc.dart';
import '../../../bloc/loader_bloc/loader_event.dart';
import '../../../constants/app_color.dart';
import '../../../constants/size_config.dart';
import '../../../firebase_services/product/product_model.dart';
import '../../../reuseable_widgets/reuseable_textfield.dart';
import '../seller_reuseable_widgets/reuseable_order_status_widget.dart';
import '../seller_reuseable_widgets/reuseable_product_status_widget.dart';

class SellerHomeScreen extends StatefulWidget {
  const SellerHomeScreen({super.key});

  @override
  State<SellerHomeScreen> createState() => _SellerHomeScreenState();
}

class _SellerHomeScreenState extends State<SellerHomeScreen> {
  String sellerEmail = '';

  final ProductService _productService = ProductService();
  final UserServices _userServices = UserServices();
  final OrderService _orderService = OrderService();

  final TextEditingController userName = TextEditingController();
  final TextEditingController userAge = TextEditingController();
  final TextEditingController userPhone = TextEditingController();
  final List<String> _gender = ['Male', 'Female']; // Option 2

  File? userProfile;

  @override
  void initState() {
    // TODO: implement initState
    UserServices.userCredGet().then((value) {
      setState(() {
        sellerEmail = value['email'];
      });
    });
    BlocProvider.of<LoaderBloc>(context).add(LoadEvent(false));
    super.initState();
  }

    List liveProductCount = [];
    List rejectedProductCount = [];

    List completedOrder = [];
    List pendingOrder = [];
    List rejectedOrder = [];

  @override
  void dispose() {
    // TODO: implement dispose
    userName.dispose();
    userAge.dispose();
    userPhone.dispose();
    liveProductCount.clear();
    rejectedProductCount.clear();
    completedOrder.clear();
    pendingOrder.clear();
    rejectedOrder.clear();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) => exit(0),
      child: Scaffold(
        backgroundColor: appColorPrimary,
        body: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Container(
            width: SizeConfig.screenWidth * 1,
            margin: const EdgeInsets.symmetric(horizontal: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                SizedBox(height: SizeConfig.heightMultiplier * 0.6,),
                // Name heading
                SizedBox(
                  width: SizeConfig.screenWidth * 1,
                  height: SizeConfig.screenHeight * 0.1,
                  child: StreamBuilder(
                      stream: _userServices.getUser(sellerEmail),
                      builder: (BuildContext context, AsyncSnapshot snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            shrinkWrap: true,
                            itemCount: 1,
                            itemBuilder: (context, index) {
                              UserModel userModel = snapshot.data![index];
                              String? uID = userModel.userID;
                              String? uName = userModel.userName;
                              String? uRole = userModel.userRole;
                              String? getImage = userModel.getImage;
                              String? uAge = userModel.userAge;
                              String? uGender = userModel.userGender;
                              String? uPhone = userModel.userPhone;
                              String? uEmail = userModel.userEmail;
                              String uPassword = userModel.userPassword;
                              bool? uStatus = userModel.userStatus;
                              String? createdAt = userModel.createdAt;
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(uName!,style: TextStyle(
                                        color: appColorSecondary.withOpacity(0.6),
                                        fontSize: SizeConfig.textMultiplier * 1.8,
                                        fontWeight: FontWeight.w600
                                    ),),
                                    Text(uEmail!,style: TextStyle(
                                        color: appColorSecondary.withOpacity(0.4),
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        fontWeight: FontWeight.w600
                                    ),),
                                  ],
                                ),

                                GestureDetector(
                                  onTap: (){
                                    showModalBottomSheet(
                                      backgroundColor: Colors.transparent,
                                      context: context, builder:  (context) {
                                      return StatefulBuilder(builder: (context, setState) {
                                        return Container(
                                          width: SizeConfig.screenWidth * 1,
                                          height: SizeConfig.screenHeight * 0.6,
                                          margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 20),
                                          decoration: BoxDecoration(
                                              color: appColorPrimary,
                                              borderRadius: BorderRadius.circular(14)
                                          ),
                                          child: SingleChildScrollView(
                                              physics: const ScrollPhysics(),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [

                                                  SizedBox(height: SizeConfig.heightMultiplier * 6,),

                                                  Center(
                                                    child: CircleAvatar(
                                                      radius: 50,
                                                      backgroundImage: NetworkImage(getImage),
                                                    ),
                                                  ),

                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                  Center(
                                                    child: Text(uName,style: TextStyle(
                                                        color: appColorSecondary,
                                                        fontSize: SizeConfig.textMultiplier * 2,
                                                        fontWeight: FontWeight.w800
                                                    ),),
                                                  ),

                                                  Center(
                                                    child: Text(uEmail,style: TextStyle(
                                                        color: appColorSecondary.withOpacity(0.6),
                                                        fontSize: SizeConfig.textMultiplier * 1.5,
                                                        fontWeight: FontWeight.w600
                                                    ),),
                                                  ),

                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),


                                                  Center(
                                                    child: ElevatedButton(
                                                      style: ButtonStyle(
                                                          backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                                      ),
                                                      onPressed: (){
                                                        Navigator.pop(context);
                                                        userName.text = uName;
                                                        userAge.text = uAge!;
                                                        userPhone.text = uPhone!;
                                                        showDialog(
                                                          context: context, builder: (context) {
                                                          return StatefulBuilder(builder:  (context, setState) {
                                                            return AlertDialog(
                                                              backgroundColor: appColorSecondary.withOpacity(0.4),
                                                              content: SingleChildScrollView(
                                                                physics: const ScrollPhysics(),
                                                                child: Column(
                                                                  children: [

                                                                    userProfile == null ? GestureDetector(
                                                                      onTap:()async{
                                                                        XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                                                        if(selectedImage != null){

                                                                          File convertedFile = File(selectedImage.path);
                                                                          setState(() {
                                                                            userProfile = convertedFile;
                                                                          });
                                                                          if(context.mounted){
                                                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                                                          }
                                                                        }
                                                                        else{
                                                                          if (context.mounted) {
                                                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                                                          }
                                                                        }
                                                                      },
                                                                      child: Container(
                                                                        margin: const EdgeInsets.symmetric(vertical: 10),
                                                                        alignment: Alignment.center,
                                                                        child: CircleAvatar(
                                                                          radius: 30,
                                                                          backgroundColor: appColorPrimary,
                                                                          backgroundImage: NetworkImage(getImage),
                                                                        ),
                                                                      ),
                                                                    ) :
                                                                    GestureDetector(
                                                                      onTap:()async{
                                                                        XFile? selectedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
                                                                        if(selectedImage != null){
                                                                          File convertedFile = File(selectedImage.path);
                                                                          setState(() {
                                                                            userProfile = convertedFile;
                                                                          });
                                                                          if(context.mounted){
                                                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image Selected"),backgroundColor: Colors.green, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                                                          }
                                                                        }
                                                                        else{
                                                                          if (context.mounted) {
                                                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Image not Selected"),backgroundColor: Colors.red, margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),behavior: SnackBarBehavior.floating,));
                                                                          }
                                                                        }
                                                                      },
                                                                      child: Container(
                                                                        alignment: Alignment.center,
                                                                        margin: const EdgeInsets.symmetric(vertical: 10),
                                                                        child: CircleAvatar(
                                                                          radius: 30,
                                                                          backgroundImage: userProfile != null ? FileImage(userProfile!) : null,
                                                                        ),
                                                                      ),
                                                                    ),

                                                                    SizedBox(
                                                                      height: SizeConfig.heightMultiplier * 2,
                                                                    ),

                                                                    CustomTextField(
                                                                        fieldController: userName,
                                                                        hintText: 'Enter Your Name Here',
                                                                        fieldIcon: Iconsax.user,
                                                                        errorText: 'username is Required'),

                                                                    SizedBox(
                                                                      height: SizeConfig.heightMultiplier * 2,
                                                                    ),

                                                                    CustomTextField(
                                                                        fieldController: userAge,
                                                                        hintText: 'Enter Your Age Here',
                                                                        fieldIcon: Iconsax.graph,
                                                                        errorText: 'Age is Required'),


                                                                    Container(
                                                                      margin: const EdgeInsets.only(left: 10),
                                                                      width: SizeConfig.screenWidth * 0.8,
                                                                      child: DropdownButton(
                                                                        isExpanded: true,
                                                                        iconEnabledColor: appColorPrimary,
                                                                        hint: Text('Your Gender', style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),), // Not necessary for Option 1
                                                                        value: uGender,
                                                                        onChanged: (newValue) {
                                                                          setState(() {
                                                                            uGender = newValue;
                                                                          });
                                                                        },
                                                                        items: _gender.map((location) {
                                                                          return DropdownMenuItem(
                                                                            value: location,
                                                                            child: Text(location, style: TextStyle(color: appColorPrimary, fontSize: SizeConfig.textMultiplier * 2),),
                                                                          );
                                                                        }).toList(),
                                                                      ),
                                                                    ),

                                                                    SizedBox(
                                                                      height: SizeConfig.heightMultiplier * 2,
                                                                    ),

                                                                    CustomTextField(
                                                                        fieldController: userPhone,
                                                                        hintText: 'Enter Your Phone Number Here',
                                                                        fieldIcon: Iconsax.call,
                                                                        errorText: 'Phone number is Required'),

                                                                    SizedBox(
                                                                      height: SizeConfig.heightMultiplier * 2,
                                                                    ),

                                                                    Align(
                                                                      alignment: Alignment.centerRight,
                                                                      child: BlocBuilder<LoaderBloc, LoaderState>(builder: (context, state) {
                                                                        if(state is LoadState){
                                                                          return state.onLoad ? CircularProgressIndicator(color: appColorAccent,) : ElevatedButton(
                                                                              style: ButtonStyle(
                                                                                  backgroundColor: MaterialStatePropertyAll(appColorAccent)
                                                                              ),
                                                                              onPressed: (){
                                                                                if(userProfile == null){
                                                                                  _userServices.userUpdate(UserModel(
                                                                                    userID: uID,
                                                                                    userName: userName.text.toString(),
                                                                                    userAge: userAge.text.toString(),
                                                                                    userRole: uRole,
                                                                                    userGender: uGender,
                                                                                    userPhone: userPhone.text.toString(),
                                                                                    userEmail: uEmail,
                                                                                    userPassword: uPassword,
                                                                                    userStatus: uStatus,
                                                                                    getImage: getImage,
                                                                                    createdAt: createdAt,
                                                                                  ), context);
                                                                                } else {
                                                                                  _userServices.userUpdate(UserModel(
                                                                                    userID: uID,
                                                                                    userName: userName.text.toString(),
                                                                                    userAge: userAge.text.toString(),
                                                                                    userRole: uRole,
                                                                                    userGender: uGender,
                                                                                    userPhone: userPhone.text.toString(),
                                                                                    userEmail: uEmail,
                                                                                    userPassword: uPassword,
                                                                                    userStatus: uStatus,
                                                                                    getImage: getImage,
                                                                                    userImage: userProfile!,
                                                                                    createdAt: createdAt,
                                                                                  ), context);
                                                                                }

                                                                              }, child: Text('Update',style: TextStyle(
                                                                              fontSize: SizeConfig.textMultiplier * 2,
                                                                              fontWeight: FontWeight.w600,
                                                                              color: appColorPrimary
                                                                          ),));
                                                                        } else{
                                                                          return const Text("Something went wrong");
                                                                        }
                                                                      },),
                                                                    ),

                                                                  ],
                                                                ),
                                                              ),
                                                            );
                                                          },);
                                                        },);
                                                      }, child: Text('Edit Profile',style: TextStyle(
                                                        color: appColorPrimary,
                                                        fontSize: SizeConfig.textMultiplier * 1.5,
                                                        fontWeight: FontWeight.w600
                                                    ),),),
                                                  ),

                                                  SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                  SizedBox(
                                                    width: SizeConfig.screenWidth * 1,
                                                    height: SizeConfig.screenHeight * 0.3,
                                                    child: SingleChildScrollView(
                                                      physics: const ScrollPhysics(),
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: const EdgeInsets.only(left: 14),
                                                            child: Text('Password',style: TextStyle(
                                                                color: appColorSecondary,
                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                fontWeight: FontWeight.w600
                                                            ),),
                                                          ),

                                                          Container(
                                                            width: SizeConfig.screenWidth * 1,
                                                            margin: const EdgeInsets.symmetric(horizontal: 10),
                                                            decoration: BoxDecoration(
                                                                color: appColorPrimary
                                                            ),
                                                            child: ListTile(
                                                              onTap: (){
                                                                _userServices.userPasswordRequest(sellerEmail, context);
                                                              },
                                                              leading: const Icon(Iconsax.password_check),
                                                              title: Text('Request Password Change',style: TextStyle(
                                                                  color: appColorSecondary,
                                                                  fontSize: SizeConfig.textMultiplier * 1.5,
                                                                  fontWeight: FontWeight.w600
                                                              ),),
                                                              trailing: Icon(Icons.chevron_right, color: appColorSecondary,),
                                                            ),
                                                          ),

                                                          SizedBox(height: SizeConfig.heightMultiplier * 2,),

                                                          Container(
                                                            margin: const EdgeInsets.only(left: 14),
                                                            child: Text('Account Management',style: TextStyle(
                                                                color: appColorSecondary,
                                                                fontSize: SizeConfig.textMultiplier * 1.5,
                                                                fontWeight: FontWeight.w600
                                                            ),),
                                                          ),

                                                          Container(
                                                            width: SizeConfig.screenWidth * 1,
                                                            margin: const EdgeInsets.symmetric(horizontal: 10),
                                                            decoration: BoxDecoration(
                                                                color: appColorPrimary
                                                            ),
                                                            child: GestureDetector(
                                                              onTap: (){
                                                                _userServices.userLogout(context);
                                                              },
                                                              child: ListTile(
                                                                leading: const Icon(Iconsax.logout),
                                                                title: Text('Log out',style: TextStyle(
                                                                    color: appColorSecondary,
                                                                    fontSize: SizeConfig.textMultiplier * 1.5,
                                                                    fontWeight: FontWeight.w600
                                                                ),),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            width: SizeConfig.screenWidth * 1,
                                                            margin: const EdgeInsets.symmetric(horizontal: 10),
                                                            decoration: BoxDecoration(
                                                                color: appColorPrimary
                                                            ),
                                                            child: GestureDetector(
                                                              onTap: (){
                                                               _userServices.userDelete(uID, getImage, context);
                                                              },
                                                              child: ListTile(
                                                                leading: const Icon(Iconsax.trash, color: Colors.red,),
                                                                title: Text('Delete Account',style: TextStyle(
                                                                    color: Colors.red,
                                                                    fontSize: SizeConfig.textMultiplier * 1.5,
                                                                    fontWeight: FontWeight.w600
                                                                ),),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(height: SizeConfig.heightMultiplier * 0.5,),
                                                        ],
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              )),
                                        );
                                      },);
                                    },);
                                  },
                                  child: CircleAvatar(
                                    radius: 20,
                                    backgroundImage: NetworkImage(getImage!),
                                  ),
                                ),
                              ],
                            );
                          },);
                        } else if (snapshot.hasError) {
                          return const Icon(Icons.error_outline);
                        } else {
                          return Container();
                        }
                      }),
                ),


               // About Order
               SizedBox(
                 width: SizeConfig.screenWidth * 1,
                 height: SizeConfig.screenHeight * 0.05,
                 child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                   children: [
                     Container(
                       margin: const EdgeInsets.only(left: 10, top: 10),
                       child: Text('About Your Orders:',style: TextStyle(
                           color: appColorSecondary.withOpacity(0.4),
                           fontSize: SizeConfig.textMultiplier * 2,
                           fontWeight: FontWeight.w600
                       ),),
                     ),
                     Container(
                       margin: const EdgeInsets.only(left: 10, top: 10),
                       child: GestureDetector(
                         onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (context) => const SellerOrderScreen(),));
                         },
                         child: Text('Manage Your Orders',style: TextStyle(
                             color: appColorAccent,
                             fontSize: SizeConfig.textMultiplier * 1.4,
                             fontWeight: FontWeight.w600
                         ),),
                       ),
                     ),
                   ],
                 ),
               ),
                // Order Counter
                StreamBuilder(stream: _orderService.getOrder(sellerEmail), builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return const Center(child: Text('Loading Data'),);
                  } else if(snapshot.hasData){
                    return ListView.builder(
                      itemCount: 1,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        // Loop through all products in the snapshot
                        for (var doc in snapshot.data!) {
                          OrderModel oData = doc;

                          String oStatus = oData.orderStatus ?? '';

                          // Increment the respective counter based on the status
                          if (oStatus == "Completed") {
                            completedOrder.add(oStatus);
                          } else if (oStatus == "Pending") {
                            pendingOrder.add(oStatus);
                          } else if(oStatus == "Rejected"){
                            rejectedOrder.add(oStatus);
                          } else{

                          }
                        }
                      return SizedBox(
                        width: SizeConfig.screenWidth * 1,
                        height: SizeConfig.screenHeight * 0.11,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [

                            Column(
                              children: [
                                Text('Pending Orders:',style: TextStyle(
                                    color: appColorSecondary,
                                    fontSize: SizeConfig.textMultiplier * 1.4,
                                    fontWeight: FontWeight.w600
                                ),),

                                Text('${pendingOrder.length}',style: TextStyle(
                                    color: appColorSecondary.withOpacity(0.4),
                                    fontSize: SizeConfig.textMultiplier * 6,
                                    fontWeight: FontWeight.w600
                                ),),
                              ],
                            ),
                            Column(
                              children: [
                                Text('Finished Orders:',style: TextStyle(
                                    color: appColorSecondary,
                                    fontSize: SizeConfig.textMultiplier * 1.4,
                                    fontWeight: FontWeight.w600
                                ),),

                                Text('${completedOrder.length}',style: TextStyle(
                                    color: appColorSecondary.withOpacity(0.4),
                                    fontSize: SizeConfig.textMultiplier * 6,
                                    fontWeight: FontWeight.w600
                                ),),
                              ],
                            ),
                            Column(
                              children: [
                                Text('Rejected Orders:',style: TextStyle(
                                    color: appColorSecondary,
                                    fontSize: SizeConfig.textMultiplier * 1.4,
                                    fontWeight: FontWeight.w600
                                ),),

                                Text('${rejectedOrder.length}',style: TextStyle(
                                    color: appColorSecondary.withOpacity(0.4),
                                    fontSize: SizeConfig.textMultiplier * 6,
                                    fontWeight: FontWeight.w600
                                ),),
                              ],
                            ),
                          ],
                        ),
                      );
                    },);
                  } else {
                    return Container();
                  }
                },),

                SizedBox(height: SizeConfig.heightMultiplier * 1),

               // Orders
                StreamBuilder(stream: _orderService.getOrder(sellerEmail), builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return Container();
                  } else if(snapshot.hasData){
                    return  snapshot.data!.length != 0 ? CarouselSlider(
                        items: List.generate(snapshot.data!.length,  (index) {
                          OrderModel orderData = snapshot.data![index];
                          String orderID = orderData.orderID;
                          String userID = orderData.userEmailID;
                          // String productID = orderData.userEmailID;
                          List orderItem = orderData.orderItem;
                          String productPrice = orderData.orderPrice;
                          String orderStatus = orderData.orderStatus;
                          return CustomOrderStatusWidget(
                            orderID: orderID,
                            productName: userID,
                            productQty: orderItem.length.toString(),
                            productPrice: productPrice,
                            orderStatus: orderStatus,
                          );
                        },), options: CarouselOptions(
                        autoPlay: true,
                        viewportFraction: 1,
                        height: SizeConfig.screenHeight * 0.24,
                        enlargeCenterPage: true,
                        autoPlayInterval: const Duration(milliseconds: 2000)
                    )) : const Center(child: Text('Nothing to Show'),);
                  } else {
                    return const Center(child: Icon(Icons.error,color: Colors.red,),);
                  }
                },),
               //
                SizedBox(height: SizeConfig.heightMultiplier * 1),

                //About product
                SizedBox(
                  width: SizeConfig.screenWidth * 1,
                  height: SizeConfig.screenHeight * 0.035,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 10),
                        child: Text('About Your Products:',style: TextStyle(
                            color: appColorSecondary.withOpacity(0.4),
                            fontSize: SizeConfig.textMultiplier * 2,
                            fontWeight: FontWeight.w600
                        ),),
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 10),
                        child: GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const SellerProductScreen(),));
                          },
                          child: Text('Manage Your Products',style: TextStyle(
                              color: appColorAccent,
                              fontSize: SizeConfig.textMultiplier * 1.4,
                              fontWeight: FontWeight.w600
                          ),),
                        ),
                      ),
                    ],
                  ),
                ),

               //
               //  // product counter
                StreamBuilder(
                    stream: _productService.getProductBySeller(sellerEmail),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                          itemCount: 1,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {

                            // Loop through all products in the snapshot
                            for (var doc in snapshot.data!) {
                              ProductModel pData = doc;

                              String pStatus = pData.productStatus ?? '';

                              // Increment the respective counter based on the status
                              if (pStatus == "Live") {
                                liveProductCount.add(pStatus);
                              } else if (pStatus == "Blocked") {
                                rejectedProductCount.add(pStatus);
                              }
                            }

                          return SizedBox(
                            width: SizeConfig.screenWidth * 1,
                            height: SizeConfig.screenHeight * 0.11,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Column(
                                  children: [
                                    Text('live Products:',style: TextStyle(
                                        color: appColorSecondary,
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        fontWeight: FontWeight.w600
                                    ),),

                                    Text('${liveProductCount.length}',style: TextStyle(
                                        color: appColorSecondary.withOpacity(0.4),
                                        fontSize: SizeConfig.textMultiplier * 6,
                                        fontWeight: FontWeight.w600
                                    ),)
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text('Blocked Products:',style: TextStyle(
                                        color: appColorSecondary,
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        fontWeight: FontWeight.w600
                                    ),),

                                    Text('${rejectedProductCount.length}',style: TextStyle(
                                        color: appColorSecondary.withOpacity(0.4),
                                        fontSize: SizeConfig.textMultiplier * 6,
                                        fontWeight: FontWeight.w600
                                    ),),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text('Total Products:',style: TextStyle(
                                        color: appColorSecondary,
                                        fontSize: SizeConfig.textMultiplier * 1.4,
                                        fontWeight: FontWeight.w600
                                    ),),

                                    Text('${snapshot.data!.length}',style: TextStyle(
                                        color: appColorSecondary.withOpacity(0.4),
                                        fontSize: SizeConfig.textMultiplier * 6,
                                        fontWeight: FontWeight.w600
                                    ),),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },);
                      } else if (snapshot.hasError) {
                        return const Icon(Icons.error_outline);
                      } else {
                        return Container();
                      }
                    }),
               //
               //  // products
                StreamBuilder(
                    stream: _productService.getProductBySeller(sellerEmail),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        return SizedBox(
                          width: SizeConfig.screenWidth * 1,
                          height: SizeConfig.screenHeight * 0.2,
                          child: snapshot.data!.length != 0 ? CarouselSlider(
                              items: List.generate(snapshot.data!.length, (index) {
                                ProductModel data = snapshot.data![index];
                                String pID = data.productId;
                                String pName = data.productName!;
                                String pCate = data.productCategory!;
                                String pImage = data.getProductImage!;
                                String pPrice = data.productPrice!;
                                String pStatus = data.productStatus!;
                                return  CustomProductStatusWidget(
                                  productID: pID,
                                  productName: pName,
                                  productImage: pImage,
                                  productPrice: pPrice,
                                  productCategory: pCate,
                                  productStatus: pStatus,
                                );
                              },), options: CarouselOptions(
                              autoPlay: true,
                              viewportFraction: 1,
                              height: SizeConfig.screenHeight * 0.2,
                              enlargeCenterPage: true,
                              autoPlayInterval: const Duration(milliseconds: 2000)
                          )) : const Center(child: Text('Nothing to Show'),),
                        );
                      } else if (snapshot.hasError) {
                        return const Icon(Icons.error_outline);
                      } else {
                        return Container();
                      }
                    })
              ],
            ),
          ),
        ),
      ),
    );
  }
}


