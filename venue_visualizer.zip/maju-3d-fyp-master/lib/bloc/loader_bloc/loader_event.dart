
class LoaderEvent {}

class LoadEvent extends LoaderEvent{
  final bool onLoad;

  LoadEvent(this.onLoad);
}
