import 'package:bloc/bloc.dart';

import 'loader_event.dart';
import 'loader_state.dart';

class LoaderBloc extends Bloc<LoaderEvent, LoaderState> {
  LoaderBloc() : super(LoaderInitial()) {
    on<LoadEvent>(_onLoading);
  }

  void _onLoading(LoadEvent event, Emitter<LoaderState> emit){
   emit(LoadState(event.onLoad));
  }
}
