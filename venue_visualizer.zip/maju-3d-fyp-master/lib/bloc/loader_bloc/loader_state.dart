
class LoaderState {}

class LoaderInitial extends LoaderState {}

class LoadState extends LoaderState{
  final bool onLoad;

  LoadState(this.onLoad);
}
