import 'package:bloc/bloc.dart';

import 'navbar_event.dart';
import 'navbar_state.dart';

class NavbarBloc extends Bloc<NavbarEvent, NavbarState>{
  NavbarBloc():super(PageCounterInitialize()){
    on<PageShifter>(_onChange);
  }

  void _onChange(PageShifter event, Emitter<NavbarState> emit){
    emit(PageCounter(event.pageCount));
  }

}