abstract class NavbarState{}

class PageCounterInitialize extends NavbarState{

}

class PageCounter extends NavbarState{
  final int pageCount;

  PageCounter(this.pageCount);
}