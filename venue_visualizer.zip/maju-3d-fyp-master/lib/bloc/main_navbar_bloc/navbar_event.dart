abstract class NavbarEvent{}

class PageShifter extends NavbarEvent{
  final int pageCount;

  PageShifter(this.pageCount);
}