import 'package:bloc/bloc.dart';
import 'package:majumodel/bloc/product_tab/product_tab_event.dart';
import 'package:majumodel/bloc/product_tab/product_tab_state.dart';

class ProductTabBloc extends Bloc<ProductTabEvent, ProductTabState> {
  ProductTabBloc() : super(ProductTabInitial()) {
    on<ProductTabChanger>(_onTabChange);
  }

  void _onTabChange(ProductTabChanger event, Emitter<ProductTabState> emit){
    emit (ProductTabChanged(event.changeValue));
  }
}
