
class ProductTabEvent {}

class ProductTabChanger extends ProductTabEvent{
  final int changeValue;

  ProductTabChanger(this.changeValue);
}
