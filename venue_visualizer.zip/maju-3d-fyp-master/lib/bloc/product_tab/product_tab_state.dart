
class ProductTabState {}

class ProductTabInitial extends ProductTabState {}

class ProductTabChanged extends ProductTabState{
  final int newTab;

  ProductTabChanged(this.newTab);
}
