
class PasswordCheckEvent {}

class CheckHidden extends PasswordCheckEvent{
  final bool isHidden;

  CheckHidden(this.isHidden);
}
