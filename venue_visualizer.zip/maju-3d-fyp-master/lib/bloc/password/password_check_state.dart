
class PasswordCheckState {}

class PasswordCheckInitial extends PasswordCheckState {}

class HiddenChecked extends PasswordCheckState{
  final bool isHidden;

  HiddenChecked(this.isHidden);
}
