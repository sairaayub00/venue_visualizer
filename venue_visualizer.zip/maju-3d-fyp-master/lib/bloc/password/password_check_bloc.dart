import 'package:bloc/bloc.dart';

import 'password_check_event.dart';
import 'password_check_state.dart';


class PasswordCheckBloc extends Bloc<PasswordCheckEvent, PasswordCheckState> {
  PasswordCheckBloc() : super(PasswordCheckInitial()) {
    on<CheckHidden>(_onHiddenChange);
  }

  void _onHiddenChange(CheckHidden event, Emitter<PasswordCheckState> emit){
    emit(HiddenChecked(event.isHidden));
  }
}
