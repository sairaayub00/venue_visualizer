
class ProductQuantityEvent {}

class ProductQuantityChange extends ProductQuantityEvent{
  final int quantity;

  ProductQuantityChange(this.quantity);
}

