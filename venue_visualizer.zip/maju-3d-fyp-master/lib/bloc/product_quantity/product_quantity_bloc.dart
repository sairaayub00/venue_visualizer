


import 'package:bloc/bloc.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_event.dart';
import 'package:majumodel/bloc/product_quantity/product_quantity_state.dart';

class ProductQuantityBloc extends Bloc<ProductQuantityEvent, ProductQuantityState> {
  ProductQuantityBloc() : super(ProductQuantityInitial()) {
    on<ProductQuantityChange>(_onChange);
  }

  void _onChange(ProductQuantityChange event, Emitter<ProductQuantityState> emit){
     emit(ProductQuantityChanger(event.quantity));

  }
}
