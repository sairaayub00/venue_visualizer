
class ProductQuantityState {}

class ProductQuantityInitial extends ProductQuantityState {}

class ProductQuantityChanger extends ProductQuantityState{
  final int newQuantity;

  ProductQuantityChanger(this.newQuantity);
}
